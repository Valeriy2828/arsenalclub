

# tree2json.py

# Functions to create JSON string from given ete3 tree

import math
import random
import numpy as np
import matplotlib.cm as cm
import imageio # for saving the image
#import scipy.misc
import matplotlib as mpl
import os


hm_colors = ['blue', 'white','red']
cmap = mpl.colors.LinearSegmentedColormap.from_list('bwr', hm_colors)

def hm_image(data, vlim, img_name, w, h, cmap):
    # Data is the list of profiles
    # vlim is the value limit that is symmetric around 0
    # img_name is the img name with path to save the png
    # w is the heatmap cell width and h is the heatmap cell height
    # Normalize so that scales correspond
    print('%s: Creating img' % img_name)
    norm = mpl.colors.Normalize(vmin=-vlim, vmax=vlim)
    print("1")
    colormap = cm.ScalarMappable(norm=norm, cmap=cmap)
    print("2")
    im = colormap.to_rgba(data)
    print("3")
    # scale the data to a width of w pixels
    im = np.repeat(im, w, axis=1)
    print("4")
    im = np.repeat(im, h, axis=0)
    print("5")
    # save the picture
    #scipy.misc.imsave(img_name, im)
    imageio.imwrite(img_name, im)
    print("6")

# skaala [5,1000] vahemikku [5,50]
def sizeScale(x, m=1.531304, b=1.575899):
    y = m * math.sqrt(x) + b
    return int(math.ceil(y))


def get_profiles(node, ds_list, big_img, vlim, hash_param, w, h, expressions):
    size = sizeScale(len(node))
    leaves = node.get_leaves()
    # random sample
    leaves = random.sample(leaves, size)
    if big_img:
        # plot images
        hm_data = os.path.join('static/tmp/big_imgs', hash_param+node.name+'.png') # path to image
        #profiles = [map(float, l.profile.split("|")) for l in leaves]
        profiles = [expressions.get(l.name, 0) for l in leaves]
        hm_image(profiles, vlim, hm_data, w, h, cmap)
    else:
        hm_data = []
        for j in range(0, len(leaves)):
            rowOutput = []
            for k in range(0, len(ds_list)):
                #rowOutput.append([leaves[j].profile.split("|")[k], j, ds_list[k], leaves[j].name])
                rowOutput.append([expressions.get(leaves[j].name, 0)[k], j, ds_list[k], leaves[j].name])
            hm_data.append({"row_data": rowOutput})
    return hm_data


def tree2json(node, d, ds_list, vlim, hash_param, w, h, flag, big_img, expressions):
    node.name = node.name.replace("'", '')
    flag = True if hasattr(node, "status") and node.status == "D" else flag
    json = {"name": node.name,
            "sparse_parent": node.position if hasattr(node, "position") else "false",
            "rootDist": float(node.rootDist),  # distance from root
            "score": node.score if hasattr(node, "score") else 0,  # vishic score
            "type": "node" if node.children else "leaf",
            "status": node.status if hasattr(node, 'status') else "null",
            "genes_annotated": node.annotated if hasattr(node, "status") and node.status == "D" else 0,
            "annotations": d.get(node.name, "null") if flag else "null",
            "size": len(node),
            "profile": get_profiles(node, ds_list, big_img, vlim, hash_param, w, h, expressions) if hasattr(node, "status") and node.status == "D" else 0
            }
    if node.children and not flag:
        json["children"] = []
        for ch in node.children:
            json["children"].append(tree2json(ch, d, ds_list, vlim, hash_param, w, h, flag, big_img, expressions))
    return json

# nodeview result
def node2json(node, d, expressions):
    node.name = node.name.replace("'", '')
    # flag = True if hasattr(node, "status") and node.status=="D" else flag
    json = {"name": node.name,
            "rootDist": float(node.rootDist),  # distance from root
            "score": node.score if hasattr(node, "score") else 0,  # vishic score
            #"nr_unique": d[d.node_id==node.name][["nr_unique"]].iloc[0]["nr_unique"] if node.name in d.node_id else 0,
            "type": "node" if node.children else "leaf",
            "status": node.status if hasattr(node, 'status') else 0,
            # "genes_annotated": node.annotated if hasattr(node, "status") and node.status=="D" else 0,
            "annotations": d.get(node.name, 0),
           # "annotations": d.loc[np.array(d.node_id)==node.name][["t_type", "pval", "t_id", "score", "descr", "value", "t_size", "hasuniq", "unique"]].groupby("t_type").first().reset_index().to_dict("record"),
            "size": len(node),
            "profile": expressions.get(node.name, 0)
           # "profile": ['%.6f' % elem for elem in map(float, getattr(node, "profile").split("|"))] if node.is_leaf() else 0
            }
    if node.children:
        json["children"] = []
        for ch in node.children:
            json["children"].append(node2json(ch, d, expressions))
    return json




