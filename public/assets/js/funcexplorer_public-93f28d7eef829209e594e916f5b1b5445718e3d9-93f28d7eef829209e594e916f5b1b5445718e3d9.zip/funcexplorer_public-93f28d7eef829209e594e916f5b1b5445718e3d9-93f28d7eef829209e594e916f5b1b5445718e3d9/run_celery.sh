#!/bin/sh

# Wait for Redis server to start
sleep 10

celery -A vishic_latest.celery worker --loglevel=debug -f /log
