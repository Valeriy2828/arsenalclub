#!/bin/sh
cd /app/data/
chmod -R 777 upload
chmod -R 777 logs

chmod +x /app/web_helpers/cronjob.sh
chmod 777 /app/web_helpers/cronjob.sh
service cron start

/usr/sbin/apache2ctl -D FOREGROUND
