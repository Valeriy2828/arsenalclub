<b>funcExplorer web page</b>



Python preprocessing and analaysis returns data as JSON


D3.js creates the graphs


Bootstrap templates are used for the web page


Flask is used for web