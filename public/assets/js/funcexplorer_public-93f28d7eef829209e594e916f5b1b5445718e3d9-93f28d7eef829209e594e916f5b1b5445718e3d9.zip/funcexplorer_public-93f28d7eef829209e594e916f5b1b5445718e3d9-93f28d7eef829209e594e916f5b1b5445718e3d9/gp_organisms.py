# Get gprofiler organisms

# This doesnt work
import os
import json
import pickle

organism_file = "data/databases/e_89.json"
with open(organism_file, "rb") as f:
    data = json.load(f)

keys = ['EG_METAZOA', 'EG_PLANTS', 'EG_FUNGI', 'E']

data = dict(data)

res = {}
for k in data.keys():
    res.update(data[k])

pickle.dump(res, open("/home/kolberg/vishic_latest/data/databases/gp_organisms_e89.pkl", "wb"))

###
dir = "/scratch/data/gprofiler/www/gprofiler/ensembl_data/meta"

organism_file = os.path.join(dir, "organisms.dat")


with open(organism_file, "rb") as f:
    organisms = f.read()

organisms = organisms.replace("=>", ":").replace("\n", "")
data = json.loads(organisms)