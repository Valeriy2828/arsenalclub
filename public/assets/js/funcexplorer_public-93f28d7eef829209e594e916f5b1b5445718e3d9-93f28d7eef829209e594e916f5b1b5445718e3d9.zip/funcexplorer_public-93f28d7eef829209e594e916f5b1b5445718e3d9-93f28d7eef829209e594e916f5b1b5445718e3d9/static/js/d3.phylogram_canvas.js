/*
 http://bl.ocks.org/kueda/1036776

 d3.phylogram_canvas.js
 Wrapper around a d3-based phylogram (tree where branch lengths are scaled)
 Also includes a radial dendrogram visualization (branch lengths not scaled)
 along with some helper methods for building angled-branch trees.

 Copyright (c) 2013, Ken-ichi Ueda

 All rights reserved.

 Redistribution and use in source and binary forms, with or without
 modification, are permitted provided that the following conditions are met:

 Redistributions of source code must retain the above copyright notice, this
 list of conditions and the following disclaimer. Redistributions in binary
 form must reproduce the above copyright notice, this list of conditions and
 the following disclaimer in the documentation and/or other materials
 provided with the distribution.

 THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 POSSIBILITY OF SUCH DAMAGE.

 DOCUEMENTATION
 l
 d3.phylogram.build(selector, nodes, options)
 Creates a phylogram.
 Arguments:
 selector: selector of an element that will contain the SVG
 nodes: JS object of nodes
 Options:
 width
 Width of the vis, will attempt to set a default based on the width of
 the container.
 height
 Height of the vis, will attempt to set a default based on the height
 of the container.
 vis
 Pre-constructed d3 vis.
 tree
 Pre-constructed d3 tree layout.
 children
 Function for retrieving an array of children given a node. Default is
 to assume each node has an attribute called "branchset"
 diagonal
 Function that creates the d attribute for an svg:path. Defaults to a
 right-angle diagonal.
 skipTicks
 Skip the tick rule.
 skipBranchLengthScaling
 Make a dendrogram instead of a phylogram.

 d3.phylogram.rightAngleDiagonal()
 Similar to d3.diagonal except it create an orthogonal crook instead of a
 smooth Bezier curve.
 */


if (!d3) {
    throw "d3 wasn't included!";
}
(function () {
    d3.phylogram = {};

    // HELPER FUNCTIONS

    // Function for right angle diagonal
    d3.phylogram.rightAngleDiagonal = function () {
        var projection = function (d) {
            return [d.y, d.x];
        } // from left to right

        var path = function (pathData) {
            return "M" + pathData[0] + ' ' + pathData[1] + " " + pathData[2];
        }

        function diagonal(diagonalPath, i) {
            var source = diagonalPath.source,
                target = diagonalPath.target,
                midpointX = (source.x + target.x) / 2,
                midpointY = (source.y + target.y) / 2,
                pathData = [source, {x: target.x, y: source.y}, target];
            pathData = pathData.map(projection);
            return path(pathData)
        }

        diagonal.projection = function (x) {
            if (!arguments.length) return projection;
            projection = x;
            return diagonal;
        };

        diagonal.path = function (x) {
            if (!arguments.length) return path;
            path = x;
            return diagonal;
        };
        return diagonal;
    };

    /* Scale branches according to the distance to root
     nodes is list of nodes to scale (i.e dense nodes), 
     w is the width of svg before adding heatmap
     max_rootDists is the maximum distance in the whole tree 
     */
    scaleBranchLengths = function (nodes, w, max_rootDists) {
        // Visit all nodes and adjust y pos with distance metric
        var visitPreOrder = function (root, callback) {
            callback(root)
            if (root.children) {
                for (var i = root.children.length - 1; i >= 0; i--) {
                    visitPreOrder(root.children[i], callback)
                }
            }
        }

        // scale for distances
        var yscale = d3.scale.linear()
            .domain([0, max_rootDists])
            .range([0, w]);

        visitPreOrder(nodes[0], function (node) {
            node.y = yscale(node.rootDist)
            // node.y = yscale(node.dist)
        })
        return yscale
    };

    /* Generating data for heatmap depending on the node
     Selection of genes to display is random
     */
    /* heatmap_data = function (node, sizeScale, ds_list) {
     // Function to select random genes in the same order as they are
     // ds_list is list with ds names for heatmap
     function getRandom(arr, size) {
     var shuffled = Array.from(Array(arr.length).keys()).slice(0), i = arr.length, temp, index;
     while (i--) {
     index = Math.floor((i + 1) * Math.random());
     temp = shuffled[index];
     shuffled[index] = shuffled[i];
     shuffled[i] = temp;
     }
     var indexes = shuffled.slice(0, size);
     indexes.sort();
     var res = [];
     for (i = 0; i < indexes.length; i++) {
     res.push(arr[indexes[i]]);
     }
     return res;
     }

     function get_leaves(node, leaf_list) {
     if (node.type == "leaf") {
     leaf_list.push({"name": node.name, "profile": node.profile});
     } else {
     node.all_children.forEach(function (d) {
     get_leaves(d, leaf_list)
     });
     }
     return leaf_list;
     }

     var hm_data = [];
     var row = 0;
     var leaf_list = get_leaves(node, []); // list with profile lists
     var leaf_list = getRandom(leaf_list, Math.ceil(sizeScale(node.size))); // random selection
     for (var j = 0; j < leaf_list.length; j++) {
     var col = 0;
     var rowOutput = [];
     for (var k = 0; k < leaf_list[j].profile.length; k++) {
     rowOutput.push([+leaf_list[j].profile[k], row, ds_list[col], leaf_list[j].name]);
     col++
     }
     hm_data.push({"dense_parent": node.name, "row_data": rowOutput});
     row++
     }
     return hm_data;
     }*/

    /* Converting hex color to rgb
     */
    hex2rgb = function (hex, opacity) {
        hex = hex.trim().substr(1);
        var bigint = parseInt(hex, 16), h = [];
        if (hex.length === 3) {
            h.push((bigint >> 4) & 255);
            h.push((bigint >> 2) & 255);
        } else {
            h.push((bigint >> 16) & 255);
            h.push((bigint >> 8) & 255);
        }
        h.push(bigint & 255);
        if (arguments.length === 2) {
            h.push(opacity);
            return 'rgba(' + h.join() + ')';
        } else {
            return 'rgb(' + h.join() + ')';
        }
    };


    /* Styling dense tree nodes (Treemap and Heatmap)
     selector is for canvas creating
     vis is <svg> element of the plot
     color is colorscale for terms
     hm_colorScale is colorscale for heatmap
     sizeScale is rectangle size scale
     */
    d3.phylogram.styleTreeNodes = function (vis, selector, color, hm_colorScale, sizeScale, ds_list, show_sparse) {
        var f = d3.format(".2f"); // number to float

        var hm_w = ds_list.length > 50 ? 5 : 10, //heatmap cell width
            hm_h = 1; //heatmap cell height

        var bbox = d3.select("g.dendrogram").node().getBBox(); // size parameters of <g> that contains dendrogram; needed to calculate the coordinates for heatmap

        var nodeEnter = vis.selectAll('g.node');

        nodeEnter.each(function (x) {
            // Style dense nodes
            if (x.status == "D") {

                // 1. Create treemap
                var treemap = d3.layout.treemap()
                    .size([Math.ceil(sizeScale(x.size)), Math.ceil(sizeScale(x.size))])
                    .sticky(true)
                    .sort(function (a, b) {
                        return a.value - b.value;
                    })
                    .children(function (d) {
                        return d
                    });
                //.value(function (d) {
                //    return d.value;
                //   return 1;
                //});

                var treemap_cell = d3.select(this).append("a")
                    .attr("xlink:href", function (d) {
                        var numberPattern = /\d+/g;
                        var url = window.location.href + "&node_id=";
                        url += x.name.match(numberPattern);
                        //url += "&cached=1";
                        return url
                    })
                    .attr("class", "nodeview")
                    .append("g")
                    .attr("class", "hover dense " + x.name)
                    .attr("transform", function (d) {
                        return "translate(" + 0 + "," + Math.ceil(-Math.ceil(sizeScale(d.size)) / 2) + ")";
                    });


                var cell = treemap_cell.selectAll("g")
                    .data(function (d) {
                        return treemap.nodes(d.annotations);
                    })
                    .enter().append("g")
                    .attr("class", "cell")
                    .attr("transform", function (d) {
                        return "translate(" + d.x + "," + d.y + ")";
                    });

                cell.append("rect")
                    .attr("width", function (d) {
                        return d.dx;
                    })
                    .attr("height", function (d) {
                        return d.dy;
                    })
                    .style("fill", function (d) {
                        return d.children ? null : hex2rgb(color(d.t_type));
                    })
                    .on("click", function (d) {
                        d3.select("#tooltip").classed("hidden", true);

                    })
                    .on("mouseover", function () {
                        var info = stat_data[x.name];

                        var tooltip = d3.select("#tooltip");
                        var numberPattern = /\d+/g;
                        tooltip.classed("hidden", false);
                        tooltip
                            .select(".cl_id")
                            .text(x.name.match(numberPattern));
                        tooltip
                            .select(".cl_score")
                            .text(f(x.score));
                        tooltip
                            .select(".cl_size")
                            .text(x.size);
                        tooltip
                            .select(".nr_uniq")
                            .text(info.nr_unique);

                        for (i = 0; i < info.top_annotations.length; i++) {
                            tooltip
                                .select("." + info.top_annotations[i].t_type + ".nr_terms")
                                .text(info.top_annotations[i].value);
                            tooltip
                                .select("." + info.top_annotations[i].t_type + ".term_id")
                                .text(info.top_annotations[i].t_id)
                                .style("font-weight", function () {
                                    return info.top_annotations[i].unique ? "bold" : "normal";
                                });
                            tooltip
                                .select("." + info.top_annotations[i].t_type + ".term_descr")
                                .text(info.top_annotations[i].descr);
                            tooltip.select("." + info.top_annotations[i].t_type + ".pval")
                                .text(info.top_annotations[i].pval);
                            tooltip
                                .select("." + info.top_annotations[i].t_type + ".hasuniq")
                                .text(function () {
                                    return info.top_annotations[i].hasuniq ? "U" : "";
                                });
                        }

                    })

                    .on("mousemove", function () {
                        var tooltip = d3.select("#tooltip");
                        // var tooltip_w = parseFloat(tooltip.style("width"));
                        var tooltip_h = parseFloat(tooltip.style("height"));
                        // 60 here is the fixed height of footer

                        var mouseTop = d3.event.clientY + tooltip_h + 60 < window.innerHeight; // if mouse is in upper part of page (there'is room to put tooltip underneath)
                        tooltip
                            .style("left", (d3.event.pageX + 10) + "px")
                            // .style("left", Math.max(2, d3.event.pageX - tooltip_w - 60) + "px")
                            .style("top", function () {
                                if (mouseTop) {
                                    return (d3.event.pageY + 10) + "px"
                                } else {
                                    return (d3.event.pageY - Math.abs(window.innerHeight - d3.event.clientY - tooltip_h) - 10) + "px"
                                }
                            });
                    })

                    .on("mouseout", function () {
                        var tooltip = d3.select("#tooltip");
                        tooltip.classed("hidden", true);

                        tooltip.selectAll(".nr_terms")
                            .text("");
                        tooltip.selectAll(".term_id")
                            .text("");
                        tooltip.selectAll(".term_descr")
                            .text("");
                        tooltip.selectAll(".pval")
                            .text("");
                        tooltip.selectAll(".hasuniq")
                            .text("");
                    });

                var dense_box = d3.select(this).node().getBBox(); //size of node box

                // 2. Adding the grey annotations proportion area next to the node
                var annot_height = Math.round(dense_box.height * (x.genes_annotated / x.size)); // height for nr of annotated genes box
                var annotation_nr = d3.select(this)
                    .append("g")
                    .attr("class", "hover genes_annotated " + x.name);

                var n_annotated = annotation_nr
                    .append("rect")
                    .attr("transform", "translate(" + (dense_box.x + dense_box.width + 2) + "," + (dense_box.y) + ")")
                    .attr("width", 4)
                    .attr("height", dense_box.height - annot_height)
                    .attr("stroke-width", 1)
                    .attr("stroke", "grey")
                    .attr("fill", "white")

                    .on("mouseover", function (d) {
                        var tooltip = d3.select("#nr_annot");
                        tooltip.html((d.genes_annotated).toString() + " genes of " + (d.size).toString() + " are annotated in this cluster");
                        tooltip.classed("hidden", false);
                    })
                    .on("mousemove", function (d) {
                        var tooltip = d3.select("#nr_annot");
                        tooltip
                            .style("left", (d3.event.pageX + 10) + "px")
                            .style("top", (d3.event.pageY - 10) + "px");
                    })
                    .on("mouseout", function (d) {
                        d3.select("#nr_annot").classed("hidden", true);
                    });

                var annotated = annotation_nr
                    .append("rect")
                    .attr("transform", "translate(" + (dense_box.x + dense_box.width + 2) + "," + (dense_box.y + (dense_box.height - annot_height)) + ")")
                    .attr("width", 4)
                    .attr("height", annot_height)
                    .attr("stroke-width", 1)
                    .attr("stroke", "grey")
                    .attr("fill", "grey")

                    .on("mouseover", function (d) {
                        var tooltip = d3.select("#nr_annot");
                        tooltip.html((d.genes_annotated).toString() + " genes of " + (d.size).toString() + " are annotated in this cluster");
                        tooltip.classed("hidden", false);
                    })
                    .on("mousemove", function () {
                        var tooltip = d3.select("#nr_annot");
                        tooltip
                            .style("left", (d3.event.pageX + 10) + "px")
                            .style("top", (d3.event.pageY - 10) + "px");

                    })
                    .on("mouseout", function () {
                        d3.select("#nr_annot").classed("hidden", true);

                    });

                // 3. Adding heatmap data next to the node
                //var hm_data = heatmap_data(x, sizeScale, ds_list); // creating data for heatmap
                var hm_data = x.profile;
                var canvas_width = hm_w * ds_list.length;
                var canvas_height = Math.ceil(sizeScale(x.size));

                /*selector.attr("width", function () {
                 return hm_w * ds_list.length > 500 ? 500 : hm_w * ds_list.length
                 })
                 .style("width", function () {
                 return hm_w * ds_list.length > 500 ? 500 + "px" : hm_w * ds_list.length + "px"
                 });*/
                var numberPattern = /\d+/g;
                if (typeof hm_data == "string") {
                    var subUrl = window.location.protocol + "//" + window.location.hostname + "/funcexplorer/" + hm_data;
                    console.log(subUrl);
                    var Main_canvas = selector.append("img")
                    // add lnk
                        .attr("onclick", function () {
                            var url = window.location.href + "&node_id=";
                            url += x.name.match(numberPattern);
                            return "window.location=" + "'" + url + "'" + ";";
                        })
                        .style("cursor", "pointer")
                        .attr("id", "hm" + x.name)
                        .attr("src", subUrl)
                        .style("width", canvas_width)
                        .style("height", canvas_height + "px")
                        .style("width", canvas_width + "px")
                        .style("display", "block")
                        .style("margin-top", "1px")
                        .attr("class", "border-rect")
                        .on("mousemove", function () {
                            var tooltip = d3.select("#hm_tooltip_big");
                            var tooltip_w = parseFloat(tooltip.style("width"));
                            var mouseRight = d3.event.clientX + tooltip_w + 20 > window.innerWidth; // if mouse is in right part of page (there'is no room to put tooltip right)
                            tooltip.style("left", function () {
                                if (mouseRight) {
                                    return (d3.event.pageX - tooltip_w) + "px";

                                }
                                else {
                                    return (d3.event.pageX) + "px";
                                }


                            })
                                .style("top", (d3.event.pageY + 10) + "px");
                            tooltip.select(".cluster_id")
                                .text(x.name.match(numberPattern));
                            tooltip.classed("hidden", false);
                        })
                        .on("mouseout", function () {
                            d3.select("#hm_tooltip_big").classed("hidden", true);
                        });


                }
                else {
                    var canvas_nodes = hm_data.map(function (d, i) {
                        return d.row_data
                    });
                    // Canvas
                    var Main_canvas = selector.append("canvas");

                    Main_canvas.attr("id", "hm" + x.name);
                    Main_canvas.style("width", canvas_width)
                        .attr("width", canvas_width)
                        .attr("height", canvas_height)
                        .style("height", canvas_height + "px")
                        .style("width", canvas_width + "px")
                        .style("display", "block")
                        .style("margin-top", "1px")
                        .attr("class", "border-rect");

                    d3.select("#hm" + x.name).on("mousemove", function () {
                        var p = d3.mouse(this);
                        var x = Math.floor(p[0] / hm_w); // gives the column
                        var y = Math.floor(p[1] / hm_h); // gives the row
                        var tooltip = d3.select("#hm_tooltip");
                        tooltip.select(".gene_id")
                            .text(canvas_nodes[y][x][3]);
                        tooltip.select(".sample_id")
                            .text(canvas_nodes[y][x][2].replace(/\.[^/.]+$/, ""));
                        tooltip.select(".value")
                            .text(canvas_nodes[y][x][0]);
                        var tooltip_w = parseFloat(tooltip.style("width"));
                        var mouseRight = d3.event.clientX + tooltip_w + 20 > window.innerWidth; // if mouse is in right part of page (there'is no room to put tooltip right)
                        tooltip.style("left",
                            function () {
                                if (mouseRight) {
                                    return (d3.event.pageX - tooltip_w) + "px";

                                }
                                else {
                                    return (d3.event.pageX) + "px";
                                }


                            })
                            .style("top", (d3.event.pageY + 10) + "px");

                        tooltip.classed("hidden", false);

                    })
                        .on("mouseout", function () {
                            d3.select("#hm_tooltip").classed("hidden", true);
                        });

                    var canvas = Main_canvas.node().getContext('2d');

                    var i = -1;
                    while (++i < canvas_nodes.length) {
                        r = canvas_nodes[i]; // one row
                        var j = -1;
                        while (++j < r.length) {
                            c = r[j];
                            canvas.fillStyle = hm_colorScale(c[0]);
                            // Create a rectangle: x,y,width,height
                            canvas.fillRect(j * hm_w, c[1] * hm_h, hm_w, hm_h);
                        }
                    }
                    ;

                }

            }

            // 4. Adding lines where 'No info' nodes are hidden if show_sparse=0
            if (show_sparse) {
                if (x.status == "S") {
                    if (x.type != "leaf") {
                        var sparse = d3.select(this)
                            .append("g")
                            .attr("class", "hover sparse " + x.name)
                            .attr("transform", function (d) {
                                return "translate(" + 0 + "," + Math.ceil(-Math.ceil(sizeScale(d.size)) / 2) + ")";
                            });
                        var numberPattern = /\d+/g;
                        sparse.append("rect")
                            .attr("width", Math.ceil(sizeScale(x.size)))
                            .attr("height", Math.ceil(sizeScale(x.size)))
                            .attr("fill", hex2rgb(color("No data")))
                            .on("mouseover", function (d) {
                                var tooltip = d3.select("#sparse_tooltip");
                                tooltip.classed("hidden", false);
                                tooltip
                                    .select(".cl_id")
                                    .text(x.name.match(numberPattern));
                                tooltip
                                    .select(".cl_size")
                                    .text(x.size);
                            })
                            .on("mousemove", function () {
                                var tooltip = d3.select("#sparse_tooltip");
                                var tooltip_w = parseFloat(tooltip.style("width"));
                                tooltip
                                    .style("left", (d3.event.pageX - tooltip_w - 10) + "px")
                                    .style("top", (d3.event.pageY - 30) + "px");

                            })

                            .on("mouseout", function (d) {
                                var tooltip = d3.select("#sparse_tooltip");
                                tooltip.classed("hidden", true);
                            });
                    }
                    ;

                    // 3. Adding heatmap data next to the node
                    //var hm_data = heatmap_data(x, sizeScale, ds_list); // creating data for heatmap
                    var hm_data = x.profile;
                    var canvas_width = hm_w * ds_list.length;
                    var canvas_height = Math.ceil(sizeScale(x.size));

                    /*selector.attr("width", function () {
                     return hm_w * ds_list.length > 500 ? 500 : hm_w * ds_list.length
                     })
                     .style("width", function () {
                     return hm_w * ds_list.length > 500 ? 500 + "px" : hm_w * ds_list.length + "px"
                     });*/

                    if (typeof hm_data == "string") {
                        var subUrl = window.location.protocol + "//" + window.location.hostname + "/funcexplorer/" + hm_data;
                        var Main_canvas = selector.append("img")
                        // add link
                            .attr("onclick", function () {
                                var numberPattern = /\d+/g;
                                var url = window.location.href + "&node_id=";
                                url += x.name.match(numberPattern);
                                return "window.location=" + "'" + url + "'" + ";";
                            })
                            .style("cursor", "pointer")
                            .attr("id", "hm" + x.name)
                            .attr("src", subUrl)
                            .style("width", canvas_width)
                            .style("height", canvas_height + "px")
                            .style("width", canvas_width + "px")
                            .style("display", "block")
                            .style("margin-top", "1px")
                            .attr("class", "border-rect")
                            .on("mousemove", function () {
                                var tooltip = d3.select("#hm_tooltip_big");
                                var tooltip_w = parseFloat(tooltip.style("width"));
                                var mouseRight = d3.event.clientX + tooltip_w + 20 > window.innerWidth; // if mouse is in right part of page (there'is no room to put tooltip right)
                                tooltip.style("left", function () {
                                    if (mouseRight) {
                                        return (d3.event.pageX - tooltip_w) + "px";

                                    }
                                    else {
                                        return (d3.event.pageX) + "px";
                                    }


                                })
                                    .style("top", (d3.event.pageY + 10) + "px");
                                tooltip.select(".cluster_id")
                                    .text(x.name.match(numberPattern));
                                tooltip.classed("hidden", false);
                            })
                            .on("mouseout", function () {
                                d3.select("#hm_tooltip_big").classed("hidden", true);
                            });

                    }
                    else {
                        var canvas_nodes = hm_data.map(function (d, i) {
                            return d.row_data
                        });
                        // Canvas
                        var Main_canvas = selector.append("canvas");

                        Main_canvas.attr("id", "hm" + x.name);
                        Main_canvas.style("width", canvas_width)
                            .attr("width", canvas_width)
                            .attr("height", canvas_height)
                            .style("height", canvas_height + "px")
                            .style("width", canvas_width + "px")
                            .style("display", "block")
                            .style("margin-top", "1px")
                            .attr("class", "border-rect");

                        d3.select("#hm" + x.name).on("mousemove", function () {
                            var p = d3.mouse(this);
                            var x = Math.floor(p[0] / hm_w); // gives the column
                            var y = Math.floor(p[1] / hm_h); // gives the row
                            var tooltip = d3.select("#hm_tooltip");
                            tooltip.select(".gene_id")
                                .text(canvas_nodes[y][x][3]);
                            tooltip.select(".sample_id")
                                .text(canvas_nodes[y][x][2].replace(/\.[^/.]+$/, ""));
                            tooltip.select(".value")
                                .text(canvas_nodes[y][x][0]);
                            var tooltip_w = parseFloat(tooltip.style("width"));
                            var mouseRight = d3.event.clientX + tooltip_w + 20 > window.innerWidth; // if mouse is in right part of page (there'is no room to put tooltip right)
                            tooltip.style("left", function () {
                                if (mouseRight) {
                                    return (d3.event.pageX - tooltip_w) + "px";

                                }
                                else {
                                    return (d3.event.pageX) + "px";
                                }


                            })
                                .style("top", (d3.event.pageY + 10) + "px");

                            tooltip.classed("hidden", false);

                        })
                            .on("mouseout", function () {
                                d3.select("#hm_tooltip").classed("hidden", true);
                            });

                        var canvas = Main_canvas.node().getContext('2d');

                        var i = -1;
                        while (++i < canvas_nodes.length) {
                            r = canvas_nodes[i]; // one row
                            var j = -1;
                            while (++j < r.length) {
                                c = r[j];
                                canvas.fillStyle = hm_colorScale(c[0]);
                                // Create a rectangle: x,y,width,height
                                canvas.fillRect(j * hm_w, c[1] * hm_h, hm_w, hm_h);
                            }
                        }
                        ;

                    }

                }

            }
            else {
                if (x.sparse_parent != "false") {
                    var sparse_parent = d3.select(this).append("g")
                        .attr("class", "sparse_parent")
                        .append("svg:line")
                        .attr("x1", 0)
                        .attr("y1", 0)
                        .attr("x2", 0)
                        .attr("y2", function (d) {
                            return d.sparse_parent == "left" ? -3 : 3;
                        })
                }
            }

        });
        // style root node
        var root_node = d3.select(".root");
        root_node.append("svg:line")
            .attr("fill", "none")
            .attr("stroke", "#555555")
            .attr("stroke-width", "1px")
            .attr("x1", 0)
            .attr("y1", 0)
            .attr("x2", -10)
            .attr("y2", 0);

    };

    d3.phylogram.Legend = function (domain_scale, hm_colorScale, minmax) {
        var legend_svg = d3.select("#legend")
            .append("svg");
        var hm_colors_legend = d3.select("#hm_legend")
            .append("svg");

        var legend = legend_svg.append("g")
            .attr("class", "legend")
            .attr("x", 5)
            .attr("y", 0);

        var term_legend = d3.legend.color()
            .cells(domain_scale.domain())
            .orient("vertical")
            .shapeWidth(12)
            .shapeHeight(12)
            .scale(domain_scale);

        legend_svg.select(".legend")
            .call(term_legend);


        var legendWidth = 200,
            //var legendWidth = Math.min(10 * ds_list.length, 300),
            legendHeight = 15;

        //position scale
        var s = Math.max(Math.ceil(minmax.max_expr), Math.abs(Math.floor(minmax.min_expr)));
        var max_count = Math.max.apply(Math, minmax.histogram.map(function (o) {
            return o.count;
        }));
        var xScale = d3.scale.linear().domain([-s, s]).range([0, legendWidth]);
        var yScale = d3.scale.linear().domain([0, max_count]).range([1, legendHeight]);

        var arr = s > 1 ? d3.range(-s, s, 0.1) : d3.range(-s, s, 0.01);

        hm_colors_legend.append("g")
            .attr("class", "hm_legend")
            .attr("transform", "translate(10,0)")
                .selectAll('rect').data(arr).enter()
                .append('rect')
                .attr({
                    x: function (d) {
                        return xScale(d)
                    },
                    y: 0,
                    height: legendHeight,
                    width: 5,
                    fill: function (d) {
                        return hm_colorScale(d)
                    }
                });

        /*legend.append("g")
            .attr("class", "hm_legend")
            .selectAll('rect').data(arr).enter()
            .append('rect')
            .attr({
                x: function (d) {
                    return xScale(d)
                },
                y: 0,
                height: legendHeight,
                width: 5,
                fill: function (d) {
                    return hm_colorScale(d)
                }
            });*/

        var lineFunction = d3.svg.line()
            .x(function (d) {
                return xScale(d.bin);
            })
            .y(function (d) {
                return legendHeight - yScale(d.count);
            })
            .interpolate("step-after");

        var lineGraph = d3.select(".hm_legend").append("path")
            .attr("d", lineFunction(minmax.histogram))
            .attr("stroke", "black")
            .attr("stroke-width", 1)
            .attr("fill", "none");


        //Set scale for x-axis
        /*var xScale = d3.scale.linear()
         .range([0, legendWidth / 2, legendWidth])
         .domain([-5,0,5]);
         // .domain(hm_colorScale.domain());*/

        //Define x-axis
        var xAxis = d3.svg.axis()
            .orient("bottom")
            .ticks(10)  //Set rough # of ticks
            .scale(xScale);

        //Set up X axis
        d3.select("g.hm_legend").append("g")
            .attr("class", "hm_axis")  //Assign "axis" class
            .attr("transform", "translate(" + (0) + "," + (8) + ")")
            .call(xAxis);

        var col_legend = d3.select("g.legendCells").node().getBBox();
        var hm_legend = d3.select("g.hm_legend").node().getBBox();
        var hm_axis = d3.select("g.hm_axis").node().getBBox();
        /*// dimensions for whole legend
        var l_dims = legend.node().getBBox();
        // d3.select("g.hm_legend").attr("transform", "translate(" + (l_dims.width - hm_legend.width) + "," + (col_legend.height + 20) + ")");

        var new_dims = d3.select("g.legend").node().getBBox();*/
        // set the dimensions for the legend svg
        legend_svg.attr("width", col_legend.width).attr("heigth", col_legend.height);
        legend_svg.style("height",col_legend.height + "px" );
        hm_colors_legend.attr("width", hm_axis.width + 20).attr("height", hm_legend.height);
        hm_colors_legend.style("height", hm_legend.height + "px").style("width", (hm_axis.width + 20) + "px");
    };

    d3.phylogram.tracks = function (svg, track_data, ds_list) {
        var track_svg = d3.select("#trackdata").append("svg");
        var track_colors = d3.scale.category20();

        var tracks = track_svg.append("g")
            .attr("class", "tracks");

        var title = tracks.append("g")
            .attr("class", "title");
        title.append("text")
        //.attr("text-anchor", "middle")
            .attr("fill", "#555555")
            .style("font-size", "12px")
            .attr("x", 20)
            .attr("y", 5)
            .text("Sample annotations");

        var hm_w = ds_list.length > 50 ? 5 : 10;
        var trackWidth = hm_w * ds_list.length,
            //var trackWidth = Math.min(10 * ds_list.length, 300),
            trackHeight = 10;

        /*d3.select("#trackdata").attr("width", function () {
         return hm_w * ds_list.length > 500 ? 500 : hm_w * ds_list.length
         })
         .style("width", function () {
         return hm_w * ds_list.length > 500 ? 500 + "px" : hm_w * ds_list.length + "px"
         });*/

        var hm_tracks = tracks.append("g")
            .attr("class", "hm_tracks");

        /*var len = ds_list.length;
         var cellwidth = trackWidth / len;*/

        var j = 0,
            i;

        for (var key in track_data) {
            var dat = track_data[key];
            i = 0;
            var ds,
                track_value;
            while (i < ds_list.length) {
                ds = ds_list[i]; // sample_id
                track_value = dat[ds]; // track value
                hm_tracks.append("rect")
                    .data([{"ds_id": ds, "tv": track_value, "tr_type": key}])
                    .attr("fill", track_colors(track_value))
                    .attr("x", i * hm_w)
                    .attr("y", j * trackHeight)
                    .attr("width", hm_w)
                    .attr("height", trackHeight)
                    .attr("class", "hover")
                    .on("mousemove", function (d) {
                        //Update the tooltip position and value
                        var tooltip = d3.select("#track_tooltip");
                        tooltip.select(".sample_name")
                            .text(d["ds_id"].replace(/\.[^/.]+$/, ""));
                        tooltip.select(".track_value")
                            .text(d["tv"]);
                        tooltip.select(".track_type")
                            .text(d["tr_type"]);
                        var tooltip_w = parseFloat(tooltip.style("width"));
                        var mouseRight = d3.event.clientX + tooltip_w + 200 > window.innerWidth; // if mouse is in right part of page (there'is no room to put tooltip right)
                        tooltip.style("left", function () {
                            if (mouseRight) {
                                return (d3.event.pageX - tooltip_w - 10) + "px";

                            }
                            else {
                                return (d3.event.pageX) + "px";
                            }


                        })
                            .style("top", (d3.event.pageY + 10) + "px");

                        tooltip.classed("hidden", false);
                    })
                    .on("mouseout", function () {
                        d3.select("#track_tooltip").classed("hidden", true);
                    });
                i += 1;
            }
            j += 1;
        }
        ;

        // locate the tracks on top of heatmap

        hm_tracks.attr("transform", "translate(" + 0 + "," + 24 + ")");
        title.attr("transform", "translate(" + 0 + "," + 10 + ")");
        var d_dims = tracks.node().getBBox();
        track_svg.attr("width", d_dims.width).attr("height", d_dims.height);

    };

    // Main function that plots the result
    d3.phylogram.build = function (selector, nodes, options) {
        options = options || {};
        var w = options.width || d3.select(selector).style('width') || d3.select(selector).attr('width'),
            w = parseInt(w);
        // 1. Constant parameters
        var ds_list = options.ds_list;
        // Data for heatmap colorscale
        var minmax = options.minmax;
        var show_sparse = options.show_sparse;
        var track_data = options.track_data;

        var verticalSeparation = 1; //vertical distance between box edges in pixels
        var colorscale = options.colors;

        var domains = ["BP", "CC", "MF", "keg", "rea", "tf", "mi", "cor", "hp", "hpa", "No data"];
        var domain_names = ['GO: Biological Process', 'GO: Cellular Component', 'GO: Molecular Function', 'KEGG', 'REACTOME', 'TRANSFAC', 'miRNA', 'CORUM', 'Human Phenotype Ontology', 'Human Protein Atlas', 'No data'];
        var fills = [];
        domains.forEach(function (n) {
            if (colorscale.hasOwnProperty(n)) {
                fills.push(colorscale[n]);
            }
        });

        var domain_scale = d3.scale.ordinal().domain(domain_names).range(fills);
        var color = d3.scale.ordinal().domain(domains).range(fills);

        //define a color scale using the min and max expression values
        //var s = Math.max(Math.ceil(maxData), Math.abs(Math.ceil(minData)));
        var b = Math.max(Math.ceil(minmax.higher), Math.abs(Math.floor(minmax.lower)));
        var hm_colorScale = d3.scale.linear()
            .domain([-b, 0, b])
            //.domain([-s, 0, s])
            .range(["blue", "white", "red"]);

        //var sizeScale = d3.scale.linear().domain([5, 1000]).range([5, 50]); // rectangle size scale
        var sizeScale = d3.scale.sqrt().domain([5, 1000]).range([5, 50]); // rectangle size scale

        var tree = options.tree || d3.layout.cluster()
                .nodeSize([1, 1]) // does it matter what size we have here?
                .separation(function (a, b) {
                    return (Math.ceil(sizeScale(a.size)) + Math.ceil(sizeScale(b.size))) / 2 + verticalSeparation;
                })
                .children(options.children || function (node) {
                        return node.children; // my change
                    });

        var nodes = tree(nodes);
        var leaf_nodes = nodes.filter(function (d) {
            return !d.children
        });

        //Distance between the top of the tree and the origin. Necessary for translation.
        var topToOrigin = -leaf_nodes[0].x + Math.ceil(sizeScale(leaf_nodes[0].size)) / 2 + verticalSeparation;

        var diagonal = options.diagonal || d3.phylogram.rightAngleDiagonal();

        var svg = options.vis || d3.select(selector).append("svg");

        var vis = svg.append("g")
            .attr("class", "dendrogram")
            .attr("id", "dendrogram")
            .attr("transform", "translate(20," + (topToOrigin) + ")");

        // add colors to tooltip
        for (i = 0; i < color.domain().length - 1; i++) {
            var term_type = color.domain()[i];
            var colorbox = d3.select("div." + term_type + ".colorbox");
            colorbox
                .style("background-color", color(term_type));
        }
        ;

        var max_rootDists = options.max_rootDists;

        // if this is set, then it draws dendrogram
        if (options.skipBranchLengthScaling) {
            var yscale = d3.scale.linear()
                .domain([0, w])
                .range([0, w]);
        } else {
            var yscale = scaleBranchLengths(nodes, w, max_rootDists);
        }

        // Drawing the distance scale behind the dendrogram
        var yscaleinv = d3.scale.linear()
            .domain([max_rootDists, 0])
            .range([0, w]);
        var scaleAxis = d3.svg.axis()
            .scale(yscaleinv)
            .orient("bottom")
            .ticks(5);  //Set rough # of ticks
        svg.append("g")
            .attr("class", "axis")  //Assign "axis" class
            .call(scaleAxis);

        // Drawing the tree
        var links = tree.links(nodes);
        var link = vis.selectAll("path.link")
            .data(links);

        link.enter().insert("path", "g")
            .attr("class", "link")
            .attr("id", function (d) {
                return d.target.name;
            })
            .attr("d", diagonal);
        /*.attr("fill", "none")
         .attr("stroke", "#555555")
         .attr("stroke-width", "0.5px")*/
        ;


        var node = vis.selectAll("g.node")
            .data(nodes).enter()
            .append("svg:g")
            .attr("class", function (n) {
                if (n.children) {
                    if (n.depth == 0) {
                        return "root node"
                    } else {
                        return "inner node"
                    }
                } else {
                    return "leaf node " + n.name
                }
            })
            .attr("transform", function (d) {
                return "translate(" + d.y + "," + d.x + ")";

            });
        // Add legend
        d3.phylogram.Legend(domain_scale, hm_colorScale, minmax);

        var sel = d3.select("#heatmapcanvas");
        d3.phylogram.styleTreeNodes(vis, sel, color, hm_colorScale, sizeScale, ds_list, show_sparse);

        // Add tracks
        d3.phylogram.tracks(svg, track_data, ds_list);

        var t = d3.transform(d3.select('.dendrogram').attr("transform")),
            x = t.translate[0],
            y = t.translate[1];

        d3.select(".dendrogram").attr("transform", "translate(" + x + "," + y + ")");

        // Optimize SVG dimensions according to plots
        var d1 = d3.select(".dendrogram").node().getBBox();
        var d2 = d3.select(".axis").node().getBBox();
        d3.select(".axis").attr("transform", "translate(20," + (d1.height + 20) + ")");
        svg.attr("width", Math.max(d1.width, d2.width) + 20)
            .attr("id", "vishic_svg")
            .attr("height", (d1.height + d2.height) + 20);


        return {tree: tree, vis: vis}
    }
}());


