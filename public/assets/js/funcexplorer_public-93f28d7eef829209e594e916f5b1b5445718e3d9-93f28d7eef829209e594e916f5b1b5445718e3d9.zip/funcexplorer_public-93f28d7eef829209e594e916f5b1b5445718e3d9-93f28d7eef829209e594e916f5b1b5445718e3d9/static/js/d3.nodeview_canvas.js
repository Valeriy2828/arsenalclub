if (!d3) {
    throw "d3 wasn't included!";
}

(function () {
    d3.nodeview = {};
    // HELPER FUNCTIONS

    // Function for right angle diagonal
    d3.nodeview.rightAngleDiagonal = function () {
        var projection = function (d) {
            return [d.y, d.x];
        }; // from left to right

        var path = function (pathData) {
            return "M" + pathData[0] + ' ' + pathData[1] + " " + pathData[2];
        };

        function diagonal(diagonalPath, i) {
            var source = diagonalPath.source,
                target = diagonalPath.target,
                midpointX = (source.x + target.x) / 2,
                midpointY = (source.y + target.y) / 2,
                pathData = [source, {x: target.x, y: source.y}, target];
            pathData = pathData.map(projection);
            return path(pathData)
        };

        diagonal.projection = function (x) {
            if (!arguments.length) return projection;
            projection = x;
            return diagonal;
        };

        diagonal.path = function (x) {
            if (!arguments.length) return path;
            path = x;
            return diagonal;
        };
        return diagonal;
    };

    /* Scale branches according to the distance to root
     nodes is list of nodes to scale (i.e dense nodes),
     w is the width of svg before adding heatmap
     max_rootDists is the maximum distance in the whole tree
     */
    visitPreOrder = function (root, callback) {
        callback(root);
        if (root.children) {
            for (var i = root.children.length - 1; i >= 0; i--) {
                visitPreOrder(root.children[i], callback)
            }
        }
    };

    scaleBranchLengths = function (nodes, w, max_rootDists) {

        // scale for distances
        var yscale = d3.scale.linear()
            .domain([0, max_rootDists])
            .range([0, w]);
        // Visit all nodes and adjust y pos with distance metric

        visitPreOrder(nodes[0], function (node) {
            node.y = yscale(node.rootDist)
        });
        return yscale
    };
    get_all_child = function (d, all_childs) {
        if (d.children) {
            var children = d.children;

            for (var i = 0; i < children.length; i++) {
                all_childs.push(children[i].name);
                get_all_child(children[i], all_childs);
            }
        }
        else {
            return all_childs
        }
        return all_childs;
    };

    get_all_annots = function (d, all_annots) {
        if (d.children) {
            var children = d.children;

            for (var i = 0; i < children.length; i++) {
                if (children[i].annotations.children && children[i].annotations.children.length) {
                    all_annots.push(children[i].annotations.children);
                }
                get_all_annots(children[i], all_annots);
            }
        }
        else {
            return all_annots
        }
        return all_annots;
    };

    // instead all_children we have children here!!
    get_leaves = function (node, leaf_list) {
        if (node.type == "leaf") {
            leaf_list.push({"name": node.name, "profile": node.profile});
        } else {
            if (node.children) {
                node.children.forEach(function (d) {
                    get_leaves(d, leaf_list)
                });
            }
            else {
                node.all_children.forEach(function (d) {
                    get_leaves(d, leaf_list)
                });

            }

        }
        return leaf_list;
    };

    /* Generating data for heatmap*/
    heatmap_data = function (node, ds_list) {
        // ds_list is list with ds names for heatmap
        // without random selection

        var hm_data = [];
        var row = 0;
        var leaf_list = get_leaves(node, []); // list with profile lists
        for (var j = 0; j < leaf_list.length; j++) {
            var col = 0;
            var rowOutput = [];
            for (var k = 0; k < leaf_list[j].profile.length; k++) {
                rowOutput.push([+leaf_list[j].profile[k], row, ds_list[col], leaf_list[j].name]);
                col++
            }
            hm_data.push({"dense_parent": node.name, "row_data": rowOutput});
            row++
        }
        return hm_data;
    }

    /* Converting hex color to rgb
     */
    hex2rgb = function (hex, opacity) {
        hex = hex.trim().substr(1);
        var bigint = parseInt(hex, 16), h = [];
        if (hex.length === 3) {
            h.push((bigint >> 4) & 255);
            h.push((bigint >> 2) & 255);
        } else {
            h.push((bigint >> 16) & 255);
            h.push((bigint >> 8) & 255);
        }
        h.push(bigint & 255);
        if (arguments.length === 2) {
            h.push(opacity);
            return 'rgba(' + h.join() + ')';
        } else {
            return 'rgb(' + h.join() + ')';
        }
    };
    replaceQueryParam = function (param, newval, search) {
        var regex = new RegExp("([?;&])" + param + "[^&;]*[;&]?");
        var query = search.replace(regex, "$1").replace(/&$/, '');
        return (query.length > 2 ? query + "&" : "?") + (newval ? param + "=" + newval : '');
    };

    d3.nodeview.Legend = function (container, domain_scale, hm_colorScale, minmax) {
        var legend_svg = container.select("#legend")
            .append("svg");

        var hm_colors_legend = d3.select("#hm_legend")
            .append("svg");

        var legend = legend_svg.append("g")
            .attr("class", "legend")
            .attr("x", 5)
            .attr("y", 0);


        var term_legend = d3.legend.color()
            .cells(domain_scale.domain())
            .shapeWidth(12)
            .shapeHeight(12)
            .scale(domain_scale);

        legend_svg.select(".legend")
            .call(term_legend);

        // width and height for heatmap scale
        var legendWidth = 200,
            legendHeight = 15;

        var s = Math.max(Math.ceil(minmax.max_expr), Math.abs(Math.floor(minmax.min_expr)));
        var max_count = Math.max.apply(Math, minmax.histogram.map(function (o) {
            return o.count;
        }));
        var xScale = d3.scale.linear().domain([-s, s]).range([0, legendWidth]);
        var yScale = d3.scale.linear().domain([0, max_count]).range([1, legendHeight]);
        var arr = s > 1 ? d3.range(-s, s, 0.1) : d3.range(-s, s, 0.01);

        hm_colors_legend.append("g")
            .attr("class", "hm_legend")
            .attr("transform", "translate(10,0)")
            .selectAll('rect').data(arr).enter()
            .append('rect')
            .attr({
                x: function (d) {
                    return xScale(d)
                },
                y: 0,
                height: legendHeight,
                width: 5,
                fill: function (d) {
                    return hm_colorScale(d)
                }
            });

        var lineFunction = d3.svg.line()
            .x(function (d) {
                return xScale(d.bin);
            })
            .y(function (d) {
                return legendHeight - yScale(d.count);
            })
            .interpolate("step-after");

        var lineGraph = d3.select(".hm_legend").append("path")
            .attr("d", lineFunction(minmax.histogram))
            .attr("stroke", "black")
            .attr("stroke-width", 1)
            .attr("fill", "none");

        //Define x-axis
        var xAxis = d3.svg.axis()
            .orient("bottom")
            .ticks(10)  //Set rough # of ticks
            .scale(xScale);

        //Set up X axis
        d3.select("g.hm_legend").append("g")
            .attr("class", "hm_axis")  //Assign "axis" class
            .attr("transform", "translate(" + (0) + "," + (8) + ")")
            .call(xAxis);

        // size of heatmap legend
        var hm_legend = d3.select("g.hm_legend").node().getBBox();
        var col_legend = d3.select("g.legendCells").node().getBBox();
        var hm_axis = d3.select("g.hm_axis").node().getBBox();

        legend_svg.attr("width", col_legend.width).attr("heigth", col_legend.height);
        legend_svg.style("height", col_legend.height + "px");
        hm_colors_legend.attr("width", hm_axis.width + 20).attr("height", hm_legend.height);
        hm_colors_legend.style("height", hm_legend.height + "px").style("width", (hm_axis.width + 20) + "px");
    };

    d3.nodeview.expr_profile = function (container, mynode, s, b, hm_colorScale, ds_list) {
        var expr_div = container.select("#expr_profile");

        var hm_w = ds_list.length > 50 ? 5 : 10;
        //var plotwidth = Math.min(10, 300 / ds_list.length) * ds_list.length,

        var margin = {top: 22, right: 5, bottom: 20, left: 60},
            width = ds_list.length * hm_w > 500 ? 500 : ds_list.length * hm_w,
            height = 300;

        var plotwidth = hm_w * ds_list.length,
            plotheight = 200;

        var svg = expr_div
            .append("svg");

        var gene_profile = svg.append("g")
            .attr("class", "gene_profile")
            .attr("transform", "translate(" + margin.left + "," + margin.top + ")")
            .style('stroke', "url(#linear-gradient)");

        // Get data
        var profiles = get_leaves(mynode, []);
        // x and y axis scales
        var x = d3.scale.linear().domain([0, ds_list.length]).range([0, plotwidth+hm_w]);
        var y = d3.scale.linear().domain([-s, 0, s]).nice().range([plotheight, plotheight / 2, 0]);

        // Linear gradient for profiles
        var defs = svg.append("g")
            .attr("class", "gradient")
            .append("defs");

        var linearGradient = defs.append("linearGradient")
            .attr("id", "linear-gradient")
            .attr("gradientUnits", "userSpaceOnUse");
        //Horizontal gradient

        linearGradient
            .attr("x1", 0)
            .attr("y1", y(-b))
            .attr("x2", 0)
            .attr("y2", y(b));

        //Append multiple color stops by using D3's data/enter step
        linearGradient.selectAll("stop")
            .data(hm_colorScale.range())
            .enter().append("stop")
            .attr("offset", function (d, i) {
                return i / (hm_colorScale.range().length - 1);
            })
            .attr("stop-color", function (d) {
                return d;
            });

        // Create x and y axis
        var xAxis = d3.svg.axis()
            .scale(x)
            .ticks(0)
            .outerTickSize(0);

        var yAxis = d3.svg.axis()
            .scale(y)
            .orient("left")
            .ticks(17)
            .outerTickSize(0)
            .tickFormat(d3.format('.1f'));

        gene_profile.append("g")
            .attr("class", "x axis geneprofile")
            .attr("font-weight", "lighter")
            .attr("transform", "translate(0," + y(0) + ")")
            .call(xAxis);

        gene_profile.append("g")
            .attr("class", "y axis geneprofile")
            .attr("font-weight", "lighter")
            .call(yAxis);


        // Add title
        gene_profile.append("text")
            .attr("dy", "0em")
            //.attr("x", (plotwidth / 2))
            .attr("x", 90)
            .attr("y", (0 - (margin.top / 2)))
            .attr("text-anchor", "middle")
            .attr("fill", "#555555")
            .attr("stroke", "none")
            .style("font-size", "12px")
            .text("Gene expression profiles");
        gene_profile.append("text")
            .attr("dy", "1em")
            //.attr("x", (plotwidth / 2))
            .attr("x", 90)
            .attr("y", (0 - (margin.top / 2)))
            .attr("text-anchor", "middle")
            .attr("fill", "#555555")
            .attr("stroke", "none")
            .style("font-size", "12px")
            .text("across experiments;");
        gene_profile.append("text")
            .attr("dy", "2em")
            //.attr("x", (plotwidth / 2))
            .attr("x", 90)
            .attr("y", (0 - (margin.top / 2)))
            .attr("text-anchor", "middle")
            .attr("fill", "#555555")
            .attr("stroke", "none")
            .style("font-size", "12px")
            .text("Eigengene profile");

        // Add titles to the axes
        gene_profile.append("text")
            .attr("fill", "#555555")
            .attr("stroke", "none")
            .style("font-size", "12px")
            .attr("text-anchor", "middle")  // this makes it easy to centre the text as the transform is applied to the anchor
            .attr("transform", "translate(" + (-50 + 14) + "," + (plotheight / 2) + ")rotate(-90)")  // text is drawn off the screen top left, move down and out and rotate
            .text("Expression");

        // Create d3 line chart
        var line = d3.svg.line()
            .x(function (d, i) {
                return x(i);
            })
            .y(function (d) {
                return y(d);
            });
        // Plot all gene profiles
        profiles.forEach(function (d, i) {
            gene_profile.append("path")
                .datum(d["profile"])
                .attr("class", "line")
                .attr("id", d.name)
               // .attr('stroke', "url(#linear-gradient)")
                .attr('stroke-width', 1)
                .attr('fill', 'none')
                .attr("d", line)
                .on("mouseover", function (x) {
                    //Update the tooltip position and value
                    var tooltip = d3.select("#expr_tooltip");
                    tooltip.select(".gene_id")
                        .text(this.id);
                    var tooltip_w = parseFloat(tooltip.style("width"));
                    tooltip.style("left", (d3.event.pageX - 100) + "px")
                        .style("top", (d3.event.pageY + 10) + "px");

                    tooltip.classed("hidden", false);

                })
                .on("mouseout", function () {
                    d3.select("#expr_tooltip").classed("hidden", true);
                });
        });
        var dims = gene_profile.node().getBBox();

        svg.attr("width", dims.width + margin.left)
            .attr("height", dims.height + 10);

    };

    d3.nodeview.heatmapcanvas = function (mynode, container, ds_list, hm_colorScale) {

        var hm_w = ds_list.length > 50 ? 5 : 10,
            hm_h = 3;
        /*var hm_w = Math.min(10, 300 / ds_list.length), //heatmap cell width
         hm_h = 3; //heatmap cell height*/

        var hm_container = container.select("#heatmapcanvas");
        // 3. Adding heatmap data next to the node
        var hm_data = heatmap_data(mynode, ds_list); // creating data for heatmap

        var canvas_nodes = hm_data.map(function (d, i) {
            return d.row_data
        });
        // Canvas
        var Main_canvas = hm_container.append("canvas");

        /*hm_container.attr("width", function () {
         return hm_w * ds_list.length > 500 ? 500 : hm_w * ds_list.length
         })
         .style("width", function () {
         return hm_w * ds_list.length > 500 ? 500 + "px" : hm_w * ds_list.length + "px"
         });*/

        var canvas_width = hm_w * ds_list.length;
        var canvas_height = hm_h * canvas_nodes.length;
        Main_canvas.attr("id", "hm" + mynode.name);
        Main_canvas.style("width", canvas_width)
            .attr("width", canvas_width)
            .attr("height", canvas_height)
            .style("height", canvas_height + "px")
            .style("width", canvas_width + "px")
            .style("display", "block")
            // .style("margin-top", "3px")
            .attr("class", "border-rect");

        d3.select("#hm" + mynode.name).on("mousemove", function () {
            var p = d3.mouse(this);
            var x = Math.floor(p[0] / hm_w); // gives the column
            var y = Math.floor(p[1] / hm_h); // gives the row
            var tooltip = d3.select("#hm_tooltip");

            tooltip.select(".gene_id")
                .text(canvas_nodes[y][x][3]);
            tooltip.select(".sample_id")
                .text(canvas_nodes[y][x][2].replace(/\.[^/.]+$/, ""));
            tooltip.select(".value")
                .text(canvas_nodes[y][x][0]);
            var tooltip_w = parseFloat(tooltip.style("width"));
            var mouseRight = d3.event.clientX + tooltip_w + 200 > window.innerWidth; // if mouse is in right part of page (there'is no room to put tooltip right)
            tooltip.style("left", function () {
                if (mouseRight) {
                    return (d3.event.pageX - tooltip_w - 10) + "px";

                }
                else {
                    return (d3.event.pageX) + "px";
                }


            })
                .style("top", (d3.event.pageY + 10) + "px");

            tooltip.classed("hidden", false);

        })
            .on("mouseout", function () {
                d3.select("#hm_tooltip").classed("hidden", true);
            });

        var canvas = Main_canvas.node().getContext('2d');

        var i = -1;
        while (++i < canvas_nodes.length) {
            r = canvas_nodes[i]; // one row
            var j = -1;
            while (++j < r.length) {
                c = r[j];
                canvas.fillStyle = hm_colorScale(c[0]);
                // Create a rectangle: x,y,width,height
                canvas.fillRect(j * hm_w, c[1] * hm_h, hm_w, hm_h);
            }
        }
        ;
    };
    d3.nodeview.StyleTreeNodes = function (dendrogram, color, sizeScale) {
        var f = d3.format(".2f"); // number to float

        var nodeEnter = dendrogram.selectAll('g.node');

        // Style nodes that have any annotation
        nodeEnter.each(function (n) {
            if (n.annotations != 0) {
                // 1. Create treemap
                var treemap = d3.layout.treemap()
                    .size([Math.ceil(sizeScale(n.size)), Math.ceil(sizeScale(n.size))])
                    .sticky(true)
                    .sort(function (a, b) {
                        return a.value - b.value;
                    })
                    .children(function (d) {
                        return d
                    });

                var treemap_cell = d3.select(this).append("a")
                    .attr("xlink:href", function (d) {
                        var numberPattern = /\d+/g;
                        //var url = window.location.href;
                        var str = window.location.search;

                        var url = window.location.pathname + replaceQueryParam("node_id", n.name.match(numberPattern), str);
                        //url += n.name.match(numberPattern);
                        return url
                    })
                    .attr("class", "nodeview")
                    .append("g")
                    .attr("class", "hover dense " + n.name)
                    .attr("transform", function (d) {
                        return "translate(" + Math.ceil(-Math.ceil(sizeScale(d.size)) / 2) + "," + Math.ceil(-Math.ceil(sizeScale(d.size)) / 2) + ")";
                    });

                var cell = treemap_cell.selectAll("g")
                    .data(function (d) {
                        return treemap.nodes(d.annotations);
                    })
                    .enter().append("g")
                    .attr("class", "cell")
                    .attr("stroke", "#ffffff")
                    .attr("stroke-width", 0.2)
                    .attr("transform", function (d) {
                        return "translate(" + d.x + "," + d.y + ")";
                    });
                cell.append("rect")
                    .attr("width", function (d) {
                        return d.dx;
                    })
                    .attr("height", function (d) {
                        return d.dy;
                    })
                    .style("fill", function (d) {
                        return d.children ? null : hex2rgb(color(d.t_type));
                    })
                    .on("mouseover", function (d) {
                        var children = get_all_child(n, []);
                        var paths = d3.selectAll(".link").filter(function (d) {
                            return children.indexOf(d.target.name) !== -1
                        });
                        //paths.style("stroke", "#8EA426");
                        paths.style("stroke", "#586618").style("stroke-width", 2);

                        var info = d.parent;

                        var tooltip = d3.select("#tooltip");
                        var numberPattern = /\d+/g;
                        var score = n.score;

                        tooltip.classed("hidden", false);
                        tooltip
                            .select(".cl_id")
                            .text(n.name.match(numberPattern));
                        tooltip
                            .select(".cl_score")
                            .text(f(score));
                        tooltip
                            .select(".cl_size")
                            .text(n.size);

                        n.status == "D" ? tooltip.select(".nr_uniq").text(n.nr_unique) : tooltip.select("#uniq").text("");

                        for (i = 0; i < info.length; i++) {
                            tooltip
                                .select("." + info[i].t_type + ".nr_terms")
                                .text(info[i].value);
                            tooltip
                                .select("." + info[i].t_type + ".term_id")
                                .text(info[i].t_id)
                                .style("font-weight", function () {
                                    return info[i].unique ? "bold" : "normal";
                                });
                            tooltip
                                .select("." + info[i].t_type + ".term_descr")
                                .text(info[i].descr);
                            tooltip.select("." + info[i].t_type + ".pval")
                                .text(info[i].pval);
                            tooltip
                                .select("." + info[i].t_type + ".hasuniq")
                                .text(function () {
                                    return info[i].hasuniq ? "U" : "";
                                });
                        }
                        ;
                        var tooltip_w = parseFloat(tooltip.style("width"));
                        var tooltip_h = parseFloat(tooltip.style("height"));
                        // 60 here is the fixed height of footer

                        var mouseTop = d3.event.clientY + tooltip_h + 60 < window.innerHeight; // if mouse is in upper part of page (there'is room to put tooltip underneath)
                        tooltip
                            .style("left", Math.max(2, d3.event.pageX - tooltip_w - 60) + "px")
                            .style("top", function () {
                                if (mouseTop) {
                                    return (d3.event.pageY + 10) + "px"
                                } else {
                                    return (d3.event.pageY - Math.abs(window.innerHeight - d3.event.clientY - tooltip_h) - 60 - 5) + "px"
                                }
                            });

                    })

                    /*.on("mousemove", function () {
                        var tooltip = d3.select("#tooltip");
                        var tooltip_w = parseFloat(tooltip.style("width"));
                        var tooltip_h = parseFloat(tooltip.style("height"));
                        // 60 here is the fixed height of footer

                        var mouseTop = d3.event.clientY + tooltip_h + 60 < window.innerHeight; // if mouse is in upper part of page (there'is room to put tooltip underneath)
                        tooltip
                            .style("left", Math.max(2, d3.event.pageX - tooltip_w - 60) + "px")
                            .style("top", function () {
                                if (mouseTop) {
                                    return (d3.event.pageY + 10) + "px"
                                } else {
                                    return (d3.event.pageY - Math.abs(window.innerHeight - d3.event.clientY - tooltip_h) - 60 - 5) + "px"
                                }
                            });
                    })*/

                    .on("mouseout", function () {
                        var paths = d3.selectAll(".link");
                        paths.style("stroke", "#555555").style("stroke-width", 1);

                        var tooltip = d3.select("#tooltip");
                        tooltip.classed("hidden", true);

                        tooltip.selectAll(".nr_terms")
                            .text("");
                        tooltip.selectAll(".term_id")
                            .text("");
                        tooltip.selectAll(".term_descr")
                            .text("");
                        tooltip.selectAll(".pval")
                            .text("");
                        tooltip.selectAll(".hasuniq")
                            .text("");
                    });
            }
            ;
        });

    };

    d3.nodeview.dendrogram = function (container, mynode, hm_colorScale, sizeScale, width, max_rootDists, color) {
        var svg = container.select("#node_tree")
            .append("svg");

        var dendrogram = svg.append("g")
            .attr("class", "node_dendrogram");

        var verticalSeparation = 3; //vertical distance between box edges in pixels

        var tree = d3.layout.cluster()
            .nodeSize([1, 1])
            .separation(function (a, b) {
                return verticalSeparation;
            })
            .children(function (node) {
                return node.children; // my change
            });

        var nodes = tree(mynode);

        var leaf_nodes = nodes.filter(function (d) {
            return !d.children
        });

        //var topToOrigin = -leaf_nodes[0].x + sizeScale(leaf_nodes[0].size) / 2 + verticalSeparation;
        var topToOrigin = -leaf_nodes[0].x + verticalSeparation;

        var tree_height = (leaf_nodes.length + 1 ) * verticalSeparation;

        var diagonal = d3.nodeview.rightAngleDiagonal();

        var yscale = scaleBranchLengths(nodes, width, max_rootDists);
        var yscaleinv = d3.scale.linear()
            .domain([max_rootDists, 0])
            .range([0, width]);
        var scaleAxis = d3.svg.axis()
            .scale(yscaleinv)
            .orient("bottom")
            .ticks(5);  //Set rough # of ticks

        dendrogram.append("g")
            .attr("class", "axis")  //Assign "axis" class
            .attr("id", "dendrogram_axis")
            .attr("transform", "translate(0," + ((tree_height - topToOrigin) + 10) + ")")
            .call(scaleAxis);


        // Drawing the tree
        var links = tree.links(nodes);
        var link = dendrogram.selectAll("path.link")
            .data(links);

        link.enter().insert("path", "g")
            .attr("class", "link")
            .attr("id", function (d) {
                return d.target.name;
            })
            .attr("d", diagonal);

        var node = dendrogram.selectAll("g.node")
            .data(nodes).enter()
            .append("g")
            .attr("class", function (n) {
                if (n.children) {
                    if (n.depth == 0) {
                        return "root node"
                    } else {
                        return "inner node"
                    }
                } else {
                    return "leaf node " + n.name
                }
            })
            .attr("transform", function (d) {
                return "translate(" + d.y + "," + d.x + ")";

            });


        // add colors to tooltip
        for (i = 0; i < color.domain().length - 1; i++) {
            var term_type = color.domain()[i];
            var colorbox = d3.select("div." + term_type + ".colorbox");
            colorbox
                .style("background-color", color(term_type));
        }
        ;

        d3.nodeview.StyleTreeNodes(dendrogram, color, sizeScale);

        dendrogram.attr("transform", "translate(20," + (topToOrigin) + ")");
        // Optimize SVG dimensions according to plots
        var d1 = d3.select(".node_dendrogram").node().getBBox();

        var d2 = d3.select("#dendrogram_axis").node().getBBox();

        svg.attr("width", Math.max(d1.width, d2.width) + 20)
            .attr("height", (d1.height + d2.height) + 20);


    };

    flatten = function (arr, result) {
        for (let i = 0, length = arr.length; i < length; i++) {
            const value = arr[i];
            if (Array.isArray(value)) {
                for (let i = 0, length = value.length; i < length; i++) {
                    const value2 = value[i];
                    if (Array.isArray(value2)) {
                        flatten(value2, result)
                    } else {
                        result.push(value2)
                    }
                }
            } else {
                result.push(value)
            }
        }
        return result
    };

    d3.nodeview.annot_profile = function (container, mynode, color) {
        var svg = container.select("#annot_profile")
            .append("svg");

        var annot_profile = svg.append("g")
            .attr("class", "annot_profile")
            .attr("transform", "translate(" + 60 + "," + 20 + ")")

        var plotwidth = 600;
        var plotheight = 400;

        var annotations = get_all_annots(mynode, []);
        annotations.push(mynode.annotations.children);
        var flat1 = flatten(annotations, []); // list of terms
        //var annotations = mynode.annotations.children;

        var data = flat1.map(function (d) {
            return d.children
        }); // list with lists for each t_type

        var flat = flatten(data, []); // list of terms

        flat.sort(function (a, b) {
            return a.pval - b.pval
        });
        var y = d3.scale.linear().range([plotheight, 0]);

        var x = d3.scale.ordinal()
            .rangeBands([0, plotwidth], 0.3);
        //.rangeRoundBands([0, plotwidth], .5, .01);

        x.domain(flat.map(function (d) {
            return d.name
        }));

        var xAxis = d3.svg.axis()
            .scale(x)
            .orient("bottom")
            .ticks(0)
            .tickSize(0)
            .tickFormat("");

        var yAxis = d3.svg.axis()
            .scale(y)
            .orient("left")
            .ticks(15);

        y.domain([0, d3.max(flat, function (d) {
            return -Math.log10(d.pval);
        })]);

        annot_profile.append("g")
            .attr("class", "x axis")
            .attr("transform", "translate(0," + plotheight + ")")
            .call(xAxis);
        /*.selectAll("text")
         .attr("dx", "-.8em")
         .attr("dy", ".15em")
         .attr("transform", "rotate(-65)")
         .style("text-anchor", "end")
         .style("font-size", "6");*/


        annot_profile.append("g")
            .attr("class", "y axis")
            .call(yAxis)
            .append("text")
            .attr("transform", "rotate(-90)")
            .attr("y", -60)
            .attr("x", 0 - (plotheight / 2))
            .attr("dy", "1em")
            .style("text-anchor", "middle")
            .text("-log10(p-val)");

        annot_profile.selectAll(".bar")
            .data(flat)
            .enter().append("rect")
            .attr("class", "hover bar")
            .attr("x", function (d) {
                return x(d.name);
            })
            .attr("y", function (d) {
                return y(-Math.log10(d.pval));
            })
            .attr("height", function (d) {
                return plotheight - y(-Math.log10(d.pval));
            })
            .attr("width", x.rangeBand())
            .attr("fill", function (d) {
                return hex2rgb(color(d.parent.name));
            })
            .attr("stroke", "white")
            .style("opacity", 0.4)
            .on("mouseover", function (d) {
                var numberPattern = /\d+/g;
                var tooltip = d3.select("#annot_tooltip");
                tooltip.select(".t_id")
                    .text(d.name);
                tooltip.select(".t_descr")
                    .text(d.descr);
                tooltip.select(".t_pval")
                    .text(d.pval);
                tooltip.select(".cl_id")
                    .text(d.parent.parent.name.match(numberPattern));
                tooltip.style("left", (d3.event.pageX) + "px")
                    .style("top", (d3.event.pageY + 10) + "px");
                tooltip.classed("hidden", false);
            })
            .on("mouseout", function () {
                d3.select("#annot_tooltip").classed("hidden", true);
            });

        var dims = annot_profile.node().getBBox();

        svg.attr("width", dims.width + 200)
            .attr("height", dims.height + 200);


    };
    d3.nodeview.tracks = function (track_data, ds_list) {
        var track_svg = d3.select("#trackdata").append("svg");

        var track_colors = d3.scale.category20();

        var tracks = track_svg.append("g")
            .attr("class", "tracks");

        var hm_w = ds_list.length > 50 ? 5 : 10;
        var trackWidth = hm_w * ds_list.length,
            //var trackWidth = Math.min(10 * ds_list.length, 300),
            trackHeight = 10;

        var hm_tracks = tracks.append("g")
            .attr("class", "hm_tracks");

        var title = tracks.append("g")
            .attr("class", "title");
        title.append("text")
            .attr("fill", "#555555")
            .style("font-size", "12px")
            .attr("x", 20)
            .attr("y", 5)
            .text("Sample annotations");

        var j = 0,
            i;

        for (var key in track_data) {
            var dat = track_data[key];
            i = 0;
            var ds,
                track_value;
            while (i < ds_list.length) {
                ds = ds_list[i]; // sample_id
                track_value = dat[ds]; // track value
                hm_tracks.append("rect")
                    .data([{"ds_id": ds, "tv": track_value, "tr_type": key}])
                    .attr("fill", track_colors(track_value))
                    .attr("x", i * hm_w)
                    .attr("y", j * trackHeight)
                    .attr("width", hm_w)
                    .attr("height", trackHeight)
                    .attr("class", "hover")
                    .on("mouseover", function (d) {
                        //Update the tooltip position and value
                        var tooltip = d3.select("#track_tooltip");
                        tooltip.select(".sample_name")
                            .text(d["ds_id"].replace(/\.[^/.]+$/, ""));
                        tooltip.select(".track_value")
                            .text(d["tv"]);
                        tooltip.select(".track_type")
                            .text(d["tr_type"]);
                        // var tooltip_w = parseFloat(tooltip.style("width"));

                        // var mouseRight = d3.event.clientX + tooltip_w + 300 > window.innerWidth; // if mouse is in right part of page (there'is no room to put tooltip right)
                        tooltip.style("left", (d3.event.pageX - 170) + "px")
                            .style("top", (d3.event.pageY + 10) + "px");

                        tooltip.classed("hidden", false);
                    })
                    .on("mouseout", function () {
                        d3.select("#track_tooltip").classed("hidden", true);
                    });
                i += 1;
            }
            j += 1;
        }
        ;
        // locate the tracks on top of heatmap

        hm_tracks.attr("transform", "translate(" + 0 + "," + 24 + ")");
        title.attr("transform", "translate(" + 0 + "," + 10 + ")");
        var d_dims = tracks.node().getBBox();
        track_svg.attr("width", d_dims.width).attr("height", d_dims.height);

        // locate the tracks on top of heatmap
        //var d_dims = track_svg.node().getBBox();

        //tracks.attr("transform", "translate(" + 0 + "," + 30 + ")");
        //hm_tracks.attr("transform", "translate(" + (d_dims.width - trackWidth) + "," + 20 + ")");
        //title.attr("transform", "translate(" + (d_dims.width - trackWidth) + "," + 10 + ")");
        // track_svg.attr("width", d_dims.width).attr("height", d_dims.height + 40);
    };

    d3.nodeview.build = function (selector, mydata, options) {
        options = options || {};
        var width = options.width || d3.select(selector).style('width') || d3.select(selector).attr('width'),
            width = parseInt(width);
        var height = options.height || d3.select(selector).style('height') || d3.select(selector).attr('height'),
            height = parseInt(height);
        var margin = options.margin; // must be?
        var track_data = options.track_data;
        var container = d3.select(selector);
        var colorscale = options.colors;
        // 1. Constant parameters
        // Data for heatmap colorscale
        var minmax = options.minmax;

        var max_rootDists = options.max_rootDists;
        var ds_list = options.ds_list;
        // 2. Define scales

        var domains = ["BP", "CC", "MF", "keg", "rea", "tf", "mi", "cor", "hp", "hpa", "No data"];
        var domain_names = ['GO: Biological Process', 'GO: Cellular Component', 'GO: Molecular Function', 'KEGG', 'REACTOME', 'TRANSFAC', 'miRNA', 'CORUM', 'Human Phenotype Ontology', 'Human Protein Atlas', 'No data'];
        var fills = [];
        domains.forEach(function (n) {
            if (colorscale.hasOwnProperty(n)) {
                fills.push(colorscale[n]);
            }
        });
        var domain_scale = d3.scale.ordinal().domain(domain_names).range(fills);
        var color = d3.scale.ordinal().domain(domains).range(fills);

        //define a color scale using the min and max expression values
        var s = Math.max(Math.ceil(minmax.max_expr), Math.abs(Math.floor(minmax.min_expr)));
        var b = Math.max(Math.ceil(minmax.higher), Math.abs(Math.floor(minmax.lower)));
        var hm_colorScale = d3.scale.linear()
            .domain([-b, 0, b])
            .range(["blue", "white", "red"]);

        // 3. Create gradient for expression profiles

        //var sizeScale = d3.scale.linear().domain([5, 1000]).range([5, 40]); // rectangle size scale
        var sizeScale = d3.scale.sqrt().domain([5, 1000]).range([5, 50]); // rectangle size scale

        // Create Gene expression Profiles plot
        d3.nodeview.expr_profile(container, mydata, s, b, hm_colorScale, ds_list);

        // Create the dendrogram and style the nodes + add heatmap and legend
        d3.nodeview.dendrogram(container, mydata, hm_colorScale, sizeScale, width, max_rootDists, color);

        // Create tracks
        d3.nodeview.tracks(track_data, ds_list);

        // Heatmap canvas
        d3.nodeview.heatmapcanvas(mydata, container, ds_list, hm_colorScale);

        // Create legend
        d3.nodeview.Legend(container, domain_scale, hm_colorScale, minmax);
    };
}());
