import os
import sys
from os.path import basename

import numpy as np
from ete3 import Tree
from flask import Flask, render_template, url_for, redirect, request, g, jsonify
from flask_compress import Compress
from keys import *
import hashlib
import json
import tempfile
from vishic.vishic import vishic2
from tree2json.tree2json import tree2json, node2json
from gprofiler import GProfiler
from collections import defaultdict
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.header import Header
import smtplib
import gzip
import operator
from werkzeug import secure_filename
import time
import base64
import pandas as pd
from vishic_celery import make_celery
import psycopg2
import gc # garbage collector
import logging
from web_helpers.create_logs import setup_logger
from web_helpers.short_link import create_short
import pickle
from datetime import datetime

calc_logger = setup_logger('vishic_calc', 'data/logs/vishic_calc.log') # logs of vishic pipeline calculations
data_prep_logger = setup_logger('data_prep', 'data/logs/data_prep.log') # logs of generating web view data

reload(sys)
sys.setdefaultencoding('utf-8')
sys.setrecursionlimit(5000)
import GEOparse
from web_helpers.captcha import pass_hidden, pass_img, create_identification_image
from web_helpers.clean_data import upload_file
from web_helpers.get_data import get_data_for_treeview

gp = GProfiler("funcexplorer/1.0")


app = Flask(__name__, static_url_path="/funcexplorer/static")
app.config.from_object('config')
app.config['CACHE_TYPE'] = 'simple'
app.config['SEND_FILE_MAX_AGE_DEFAULT'] = 2592000

COLORS = app.config["COLORS"]
BACKGROUNDS = app.config["BACKGROUNDS"]
NUMERIC_NS = app.config["NUMERIC_NS"]
ORGANISMS = app.config["ORGANISMS"]
HASHTABLE_NAME = app.config["HASHTABLE_NAME"]

compress = Compress()
compress.init_app(app)

celery = make_celery(app)


# Celery tasks


@celery.task(name='vishic_latest.get_url_data', bind=True)
def get_url_data(self, ds_id, data_dir, params2web, vishic_hash, hash_name, user):

    # Connect to vishic.postgres
    if user:
        db_user = app.config['DATABASES']['user']['USER']
        dbname = app.config['DATABASES']['user']['DBNAME']
        host = app.config['DATABASES']['user']['HOST']

    else:
        db_user = app.config['DATABASES']['default']['USER']
        dbname = app.config['DATABASES']['default']['DBNAME']
        host = app.config['DATABASES']['default']['HOST']

    conn_string = "host='%s' dbname='%s' user='%s'" % (host, dbname, db_user)
    conn = psycopg2.connect(conn_string)

    message = "Analysis starts..."
    self.update_state(state='PROGRESS',
                      meta={'status': message})

    startTime = datetime.now()
    tree, annotations, minmax, expressions = vishic2(ds_id=ds_id, hash_name=hash_name, conn=conn, params = params2web,
    data_dir = data_dir, user = user, self = self)
    # annotations are sorted by pval!!!
    timeElapsed = datetime.now() - startTime
    calc_logger.info('%s: Time taken for vishic2 (hh:mm:ss.ms) {}'.format(timeElapsed), ds_id)

    message = "Preparing the data for visualisation..."
    self.update_state(state='PROGRESS',
                      meta={'status': message})

    # If sparse clusters are not to show, then detach them
    if not params2web["showEmpty"]:
        for n in tree.iter_search_nodes(status="S"):
            n.detach()
    startTime = datetime.now()
    annot_data = \
    annotations.groupby(["node_id", "t_type"]).first().reset_index()[
        ["node_id", "t_id", "t_size", "intersection", "t_type", "pval", "descr", "status", "nr_unique", "value",
         "score", "unique", "size", "hasuniq"]]
    timeElapsed = datetime.now() - startTime
    calc_logger.info('%s: Time taken for annotations (hh:mm:ss.ms) {}'.format(timeElapsed), ds_id)

    # Get dense data
    startTime = datetime.now()
    dense_nodes = annot_data[annot_data.status == "D"].groupby("node_id")
    timeElapsed = datetime.now() - startTime
    calc_logger.info('%s: Time taken for selecting dense (hh:mm:ss.ms) {}'.format(timeElapsed), ds_id)
    startTime = datetime.now()
    stat_data = {k: {"unique": "U" if v.nr_unique.values[0] > 0 else "", "nr_unique": v.nr_unique.values[0] if v.nr_unique.values[0]>0 else 0,
                     "size": v["size"].values[0], "score": v.score.values[0], "top_annotations": v[
            ["t_id", "t_size", "intersection", "t_type", "pval", "descr", "value", "unique", "hasuniq"]].to_dict(
            "records")} for k, v in dense_nodes}
    timeElapsed = datetime.now() - startTime
    calc_logger.info('%s: Time taken for stat_data (hh:mm:ss.ms) {}'.format(timeElapsed), ds_id)
    startTime = datetime.now()
    to_json = {k: v[["t_type", "value"]].to_dict("records") for
               k, v in dense_nodes}
    timeElapsed = datetime.now() - startTime
    calc_logger.info('%s: Time taken for to_json (hh:mm:ss.ms) {}'.format(timeElapsed), ds_id)

    cur = conn.cursor()
    cur.execute("""SELECT ds_list FROM dataset WHERE ds_id='{t}';""".format(t=ds_id))
    ds_list = cur.fetchone()[0]
    if len(ds_list) > 250:
        big_img = True
        w = 5
        h = 1
    else:
        big_img = False
        w = 10
        h = 1

    vlim = max(np.floor(minmax["lower"]), np.ceil(minmax["higher"])) #Math.max(Math.ceil(minmax.higher), Math.abs(Math.floor(minmax.lower)));

    startTime = datetime.now()
    json_data = tree2json(tree, to_json, ds_list, vlim, vishic_hash, w, h, flag=False, big_img=big_img, expressions=expressions)
    timeElapsed = datetime.now() - startTime
    calc_logger.info('%s: Time taken for tree2json (hh:mm:ss.ms) {}'.format(timeElapsed), ds_id)

    # Data for sample tracks
    startTime = datetime.now()
    track_sql = """SELECT sample_id, track_name, track_value FROM tracks WHERE ds_id='{t}';""".format(t=ds_id)
    tracks = pd.read_sql_query(track_sql, conn)
    track_names = tracks.groupby("track_name").groups
    track_data = dict()  # dictionary of dictionaries
    for track_name, keys in track_names.iteritems():
        d = tracks.ix[keys][["sample_id", "track_value"]].set_index("sample_id")["track_value"].to_dict()
        track_data[track_name] = d
    timeElapsed = datetime.now() - startTime
    calc_logger.info('%s: Time taken for track_data (hh:mm:ss.ms) {}'.format(timeElapsed), ds_id)
    # Keep the resulting whole dataframe as list of dictionaries
    startTime = datetime.now()
    annotations = annotations.to_dict(orient='records')
    timeElapsed = datetime.now() - startTime
    calc_logger.info('%s: Time taken for list of dictionaries (hh:mm:ss.ms) {}'.format(timeElapsed), ds_id)
    json_path = os.path.join("static/tmp", vishic_hash)
    startTime = datetime.now()
    with gzip.GzipFile(json_path, 'w') as outfile:
        json.dump(json_data, outfile)  # saves binary
    timeElapsed = datetime.now() - startTime
    calc_logger.info('%s: Time taken for json dumps (hh:mm:ss.ms) {}'.format(timeElapsed), ds_id)
    # Save the newick tree
    startTime = datetime.now()
    tree.write(features=[], format=1, outfile=json_path + ".nw", format_root_node=True)
    timeElapsed = datetime.now() - startTime
    calc_logger.info('%s: Time taken for writing tree (hh:mm:ss.ms) {}'.format(timeElapsed), ds_id)
    json_data = json.dumps({'result': json_path})

    # Save the results to cache database
    cache_user = app.config['DATABASES']['cache']['USER']
    dbname = app.config['DATABASES']['cache']['DBNAME']
    host = app.config['DATABASES']['cache']['HOST']
    conn_string = "host='%s' dbname='%s' user='%s'" % (host, dbname, cache_user)
    cache_conn = psycopg2.connect(conn_string)
    cache_cur = cache_conn.cursor()
    startTime = datetime.now()
    cache_cur.execute(
        """INSERT INTO vishic_results (hash_id, json_data, minmax, stat_data, track_data, annot_data, expressions) VALUES (%s,%s,%s,%s,%s,%s,%s) ON CONFLICT DO NOTHING;""",
        (vishic_hash, json_data, json.dumps(minmax), json.dumps(stat_data), json.dumps(track_data), json.dumps(annotations), json.dumps(expressions)))
    cache_conn.commit()
    cache_conn.close()
    conn.close()
    timeElapsed = datetime.now() - startTime
    calc_logger.info('%s: Time taken for caching data (hh:mm:ss.ms) {}'.format(timeElapsed), ds_id)
    return {'status': 'Everything is ready!', 'result': vishic_hash}


def connect_db(user):
    if user:
        db_user = app.config['DATABASES']['user']['USER']
        dbname = app.config['DATABASES']['user']['DBNAME']
        host = app.config['DATABASES']['user']['HOST']
        conn_string = "host='%s' dbname='%s' user='%s'" % (host, dbname, db_user)
        return psycopg2.connect(conn_string)

    else:
        db_user = app.config['DATABASES']['default']['USER']
        dbname = app.config['DATABASES']['default']['DBNAME']
        host = app.config['DATABASES']['default']['HOST']
        conn_string = "host='%s' dbname='%s' user='%s'" % (host, dbname, db_user)
        return psycopg2.connect(conn_string)


def get_db(user=False):
    """Opens a new database connection if there is none yet for the
    current application context.
    """
    if not hasattr(g, 'db'):
        g.db = connect_db(user)
    return g.db


@app.teardown_request
def teardown_request(exception):
    gc.collect() # garbage collector
    if hasattr(g, 'db'):
        g.db.close()

# Homepage of the app


@app.route('/funcexplorer/', methods=['GET'])
def main():
    # Get data for homepage
    cur = get_db(user=False).cursor()
    cur.execute("SELECT DISTINCT ds_id, ds_name, ds_descr, organism, sample_count, platform FROM dataset;")

    ds_data = defaultdict(list)
    for ds_id, ds_name, descr, organism, sample_count, platform in cur.fetchall():
        ds_data[organism].append({"ds_id":ds_id, "ds_name": ds_name, "descr": descr, "samples": sample_count, "platform": platform})

    sorted_data = sorted(ds_data.items(), key=operator.itemgetter(0))
    ds_order = ["hsapiens", "mmusculus", "dmelanogaster", "celegans", "scerevisiae"]
    res = []
    for org in ds_order:
        r = ds_data.get(org, None)
        if r:
            res.append((org, r))
    for key, value in sorted_data:
        if not key in ds_order:
            res.append((key, value))

    # get available gpversions
    cur.execute("SELECT DISTINCT gp_version FROM input;")
    gp_versions = [i[0] for i in cur.fetchall()]
    gp_versions.sort(reverse=True)
    badmessage = "Dear user, we are under development at the moment and therefore the processes are not stable.\nIn case of suggestions and questions please contact liis.kolberg@gmail.com."
    return render_template("homepage.html", colors=COLORS, ds_data=res, gp_versions=gp_versions, badmessage=badmessage, organisms=dict(ORGANISMS))


@app.route('/funcexplorer/user/<string:hash>', methods=['GET'])
def user_main(hash):
    message = "NOTE: You are in the user page!\n Your data will be available here as soon as the preprocessing is finished."
    # Get the data for homepage
    cur = get_db(user=True).cursor()
    cur.execute("""SELECT count(*) FROM information_schema.tables WHERE table_name='blacklist';""")
    any_blacklist = cur.fetchone()[0]
    if any_blacklist:
        cur.execute("""SELECT DISTINCT email_hash FROM blacklist;""")
        blacklist = [i[0] for i in cur.fetchall()]
    else:
        blacklist = []
    if hash in blacklist:
        badmessage = "Dear user, we encountered some problems while trying to process Your data.\nPlease contact liis.kolberg@gmail.com"
    else:
        badmessage = False
    badmessage = "Dear user, we are under development at the moment and therefore the processes are not stable.\nIn case of suggestions and questions please contact liis.kolberg@gmail.com."
    cur.execute(
        """SELECT DISTINCT ds_id, ds_name, organism, sample_count, created_at FROM dataset WHERE ds_id IN (SELECT ds_id FROM input WHERE email_hash='%s');""" % (hash,))
    ds_data = defaultdict(list)
    for ds_id, ds_name, organism, sample_count, created_at in cur.fetchall():
        ds_data[organism].append({"ds_id": ds_id, "ds_name": ds_name, "descr": "", "samples": sample_count, "created_at": created_at})

    sorted_data = sorted(ds_data.items(), key=operator.itemgetter(0))
    ds_order = ["hsapiens", "mmusculus", "dmelanogaster", "celegans", "scerevisiae"]
    res = []
    for org in ds_order:
        r = ds_data.get(org, None)
        if r:
            res.append((org, r))
    for key, value in sorted_data:
        if not key in ds_order:
            res.append((key, value))
    # get available gpversions
    cur.execute("SELECT DISTINCT gp_version FROM input;")
    gp_versions = [i[0] for i in cur.fetchall()]
    gp_versions.sort(reverse=True) # starting from latest
    return render_template("homepage.html", colors=COLORS, ds_data=res, gp_versions=gp_versions, message=message, badmessage=badmessage, user=True, hash=hash, user_hash=hash, organisms=dict(ORGANISMS))


# Initialising the calculations


@app.route('/funcexplorer/', methods=['POST'])
def main_post():
    # Reading form values after submiting
    ds_id = request.form['ds']
    distMeasure = request.form['distMeasure']  # distance measure valued as 'p'
    correction = request.form['correction']  # gP correction valued as 'a', 'b' or 'f'
    cutStrategy = request.form['cutStrategy']  # select strategy valued as 'best', 'first', 'f1'
    showEmpty = request.form['showEmpty']  # show sparse? if 1, then Yes; if 0, then 0
    gpversion = request.form['gpversion']
    minSize = request.form['minSize']  # min cluster size
    maxSize = request.form['maxSize']  # max cluster size
    threshold = request.form['threshold']  # pval threshold as string
    min_term_size = request.form['min_t_size']
    max_term_size = request.form['max_t_size']
    terms = request.form.getlist('terms')  # user selected terms;
    terms = '-'.join(terms)

    return redirect(
        url_for('treeview', ds=ds_id, dist=distMeasure, corr=correction, cut=cutStrategy, sparse=showEmpty, min=minSize,
                max=maxSize, thr=threshold, terms=terms, gpversion=gpversion, min_term_size=min_term_size, max_term_size=max_term_size, _external=True, _scheme='https'))


@app.route('/funcexplorer/user/<string:hash>', methods=['POST'])
def user_main_post(hash):
    # Reading form values after submiting
    ds_id = request.form['ds']
    distMeasure = request.form['distMeasure']  # distance measure valued as 'e' or 'p'
    correction = request.form['correction']  # gP correction valued as 'a', 'b' or 'f'
    cutStrategy = request.form['cutStrategy']  # select strategy valued as 'best', 'first'
    showEmpty = request.form['showEmpty']  # show sparse? if 1, then Yes; if 0, then 0
    gpversion = request.form['gpversion']
    minSize = request.form['minSize']  # min cluster size
    maxSize = request.form['maxSize']  # max cluster size
    threshold = request.form['threshold']  # pval threshold as string
    terms = request.form.getlist('terms')  # user selected terms;
    terms = '-'.join(terms)
    min_term_size = request.form['min_t_size']
    max_term_size = request.form['max_t_size']
    return redirect(
        url_for('treeview_user', hash=hash, ds=ds_id, dist=distMeasure, corr=correction, cut=cutStrategy, sparse=showEmpty,
                min=minSize,
                max=maxSize, thr=threshold, terms=terms, gpversion=gpversion, min_term_size=min_term_size, max_term_size=max_term_size, user_hash=hash, _external=True, _scheme='https'))


@app.route('/funcexplorer/<ds>')
def treeview(ds):
    distMeasure = request.args.get('dist')
    correction = request.args.get('corr')
    cutStrategy = request.args.get('cut')
    minSize = request.args.get('min', type=int)
    maxSize = request.args.get('max', type=int)
    threshold = request.args.get('thr', type=float)
    terms = request.args.get('terms', default="")  # comma separated
    showEmpty = request.args.get('sparse', type=int)  # show sparse clusters?
    gpversion = request.args.get('gpversion')
    min_term_size = request.args.get('min_term_size', type=int)
    max_term_size = request.args.get("max_term_size", type=int)
    # otherwise it is unicode and hash doesn't match
    if distMeasure:
        distMeasure = distMeasure.encode('utf-8')
    if correction:
        correction = correction.encode('utf-8')
    if gpversion:
        gpversion = gpversion.encode('utf-8')
    if request.args.get('node_id'):
        node_id = request.args.get('node_id')
    else:
        node_id = ""

    # needed for hashes to work
    ds = ds.encode("utf_8")

    terms = terms.split('-')  # split selected terms into list and make unicode to string (for DB query)

    # parameters to show in web
    params2web = {"dist": distMeasure, "corr": correction, "cut": cutStrategy, "min": minSize, "max": maxSize,
                  "terms": ", ".join(terms), "min_term_size": min_term_size, "max_term_size": max_term_size,
                  "gpversion": gpversion, "thr": threshold, "showEmpty": showEmpty}
    hash = "" # not a user
    # parameters used for calculations
    params = [ds, gpversion, hash]  # calculations parameters
    # parameters used for view generation
    viewparams = [cutStrategy, minSize, maxSize, threshold, terms, showEmpty, min_term_size,
                  max_term_size]  # web visualisation parameters
    key = params + [distMeasure, correction]
    hash_name = hashlib.md5(str(key)).hexdigest()
    # check if file exists
    nwk_file = ds + "_%s.nwk" % distMeasure
    nwk_file = os.path.join(app.config["DATADIR"], "nwk_files/vishic", nwk_file)
    if not os.path.isfile(nwk_file):
        return render_template("error.html")

    vishic_hash = hash_name + hashlib.md5(str(viewparams)).hexdigest()

    # Create connection
    conn = get_db(user=False)
    # Check if result is already in the database
    cache_user = app.config['DATABASES']['cache']['USER']
    dbname = app.config['DATABASES']['cache']['DBNAME']
    host = app.config['DATABASES']['cache']['HOST']
    conn_string = "host='%s' dbname='%s' user='%s'" % (host, dbname, cache_user)
    cache_conn = psycopg2.connect(conn_string)
    c = cache_conn.cursor()
    sql = """SELECT EXISTS(SELECT 1 FROM vishic_results WHERE hash_id='%s');""" % (vishic_hash,)
    c.execute(sql)
    exists = c.fetchone()[0]

    if exists:
        dat = get_data_for_treeview(ds_id=ds, vishic_hash=vishic_hash, conn=conn, cache_conn=cache_conn,
                                    node_id=str(node_id), logging=data_prep_logger)

        if node_id:
            return render_template("nodeview.html", gene_names=dat["gene_names"], minmax=dat["minmax"], term_names=dat["term_names"],
                                   node_id=node_id, gp_url=dat["gp_url"],
                                   ds_data=dat["ds_data"], json_data=dat["json_data"], ds_list=dat["ds_list"],
                                   colors=COLORS, track_data=dat["track_data"], genes=dat["node_genes"], annotations=dat["node_annotations"],
                                   hash=vishic_hash, parameters=params2web, eigengene=dat["eigengene"])
        else:
            gene_cov = sum([v["size"] for v in dat["stat_data"].itervalues()])
            perc_cov = round(float(gene_cov) / len(dat["genes"]) * 100, 2)
            return render_template("viewpage.html", minmax=dat["minmax"], ds_data=dat["ds_data"], json_data=dat["json_data"],
                                   ds_list=dat["ds_list"], unique=dat["unique"], stat_data=dat["stat_data"],
                                   colors=COLORS, show_sparse=showEmpty, gene_names=dat["gene_names"], track_data=dat["track_data"],
                                   term_names=dat["term_names"], genes=dat["genes"], hash=vishic_hash, parameters=params2web, wordcloud=dat["wordcloud"], best_score=dat["best_score"], gene_cov=gene_cov, perc_cov=perc_cov, eigengene=dat["eigengene"])

    else:
        c.close()
        cache_conn.close()
        # calculate
        user = False
        task = get_url_data.apply_async(args=[ds, app.config["DATADIR"], params2web, vishic_hash, hash_name, user])
        task_id = task.id
        resp = {'Location': url_for('taskstatus', task_id=task_id)}
        return render_template("calculating.html", urls=resp, ds=ds, dist=distMeasure, corr=correction, cut=cutStrategy,
                               sparse=showEmpty, min=minSize, max=maxSize, thr=threshold, terms="-".join(terms),
                               min_term_size=min_term_size,
                               max_term_size=max_term_size, gpversion=gpversion)




@app.route('/funcexplorer/user/<string:hash>/<ds>')
def treeview_user(hash, ds):
    startTime = datetime.now()
    message = "NOTE: You are in the user page!"
    distMeasure = request.args.get('dist')
    correction = request.args.get('corr')
    cutStrategy = request.args.get('cut')
    minSize = request.args.get('min', type=int)
    maxSize = request.args.get('max', type=int)
    threshold = request.args.get('thr', type=float)
    terms = request.args.get('terms', default="")  # comma separated
    showEmpty = request.args.get('sparse', type=int)  # show sparse clusters?
    gpversion = request.args.get('gpversion')
    min_term_size = request.args.get('min_term_size', type=int)
    max_term_size = request.args.get("max_term_size", type=int)
    terms = terms.split('-')  # split selected terms into list and make unicode to string (for DB query)
    # otherwise it is unicode and hash doesn't match
    if distMeasure:
        distMeasure = distMeasure.encode('utf-8')
    if correction:
        correction = correction.encode('utf-8')
    if gpversion:
        gpversion = gpversion.encode('utf-8')

    # needed for hashes to work
    hash = hash.encode("utf-8")
    ds = ds.encode("utf_8")

    if request.args.get('node_id'):
        node_id = request.args.get('node_id')
    else:
        node_id = ""
    timeElapsed = datetime.now() - startTime
    data_prep_logger.info('%s: Time taken for arguments (hh:mm:ss.ms) {}'.format(timeElapsed), ds)
    startTime = datetime.now()
    # parameters to show in web
    params2web = {"dist": distMeasure, "corr": correction, "cut": cutStrategy, "min": minSize, "max": maxSize,
                  "terms": ", ".join(terms), "min_term_size": min_term_size, "max_term_size": max_term_size,
                  "gpversion": gpversion, "thr": threshold, "showEmpty": showEmpty}

    # parameters used for calculations
    params = [ds, gpversion, hash] # calculations parameters
    # parameters used for view generation
    viewparams = [cutStrategy, minSize, maxSize, threshold, terms, showEmpty, min_term_size, max_term_size] # web visualisation parameters
    key = params + [distMeasure, correction]
    hash_name = hashlib.md5(str(key)).hexdigest()
    nwk_file = ds + "_%s.nwk" % distMeasure
    nwk_file = os.path.join(app.config["DATADIR"], "nwk_files/user", nwk_file)
    if not os.path.isfile(nwk_file):
        return render_template("error.html")
    vishic_hash = hash_name + hashlib.md5(str(viewparams)).hexdigest()
    timeElapsed = datetime.now() - startTime
    data_prep_logger.info('%s: Time taken for parameters (hh:mm:ss.ms) {}'.format(timeElapsed), ds)
    startTime = datetime.now()
    # Create connection
    conn = get_db(user=True)
    # Check if result is already in the database
    cache_user = app.config['DATABASES']['cache']['USER']
    dbname = app.config['DATABASES']['cache']['DBNAME']
    host = app.config['DATABASES']['cache']['HOST']
    conn_string = "host='%s' dbname='%s' user='%s'" % (host, dbname, cache_user)
    cache_conn = psycopg2.connect(conn_string)
    c = cache_conn.cursor()
    sql = """SELECT EXISTS(SELECT 1 FROM vishic_results WHERE hash_id='%s');""" % (vishic_hash,)
    c.execute(sql)
    exists = c.fetchone()[0]
    timeElapsed = datetime.now() - startTime
    data_prep_logger.info('%s: Time taken for db (hh:mm:ss.ms) {}'.format(timeElapsed), ds)
    if exists:
        startTime = datetime.now()
        dat = get_data_for_treeview(ds_id=ds, vishic_hash=vishic_hash, conn=conn, cache_conn=cache_conn, node_id=str(node_id), logging=data_prep_logger)
        #dat = get_data_for_treeview(ds_id=ds, params=params, dist=distMeasure, correction=correction, viewparams=viewparams, conn=conn, cache_conn=cache_conn, node_id=str(node_id), logging=logging)
        timeElapsed = datetime.now() - startTime
        data_prep_logger.info('%s: Time taken for get_data (hh:mm:ss.ms) {}'.format(timeElapsed), ds)

        if node_id:

            return render_template("nodeview.html", gene_names=dat["gene_names"], minmax=dat["minmax"], term_names=dat["term_names"],
                                   node_id=node_id, gp_url=dat["gp_url"],
                                   ds_data=dat["ds_data"], json_data=dat["json_data"], ds_list=dat["ds_list"],
                                   colors=COLORS, track_data=dat["track_data"], genes=dat["node_genes"], annotations=dat["node_annotations"],
                                   hash=vishic_hash, user=True, message=message, parameters=params2web, user_hash=hash, eigengene=dat["eigengene"])
        else:
            gene_cov = sum([v["size"] for v in dat["stat_data"].itervalues()])
            perc_cov = round(float(gene_cov) / len(dat["genes"])*100,2)
            return render_template("viewpage.html", minmax=dat["minmax"], ds_data=dat["ds_data"], json_data=dat["json_data"],
                                   ds_list=dat["ds_list"], unique=dat["unique"], stat_data=dat["stat_data"],
                                   colors=COLORS, show_sparse=showEmpty, gene_names=dat["gene_names"], track_data=dat["track_data"],
                                   term_names=dat["term_names"], genes=dat["genes"], hash=vishic_hash, parameters=params2web,
                                   user=True, message=message, user_hash=hash, wordcloud=dat["wordcloud"], best_score=dat["best_score"], gene_cov=gene_cov, perc_cov=perc_cov, eigengene=dat["eigengene"])
    # data is not cached
    else:
        c.close()
        cache_conn.close()
        user = True
        task = get_url_data.apply_async(args=[ds, app.config["DATADIR"], params2web, vishic_hash, hash_name, user])
        task_id = task.id
        resp = {'Location': url_for('taskstatus', task_id=task_id)}
        return render_template("calculating.html", urls=resp, ds=ds, dist=distMeasure, corr=correction, cut=cutStrategy,
                               sparse=showEmpty, min=minSize, max=maxSize, thr=threshold, terms="-".join(terms), min_term_size=min_term_size,
                               max_term_size=max_term_size, gpversion=gpversion, user=user, hash=hash, user_hash=hash)




# Additional APIs


# Ask the status of processing the data

@app.route('/funcexplorer/status/<task_id>')
def taskstatus(task_id):
    task = get_url_data.AsyncResult(task_id)
    if task.state == "PENDING":
        # job didnt start yet
        response = {"state": task.state, "status": "Pending..."}
    elif task.state != "FAILURE":
        response = {"state": task.state, "status": task.info.get("status", "")}
    else:
        # something went wrong in the background job
        response = {"state": task.state, "status": str(task.info)}  # shows exception raised
    return jsonify(response)


@app.route('/funcexplorer/error')
def error():
    return render_template('error.html')


# Gene search for AJAX query


@app.route('/funcexplorer/_search_genes')
def search_genes():
    cache_user = app.config['DATABASES']['cache']['USER']
    dbname = app.config['DATABASES']['cache']['DBNAME']
    host = app.config['DATABASES']['cache']['HOST']

    conn_string = "host='%s' dbname='%s' user='%s'" % (host, dbname, cache_user)
    cache_conn = psycopg2.connect(conn_string)
    cursor = cache_conn.cursor()

    genes = request.args.get('genes', None, type=str)
    organism = request.args.get('organism', None, type=str)
    namespace = request.args.get('namespace', None, type=str)
    hash_param = request.args.get('hash_param', None, type=str)
    sparse = request.args.get('sparse', None, type=int)

    query = [x.strip().encode('utf8') for x in genes.split('; ')]  # list with queries (gene names or affy_ids)
    # convert to affy_id
    res = gp.gconvert(query, organism=organism, target=namespace)  # list of lists with the results

    #find the dense node
    q = """SELECT json_data FROM vishic_results WHERE hash_id='%s';""" % (hash_param,)
    cursor.execute(q)
    records = cursor.fetchall()[0]
    json_path = records[0].get("result", None)
    gc_results = []
    if os.path.exists(json_path):
        tree = Tree(json_path+".nw", format=1)
        denses = tree.search_nodes(status="D")
        if sparse:
            denses = denses + tree.search_nodes(status="S")
        for r in res:
            if r[3]:
                d_node = [n.name for n in denses if r[3] in [leaf.name.upper() for leaf in n.iter_leaves()]]
                gc_results.append({"query": r[1], "affy_id": r[3], "node_id": d_node[0] if len(d_node)>0 else None})
            else:
                d_node = [n.name for n in denses if r[1] in [leaf.name for leaf in n.iter_leaves()]]
                gc_results.append({"query": r[1], "affy_id": r[1], "node_id": d_node[0] if len(d_node)>0 else None})

    else:
        gc_results = [{"query": r[1], "affy_id": r[3], "node_id":None} if r[3] else {"query": r[1], "affy_id": r[1], "node_id": None} for r in
                  res]  # query: affy_id, upper cases
    return json.dumps(gc_results)


# Term search for AJAX query


@app.route('/funcexplorer/_search_terms')
def search_terms():
    q_terms = request.args.get('q_terms', None, type=str)
    hash_param = request.args.get('hash', type=str)

    query = filter(None, [x.strip().encode('utf8') for x in q_terms.split('; ')])  # list with queries

    user = app.config['DATABASES']['cache']['USER']
    dbname = app.config['DATABASES']['cache']['DBNAME']
    host = app.config['DATABASES']['cache']['HOST']

    conn_string = "host='%s' dbname='%s' user='%s'" % (host, dbname, user)
    cache_conn = psycopg2.connect(conn_string)
    cursor = cache_conn.cursor()

    q = """SELECT annot_data FROM vishic_results WHERE hash_id='%s';""" % (hash_param,)
    cursor.execute(q)
    records = cursor.fetchall()[0]
    annotations = pd.DataFrame(records[0])  # dataframe
    # Find nodes
    results = \
        annotations[
            (annotations.status == "D") & ((annotations['descr'].isin(query)) | (annotations['t_id'].isin(query)))][['node_id', 't_id', 'descr', 'pval']]
    not_found = [{"t_id": q, "node_id": []} for q in query if not results.isin([q]).any().any()]
    term_results = results.groupby(['t_id','descr'], as_index=False)['node_id','pval'].agg(lambda x: tuple(x)).to_dict("records")
    #term_results = results.groupby(['t_id', 'descr'])['node_id'].apply(list).reset_index().to_dict("records")
    term_results = term_results + not_found
    return json.dumps(term_results)

@app.route('/funcexplorer/_search_terms_in_nodes')
def search_terms_in_nodes():
    q_terms = request.args.get('q_terms', None, type=str)
    hash_param = request.args.get('hash', type=str)

    query = filter(None, [x.strip().encode('utf8') for x in q_terms.split('; ')])  # list with queries

    user = app.config['DATABASES']['cache']['USER']
    dbname = app.config['DATABASES']['cache']['DBNAME']
    host = app.config['DATABASES']['cache']['HOST']

    conn_string = "host='%s' dbname='%s' user='%s'" % (host, dbname, user)
    cache_conn = psycopg2.connect(conn_string)
    cursor = cache_conn.cursor()

    q = """SELECT annot_data FROM vishic_results WHERE hash_id='%s';""" % (hash_param,)
    cursor.execute(q)
    records = cursor.fetchall()[0]
    annotations = pd.DataFrame(records[0])  # dataframe
    # Find nodes
    results = \
        annotations[((annotations['descr'].isin(query)) | (annotations['t_id'].isin(query)))][
            ['node_id', 't_id', 'descr', 'pval']]
    not_found = [{"t_id": q, "node_id": []} for q in query if not results.isin([q]).any().any()]
    term_results = results.groupby(['t_id', 'descr'], as_index=False)['node_id', 'pval'].agg(
        lambda x: tuple(x)).to_dict("records")
    # results = annotations[((annotations['descr'].isin(query)) | (annotations['t_id'].isin(query)))][
    #     ['node_id', 't_id', 'descr']]
    # not_found = [{"t_id": q, "node_id": []} for q in query if not results.isin([q]).any().any()]
    # term_results = results.groupby(['t_id', 'descr'])['node_id'].apply(list).reset_index().to_dict("records")
    term_results = term_results + not_found
    return json.dumps(term_results)


# Create short links

@app.route('/funcexplorer/_create_short', methods=['POST'])
def create_shortlink():
    long_url = request.form['long_url']
    short_url = create_short(long_url, HASHTABLE_NAME)
    return json.dumps({"short_url": short_url})


# Redirect from short links

@app.route('/funcexplorer/link/<short>')
def redirect_shortlink(short):
    # get the long url from hashtable
    hashtable = pickle.load(open(HASHTABLE_NAME, "rb"))
    long_url = hashtable.get(short, "https://biit.cs.ut.ee/funcexplorer/")
    return redirect(long_url)

# Import data table from main summary
@app.route('/funcexplorer/_summary_data', methods=['POST'])
def summary_data():
    res = {"table": ""}
    return json.dumps(res)

# Validate the SOFT file before upload


@app.route('/funcexplorer/_validate_soft', methods=['POST'])
def validate_soft():
    try:
        organism = request.form['organism']
        inputfile = request.files['file']
        numeric_ns = request.form['numeric_ns']
        filename = secure_filename(inputfile.filename)
        filename = filename.split(".")[0]
        test_filename = filename + "_test.SOFT"
        soft_filename = os.path.join(app.root_path, app.config['UPLOAD_FOLDER'], test_filename)
        # Save the SOFT file
        inputfile.save(soft_filename)
        # select the gene IDs and convert them
        gds = GEOparse.get_GEO(filepath=soft_filename)
        if type(gds) == GEOparse.GEOTypes.GDS:
            df = gds.table  # pandas dataframe with expression value
            gene_ids = "ID_REF"
            other_id = "IDENTIFIER"
            gene_id1 = df[gene_ids].tolist()
            gene_id2 = df[other_id].tolist()
            res1 = gp.gconvert(gene_id1, organism=organism, numeric_ns=numeric_ns)
            res1 = [r[3] for r in res1 if r[3] and r[2] == str(r[0]) + ".1"]
            res2 = gp.gconvert(gene_id2, organism=organism, numeric_ns=numeric_ns)
            res2 = [r[3] for r in res2 if r[3] and r[2] == str(r[0]) + ".1"]
            prop1 = int(len(gene_id1) / len(res1) * 100) if len(res1) > 0 else 0
            prop2 = int(len(gene_id2) / len(res2) * 100) if len(res2) > 0 else 0
            soft_message = "g:Convert recognises %s%% of IDs from the gene ID reference %s and %s%% from %s.\nPlease select the preferred reference of gene IDs." % (
                prop1, gene_ids, prop2, other_id)
            select = True
        if type(gds) == GEOparse.GEOTypes.GSE:
            df = gds.pivot_samples('VALUE')
            df.reset_index(level=[0], inplace=True)  # set ID_REF as column not index
            gene_id1 = df[df.columns[0]].tolist()
            res1 = gp.gconvert(gene_id1, organism=organism, numeric_ns=numeric_ns)
            res1 = [r[3] for r in res1 if r[3] and r[2] == str(r[0]) + ".1"]
            prop1 = int(len(gene_id1) / len(res1) * 100) if len(res1) > 0 else 0
            soft_message = "g:Convert recognises %s%% of IDs from the existing gene ID reference %s.\nIf this is suitable for you, proceed with the upload." % (
                prop1, df.columns[0])
            select = False
        # Delete the test file
        os.remove(soft_filename)
    except Exception as e:
        select = False
        soft_message = "We couldn't read Your SOFT file. Make sure that the fileformat is GDS or GSE.\n Error message: %s" %(e)
    return json.dumps({"message": soft_message, "select_id": select})


# Create download image

@app.route('/funcexplorer/_download_img', methods=['POST'])
def download_png():
    base64str = request.form["base64_string"]
    img_name = request.form["img_name"]
    img_path = os.path.join("static/tmp/download_imgs", img_name)
    imgdata = base64.b64decode(base64str)
    with open(img_path, 'wb') as f:
        f.write(imgdata)
    res = {"img": img_name}
    return json.dumps(res)



# Uploading page


@app.route('/funcexplorer/upload', methods=['GET', 'POST'])
def upload():
    if request.method == 'POST':
        # Read the parameters
        name = request.form.get('name', '')
        email = request.form.get('email', '')
        inputfile = request.files['fileToUpload']
        filetype = request.form['file_type'] # soft or tab
        organism = request.form['organism']
        log = request.form.get('log', None) # perform log10 transform
        transf = request.form.get("transf", None) # center, standardize, ""
        descr = request.form['descr'] # data description free text
        datatype = request.form['data_type'] # microarray or RNAseq
        numeric_ns = request.form['numeric_ns'] # numeric IDs
        cl_cols = request.form.get('cl_cols', type=int)  # 1 or 0
        bg = request.form['bg']  # ds, genome or other selections
        remove_nans = request.form.get('impute_na', None) # how to handle NAs
        # Make sure to have correct encoding of strings
        if descr:
            descr = descr.encode('utf-8')
        if organism:
            organism = organism.encode('utf-8')
        if transf:
            transf = transf.encode('utf-8')
        if bg:
            bg = bg.encode('utf-8')
        if numeric_ns:
            numeric_ns = numeric_ns.encode('utf-8')

        # Make sure that the file was included
        if inputfile:
            # deal with parameters of separate data types
            if datatype == "rna":
                norm_method = request.form.get('rna_norm', None)
                if norm_method == "log2":
                    pseudocount = request.form.get('pseudocount', 1, type=float)
                else:
                    pseudocount = None
            else:
                norm_method = None
                pseudocount = None
            if filetype == "custom":
                delimiter = request.form['delimiter']
                if delimiter == "space":
                    delimiter = " "
                else:
                    delimiter = "\t"
                gene_ids = None
            else:
                gene_ids = request.form['gene_id'] # ID_REF or other
                delimiter = None
            # if impute method is selected
            if remove_nans:
                impute_method = request.form.get('impute', None)
                if impute_method and impute_method == "fixed":
                    fix_value = request.form.get("fixed_value", 0, type=float)
                else:
                    fix_value = 0
            else:
                impute_method = None
                fix_value = 0
            # Create the unique filename and check if it is possible to process
            # Extract the dataset name from filename
            filename = secure_filename(inputfile.filename)
            ds_name, file_extension = os.path.splitext(filename)
            ds_name = basename(ds_name)
            ds_name = ds_name.encode('utf-8')
            # Create unique ds_id
            ds_id = generate_unique_filename(ds_name)
            # Create user identificator
            email_hash = generate_user_path(email, ds_id)
            # add paths etc
            path_filename = os.path.join(app.root_path, app.config['UPLOAD_FOLDER'], ds_id)
            if filetype == "soft":
                path_filename = path_filename + ".SOFT"
            # Process the data
            # http://biit.cs.ut.ee/preprocess
            message, success = upload_file(inputfile, ds_id, ds_name, name, organism, transf, bg, cl_cols,
                                           gene_ids, descr, email, email_hash, path_filename, filetype, delimiter,
                                           impute_method, fix_value, norm_method, pseudocount, numeric_ns, log, datatype)
        else:
            message = "Please make sure that you uploaded the data file."
            success = False
        return render_template("uploadpage.html", bgs=BACKGROUNDS, numeric_ns=NUMERIC_NS, organisms=ORGANISMS,
                               success=success, message=message)

    else:
        return render_template("uploadpage.html", bgs=BACKGROUNDS, numeric_ns=NUMERIC_NS, organisms = ORGANISMS)


# About page


@app.route('/funcexplorer/about')
def about():
    return render_template("aboutpage.html")


# Contact page


@app.route('/funcexplorer/contact', methods=['GET', 'POST'])
def contact():
    # remove files from static/tmp folder older than 1 day (spambot pictures)
    ID_image, ID_pass_hidden = create_identification_image()
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        subject = request.form['subject']
        message = request.form['message']
        control = request.form['ID_image']
        ID = request.form["ID_string"]
        control = str(control)
        img_name = pass_img(control)
        control_ID = pass_hidden(img_name)
        if control_ID == ID:
            if name and email and message:
                recipient = ["Liis Kolberg", "liis.kolberg@ut.ee"]
                from_address = [name, email]
                subject = 'funcExplorer support: ' + subject
                subject = subject.decode('unicode-escape')

                msg = MIMEMultipart('related')
                msg['Subject'] = "%s" % Header(subject, 'utf-8')
                msg['From'] = "\"%s\" <%s>" % (Header(from_address[0], 'utf-8'), from_address[1])
                msg['To'] = "\"%s\" <%s>" % (Header(recipient[0], 'utf-8'), recipient[1])
                msg.preamble = 'This is a multi-part message in MIME format.'

                msgAlt = MIMEMultipart('alternative')

                textpart = MIMEText(message, 'plain', 'UTF-8')
                msgAlt.attach(textpart)
                msg.attach(msgAlt)
                s = smtplib.SMTP('mailhost.ut.ee')
                s.sendmail(from_address[1], recipient[1], msg.as_string())
                s.quit()
                message = "Your message was sent successfully!"
                return render_template("contactpage.html", success=True, message=message,
                                       image="tmp/" + ID_image + ".png")
            else:
                message = "Please fill all the fields!"
                return render_template("contactpage.html", success=False, message=message,
                                       image="tmp/" + ID_image + ".png", string=ID_pass_hidden)
        else:
            message = "Human interface identification failed, please type contents of the anti-spam image!"
            return render_template("contactpage.html", success=False, message=message, image="tmp/" + ID_image + ".png",
                                   string=ID_pass_hidden)
    else:
        return render_template("contactpage.html", image="tmp/" + ID_image + ".png", string=ID_pass_hidden)


if __name__ == '__main__':
    app.secret_key = KEY["app"]
    app.run(debug=False, threaded=True)
