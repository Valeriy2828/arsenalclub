# From R package WGCNA, moduleEigengenes
# expr, clusters, nPC = 1, align = "along average", scale=T

import numpy as np
import pandas as pd

# For one cluster
def eigengene(subexpr, scale=True):
    # subexpr is the sub expression matrix with genes in rows and samples in columns from given cluster
    # returns list [eigengene]
    #subexpr = subexpr.as_matrix()
    U, s, V = np.linalg.svd(subexpr, full_matrices=False)
    pc1 = V[0, :]  # first principle component
    # correlation with average expression (if negative, then turn the pc around)
    scaledExpr = (subexpr - np.mean(subexpr, axis=1, keepdims=True)) / np.std(subexpr, axis=1, keepdims=True)
    averExpr = np.mean(scaledExpr, axis=0)
    corAve = np.corrcoef(averExpr, pc1)[0, 1]
    if not np.isfinite(corAve):
        corAve = 0
    if corAve < 0:
        pc1 = -pc1
    return list(pc1)

# For full dataset
def eigengenes(expressions, clusters, node2labels, scale=True):
    # returns dictionary {cl_id: [eigengene]}
    res = {}
    for cl in clusters:
        gene_ids = node2labels.get(cl, 0)
        subexpr = []
        for g_id in gene_ids:
            ex = expressions.get(g_id, 0)
            subexpr.append(ex)
        U, s, V = np.linalg.svd(subexpr, full_matrices=False)
        pc1 = V[0, :]  # first principle component
        # correlation with average expression (if negative, then turn the pc around)
        if scale:
            scaledExpr = (subexpr - np.mean(subexpr, axis=1, keepdims=True)) / np.std(subexpr, axis=1, keepdims=True)
            averExpr = np.mean(scaledExpr, axis=0)
        else:
            averExpr = np.mean(subexpr, axis=0)
        corAve = np.corrcoef(averExpr, pc1)[0, 1]
        if not np.isfinite(corAve):
            corAve = 0
        if corAve < 0:
            pc1 = -pc1
        res[cl] = list(pc1)
    return res