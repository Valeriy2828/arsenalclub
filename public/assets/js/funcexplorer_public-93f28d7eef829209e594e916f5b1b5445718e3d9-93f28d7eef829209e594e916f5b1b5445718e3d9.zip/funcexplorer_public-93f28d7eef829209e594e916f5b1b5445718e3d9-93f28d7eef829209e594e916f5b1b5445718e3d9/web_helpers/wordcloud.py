# Create annotation wordcloud
import numpy as np

def create_wordcloud(annotations, top_n=10, term_length = False):
    # annotations is annotations data frame (sorted by p-value)
    # select top 10 annotations and get the descriptions and scores
    # word size is proportional to -log10(pvalue)
    # Dense nodes
    dense_nodes = annotations[annotations.status == "D"]
    best_score = -np.log10(min(dense_nodes.pval))
    if term_length:
        cloud_data = {k: [{"t_id": x.t_id, "full_text": x.descr, "text": x.descr[0:term_length] + "...", "size": -np.log10(x.pval), "t_type": x.t_type, "pval": x.pval} if len(x.descr)>term_length else {"text": x.descr, "size": -np.log10(x.pval), "t_type": x.t_type} for x in v.head(top_n).itertuples()] for k, v in dense_nodes.groupby("node_id")}
    else:
        cloud_data = {
        k: [{"t_id": x.t_id, "text": x.descr, "full_text": x.descr, "size": -np.log10(x.pval), "t_type": x.t_type, "pval": x.pval} for x in v.head(top_n).itertuples()] for k, v in
        dense_nodes.groupby("node_id")}
    # returns frequency list of dictionaries for every dense node
    return cloud_data, best_score