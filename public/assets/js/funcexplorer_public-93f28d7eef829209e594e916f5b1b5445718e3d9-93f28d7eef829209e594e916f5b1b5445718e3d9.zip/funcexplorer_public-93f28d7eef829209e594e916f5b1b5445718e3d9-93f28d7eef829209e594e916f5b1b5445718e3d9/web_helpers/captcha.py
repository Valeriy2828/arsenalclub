import random
# pip install pillow
from PIL import Image, ImageFont, ImageDraw, ImageFilter
import os
import hashlib

def gen_captcha(text, fnt, fnt_sz, file_name, fmt='PNG'):
    """Generate a captcha image"""
    # randomly select the foreground color
    fgcolor = random.randint(0, 0xffff00)
    # make the background color the opposite of fgcolor
    bgcolor = fgcolor ^ 0xffffff
    # create a font object
    font = ImageFont.truetype(fnt, fnt_sz)
    # determine dimensions of the text
    dim = font.getsize(text)
    # create a new image slightly larger that the text
    im = Image.new('RGB', (dim[0] + 5, dim[1] + 5), bgcolor)
    d = ImageDraw.Draw(im)
    x, y = im.size
    r = random.randint
    # draw 10 random colored boxes on the background
    #for num in range(5):
    #    d.rectangle((r(0, x), r(0, y), r(0, x), r(0, y)), fill=r(0, 0xffffff))
    # add the text to the image
    d.text((3, 3), text, font=font, fill=fgcolor)
    im = im.filter(ImageFilter.EDGE_ENHANCE_MORE)
    # save the image to a file
    im.save(file_name, format=fmt)

def gen_random_word(wordLen=5):
    allowedChars = "abcdefghijklmnopqrstuvwzyzABCDEFGHIJKLMNOPQRSTUVWZYZ0123456789"
    word = ""
    for i in range(0, wordLen):
        word = word + allowedChars[random.randint(0, 0xffffff) % len(allowedChars)]
    return word

def pass_hidden(IDpass):
    return hashlib.md5(IDpass + ".viShIc2").hexdigest()

def pass_img(word):
    return hashlib.md5(word.strip() + "_ViSHiC2").hexdigest()

def create_identification_image():
    word = gen_random_word()
    ID_image = pass_img(word)
    ID_pass_hidden = pass_hidden(ID_image)
    gen_captcha(word.strip(), 'static/fonts/Arial.ttf', 20, os.path.join("static/tmp", ID_image + ".png"))
    return ID_image, ID_pass_hidden


if __name__ == '__main__':
    """Example: This grabs a random word from the dictionary 'words' (one
    word per line) and generates a jpeg image named 'test.jpg' using
    the truetype font 'porkys.ttf' with a font size of 20.
    """
    word = gen_random_word()
    gen_captcha(word.strip(), 'static/fonts/Arial.ttf', 20, "static/tmp/test.png")
