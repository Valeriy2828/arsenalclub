
# removes any files in static/tmp/ older than 3 days
import os, time
import psycopg2

DATABASES = {'cache':
    {
        'USER': 'vishic',
        'DBNAME': 'vishic_cache',
        'HOST': 'db'
    }}


def trim(folder, days=3):
    now = time.time()
    cutoff = now - (days * 86400)

    files = os.listdir(folder)

    for xfile in files:
        if not ".log" in xfile and not "big_imgs" in xfile:
            filepath = os.path.join(folder, xfile)
            if os.path.isfile(filepath):
                t = os.stat(filepath)
                c = t.st_mtime  # Time of last modification

                # delete file if older than x days
                if c < cutoff:
                    os.remove(filepath)


# empty cache database
cache_user = DATABASES['cache']['USER']
dbname = DATABASES['cache']['DBNAME']
host = DATABASES['cache']['HOST']
conn_string = "host='%s' dbname='%s' user='%s'" % (host, dbname, cache_user)
cache_conn = psycopg2.connect(conn_string)
cache_cur = cache_conn.cursor()
cache_cur.execute("""DELETE FROM vishic_results WHERE created_at < now() - interval '3 days';""")
cache_conn.commit()
cache_conn.close()

# remove files from static/tmp folder older than 3 days
trim("../static/tmp/", 3)
trim("../static/tmp/big_imgs", 3)

