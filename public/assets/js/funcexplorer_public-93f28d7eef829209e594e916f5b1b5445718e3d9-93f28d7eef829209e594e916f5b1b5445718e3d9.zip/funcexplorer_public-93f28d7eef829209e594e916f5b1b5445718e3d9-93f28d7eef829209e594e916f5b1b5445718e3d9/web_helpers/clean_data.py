# Functions for cleaning the uploaded data before processing
from __future__ import division

import pandas as pd
import sys
sys.path.append('../')
import os
os.environ["THEANO_FLAGS"] = "base_compiledir=/tmp/" #otherwise there are problems with KNN
from fancyimpute import KNN
import numpy as np
import requests
import GEOparse
from gprofiler import GProfiler

gp = GProfiler("funcExplorer/1.0")


def clean_data(data, impute_method=None, fix_value=0):
    # data is pandas dataframe
    # First column needs to be 'genes'!
    # missing values imputing method, if none, then remove rows
    # resulting filename
    # fix_value if method is fixed, then this value is imputed instead of nans
    data_wo = data.ix[:, data.columns != "genes"].apply(pd.to_numeric, errors="coerce")
    # If the whole row is nan, then remove
    #df.astype('float64')
    all_nan = pd.isnull(data_wo).all(1).nonzero()[0]
    data_wo = data_wo.dropna(0, how='all') # remove the nans
    nan_genes = [] # keep the removed row names
    nan_genes.extend(data.iloc[all_nan]["genes"].tolist())
    data = pd.concat([data["genes"][~data.index.isin(all_nan)], data_wo], axis=1)
    # Are there any missing values?
    is_missing = data.isnull().sum().sum() # number of missing values in data
    if is_missing > 0:
        # deal with missing values
        if impute_method:
            # fixed value
            if impute_method=="fixed":
                data = data.fillna(fix_value)
            elif impute_method=="mean":
                data = data.where(pd.notnull(data), data.mean(axis=1).T, axis=0) # replace nans with row means
            elif impute_method=="knn":
                # requires centered and standardized data (rows)
                fill_data = KNN(k=5).complete(data.ix[:, data.columns != "genes"])
                fill_data = np.c_[data["genes"], fill_data]
                data = pd.DataFrame(fill_data, columns=data.columns)
        else:
            na_genes = pd.isnull(data).any(1).nonzero()[0] # rows with nans
            nan_genes.extend(data.iloc[na_genes]["genes"].tolist())
            data = data.dropna(axis=0)
    # remove rows with 0 standard deviation
    sd_null = data.std(axis=1)==0
    if sum(sd_null)>0:
        nan_genes.extend(data[sd_null]["genes"].tolist())
        data.drop(data[sd_null].index, inplace=True)
        # sd_not_null = [not x for x in sd_null]
        # data = data[sd_not_null]
    return data, nan_genes


def upload_file(inputfile, ds_id, ds_name, name, organism, transf, bg, cl_cols, gene_ids, descr, email, email_hash, path_filename, filetype, delimiter, impute_method, fix_value, norm_method, pseudocount, numeric_ns, log, datatype):
    # check if the file already exists
    if os.path.isfile(path_filename):
        message = "The file %s already exists in the database.\n" % ds_name
        message = message + "Please try another file name."
        success = False
        return message, success
    else:
        # inputfile is the uploaded data
        if filetype == "custom":
            # data to dataframe
            data = pd.read_table(inputfile, sep=delimiter, comment="#", header = 0, skip_blank_lines=True, index_col=0)
        elif filetype == "soft":
            # Save the SOFT file
            inputfile.save(path_filename) # unique file id with path
            gds = GEOparse.get_GEO(filepath=path_filename) # This will read the file into GDS object
            if type(gds) == GEOparse.GEOTypes.GDS:
                data = gds.table # pandas dataframe with expression values
                values = ["ID_REF", "IDENTIFIER"]
                remove = [x for x in values if x!=gene_ids][0]
                del data[remove]
                if not descr:
                    descr = str(gds.metadata.get("description", [""])[0])
            if type(gds) == GEOparse.GEOTypes.GSE:
                data = gds.pivot_samples('VALUE')
                data.reset_index(level=[0], inplace=True) # set ID_REF as column not index

        # was the separator right or SOFT file correct?
        # only one column indicates wrong separator
        if data.shape[1] < 2:
            message = "The file format seems to be unsuitable.\n"
            if filetype == "custom":
                message = message + "Please make sure that you selected correct field delimiter or that your comments are added after #."
            else:
                message = message + "We accept only SOFT files with GDS or GSE format."
            success = False
            os.remove(path_filename)
            return message, success
        # If data has less than 5 columns, then it is not suitable for correlation
        if data.shape[1] < 5:
            message = "The data has too few samples for analysis. We detected {t} columns.\n".format(t=data.shape[1])
            success = False
            os.remove(path_filename)
            return message, success

        # Lines up to keyword "gene" or "genes" and without # are track annotations

        # rename first column
        if type(data.index) != pd.core.indexes.range.RangeIndex:
            data.reset_index(inplace=True)
            data.rename(columns={'index': 'genes'}, inplace=True)

        cols = data.columns.tolist() # column names
        if not "genes" in cols:
            cols[0] = "genes"  # make sure that first column is genes
            col_dict = dict(zip(data.columns.tolist(), cols))
            data.rename(columns=col_dict, inplace=True)

        # Check if gprofiler knows the gene id-s
        know_ids = gp.gconvert(data.genes, organism=organism, numeric_ns=numeric_ns)
        know_ids = pd.DataFrame(know_ids)
        know_ids = know_ids.drop_duplicates(subset=1)
        unknown_ids = sum(pd.isnull(know_ids[3]))/len(data.genes)
        if unknown_ids > 0.7:
            message = "g:Profiler did not recognise {0:.0f}% of the gene identifiers in the file.\n".format(unknown_ids*100)
            message = message + "Please make sure if the selected organism is valid or if Your identifier is accepted in g:Profiler."
            success = False
            return message, success

        # Check if are fully numeric id-s
        all_numeric = [s.isdigit() for s in data.genes]
        if all(all_numeric):
            numeric_ns = numeric_ns
        else:
            numeric_ns = ""
        # deal with NAs
        try:
            data, nan_genes = clean_data(data, impute_method, fix_value)
            # Write data to tab separated file
            data.to_csv(path_filename.split(".")[0], sep="\t", index=False)

            dataToSend = {"ds_id": ds_id, "name": name, "email": email, "ds_name": ds_name, "email_hash": email_hash, "user": True, "organism": organism, "transform": transf, "log": log, "bg": bg, "cl_cols": cl_cols, "descr": descr, "norm_method": norm_method, "pseudocount": pseudocount, "numeric_ns": numeric_ns, "fix_value": fix_value, "impute_method": impute_method, "datatype": datatype}

            message = "Your data was uploaded successfully. Number of excluded rows due to the missing values and/or zero standard deviation: %s" % (len(nan_genes))
            res = requests.post('https://biit.cs.ut.ee/preprocess/', json=dataToSend)
            response = res.text
            if "Job submitted" in response and email:
                message = message + ".\nWe will send the notification togehter with the access URL to e-mail: %s when preprocessing is finished." % email
                success = True
            elif "Job submitted" in response and not email:
                user_link = "https://biit.cs.ut.ee/funcexplorer/user/"+email_hash
                message = message + """.\nYou can access the results in: <a href="%s" target="_blank">%s</a> when preprocessing is finished.""" % (user_link, user_link)
                success = True
            else:
                message = message + ", but something happened while trying to analyse the data.\n"
                message = message + "Please try again or contact us in biit.support@ut.ee for help."
                success = False
                # delete the file
                os.remove(path_filename)
        except ValueError as e:
            message = "Something went wrong with data upload.\n"
            message = message + "Error: %s\n" % e
            message = message + "Please check your file and selected parameters or contact us in biit.support@ut.ee for help."
            success = False
            os.remove(path_filename)
    return message, success







