#!/bin/bash

cd /app/web_helpers && python run_public_datasets.py