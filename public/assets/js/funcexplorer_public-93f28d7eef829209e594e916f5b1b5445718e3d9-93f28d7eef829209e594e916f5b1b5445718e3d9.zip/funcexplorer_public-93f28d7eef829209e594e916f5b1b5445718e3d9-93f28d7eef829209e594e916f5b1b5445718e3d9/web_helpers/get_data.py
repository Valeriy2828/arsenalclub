# helper functions for getting the data from cached db

import pandas as pd
import os
import json
import gzip
from ete3 import Tree
from tree2json.tree2json import node2json
from gprofiler import GProfiler
from datetime import datetime
from Eigengene import eigengene, eigengenes
from wordcloud import create_wordcloud

gp = GProfiler("funcExplorer/1.0")

def recover_key(node2labels, clusters, value):
    for cl in clusters:
        if (value in node2labels.get(cl, 0) or value.lower() in node2labels.get(cl, 0)):
            return cl.split("_")[1]

def get_data_for_treeview(ds_id, vishic_hash, conn, cache_conn, node_id, logging):
    # Select dataset info from original db
    startTime = datetime.now()
    ds_data_sql = """SELECT * FROM dataset WHERE ds_id='{t}';""".format(t=ds_id)  # dataset descriptive info
    ds_data = pd.read_sql_query(ds_data_sql, conn).to_dict("records")[0]
    # Gene data
    gene_sql = """SELECT * FROM genes WHERE ds_id='{t}';""".format(t=ds_id)
    genes_data = pd.read_sql_query(gene_sql, conn).to_dict("records")
    timeElapsed = datetime.now() - startTime
    logging.info('%s: Time taken for db query (hh:mm:ss.ms) {}'.format(timeElapsed), ds_id)
    # Array list for heatmap
    ds_list = ds_data["ds_list"]
    conn.close()
    # take data from cache db
    c = cache_conn.cursor()
    sql = """SELECT json_data, minmax, stat_data, track_data, annot_data, expressions FROM vishic_results WHERE hash_id='%s';""" % (vishic_hash,)
    c.execute(sql)
    records = c.fetchall()[0]
    json_path = records[0].get("result", "")
    # check just in case if file exists
    if os.path.exists(json_path):
        # standard view data
        minmax = records[1]
        track_data = records[3]
        annotations = pd.DataFrame(records[4])  # dataframe, already sorted by pval
        expressions = records[5]
        if node_id:
            startTime = datetime.now()
            tree = Tree(json_path + ".nw", format=1)
            timeElapsed = datetime.now() - startTime
            logging.info('%s: Time taken for tree reading (hh:mm:ss.ms) {}'.format(timeElapsed), ds_id)
            startTime = datetime.now()
            node = tree & "NODE_" + node_id
            gene_ids = [x.upper() for x in node.get_leaf_names()] # genes in the node
            node_annotations = annotations[annotations.node_id == "NODE_" + node_id].to_dict('records')
            timeElapsed = datetime.now() - startTime
            logging.info('%s: Time taken for getting annotations (hh:mm:ss.ms) {}'.format(timeElapsed), ds_id)
            # Term list for term search autocomplete
            term_names = annotations[['t_id', 'descr']].set_index('descr')['t_id'].to_dict()
            # Gene list
            gene_names = [(g["gene_id"], g["gene_name"]) for g in genes_data]
            gene_names = [g for l in gene_names for g in l]
            gene_names = filter(None, gene_names)
            gene_names = list(set(gene_names))  # remove duplicates
            gene_names.sort()
            genes_data = pd.DataFrame(genes_data)
            node_genes = genes_data[genes_data["gene_id"].isin(gene_ids)].to_dict("record")
            ####
            startTime = datetime.now()
            gb = annotations.groupby(['node_id', 't_type']).first()

            hashtable = {}
            for index, row in gb.iterrows():
                node_id = index[0]
                other = {}
                other['t_type'] = index[1]
                other['pval'] = row['pval']
                other['t_id'] = row['t_id']
                other['score'] = row['score']
                other['descr'] = row['descr']
                other['value'] = row['value']
                other['t_size'] = row['t_size']
                other['hasuniq'] = row['hasuniq']
                other['unique'] = row['unique']
                hashtable.setdefault(node_id, []).append(other)

            timeElapsed = datetime.now() - startTime
            logging.info('%s: Time taken for hashtable(hh:mm:ss.ms) {}'.format(timeElapsed), ds_id)
            startTime = datetime.now()
            #expressions = records[5]
            timeElapsed = datetime.now() - startTime
            logging.info('%s: Time taken for expressions(hh:mm:ss.ms) {}'.format(timeElapsed), ds_id)
            # find eigengenes
            startTime = datetime.now()
            subexpr = []
            gene_ids2 = [x for x in node.get_leaf_names()]
            for g_id in gene_ids2:
                ex = expressions.get(g_id, 0)
                subexpr.append(ex)
            eigengene_val = eigengene(subexpr) # list of values for eigengene
            timeElapsed = datetime.now() - startTime
            logging.info('%s: Time taken for eigengene(hh:mm:ss.ms) {}'.format(timeElapsed), ds_id)
            #with open('/tmp/test.txt', 'w') as f:
            #    f.write(json.dumps(eigengene_out))

            # node tree
            startTime = datetime.now()
            json_data = node2json(node, hashtable, expressions)
            timeElapsed = datetime.now() - startTime
            logging.info('%s: Time taken for json(hh:mm:ss.ms) {}'.format(timeElapsed), ds_id)
            startTime = datetime.now()
            json_data = json.dumps(json_data)
            timeElapsed = datetime.now() - startTime
            logging.info('%s: Time taken for dumps (hh:mm:ss.ms) {}'.format(timeElapsed), ds_id)
            # gprofiler query
            gpq = "+".join(gene_ids)
            gp_url = "//biit.cs.ut.ee/gprofiler/index.cgi?organism=%s&query=%s&r_chr=X&r_start=start&r_end=end&analytical=1&domain_size_type=annotated&term=&significant=1&sort_by_structure=1&user_thr=1.00&output=png&prefix=ENTREZGENE_ACC" % (
            ds_data["organism"], gpq)
            c.close()
            cache_conn.close()
            return {"gene_names": gene_names, "minmax": minmax, "term_names": term_names, "gp_url": gp_url,
                    "ds_data": ds_data, "json_data": json_data, "ds_list": ds_list, "track_data": track_data,
                    "node_genes": node_genes, "node_annotations": node_annotations, "eigengene": eigengene_val}

        else:
            startTime = datetime.now()
            stat_data = records[2]
            unique = annotations[annotations.unique == True].to_dict('records')
            # Gene names for gene search autocomplete
            gene_names = [(g["gene_id"], g["gene_name"]) for g in genes_data]
            gene_names = [g for l in gene_names for g in l]
            gene_names = filter(None, gene_names)
            gene_names = list(set(gene_names))  # remove duplicates
            gene_names.sort()
            # Term list for term search autocomplete
            term_names = annotations[(annotations.status == "D")][['t_id', 'descr']].set_index('descr')[
                't_id'].to_dict()
            # Read in json data of tree
            with gzip.GzipFile(json_path, 'rb') as resfile:
                json_data = json.load(resfile)
            json_data = json.dumps(json_data)
            timeElapsed = datetime.now() - startTime
            logging.info('%s: Time taken for data read in (hh:mm:ss.ms) {}'.format(timeElapsed), ds_id)
            startTime = datetime.now()
            tree = Tree(json_path + ".nw", format=1)
            node2labels = tree.get_cached_content(store_attr="name", container_type=type([]))  # dictionary with leaf names for each node (speeds up?)
            node2labels = {n.name: v for n, v in node2labels.items()}
            dense_nodes = annotations[annotations.status == "D"]
            clusters = dense_nodes.node_id.unique().tolist() # list of dense cluster ids
            # Get cluster ID for genes
            for g in genes_data:
                g["cl_id"] = recover_key(node2labels, clusters, g["gene_id"])
            timeElapsed = datetime.now() - startTime
            logging.info('%s: Time taken for getting cl id for every gene (hh:mm:ss.ms) {}'.format(timeElapsed), ds_id)
            startTime = datetime.now()
            # Eigengenes
            eigengene_val = eigengenes(expressions, clusters, node2labels, False)
            timeElapsed = datetime.now() - startTime
            logging.info('%s: Time taken for eigengene data (hh:mm:ss.ms) {}'.format(timeElapsed), ds_id)
            startTime = datetime.now()
            wordcloud_data, best_score = create_wordcloud(annotations, top_n=10, term_length = False)
            timeElapsed = datetime.now() - startTime
            logging.info('%s: Time taken for wordcloud data (hh:mm:ss.ms) {}'.format(timeElapsed), ds_id)
            c.close()
            cache_conn.close()
            return {"minmax": minmax, "ds_data": ds_data, "json_data": json_data, "ds_list": ds_list,
                    "unique": unique, "stat_data": stat_data, "gene_names": gene_names, "track_data": track_data,
                    "term_names": term_names, "genes": genes_data, "wordcloud": wordcloud_data, "best_score": best_score, "eigengene":eigengene_val}

