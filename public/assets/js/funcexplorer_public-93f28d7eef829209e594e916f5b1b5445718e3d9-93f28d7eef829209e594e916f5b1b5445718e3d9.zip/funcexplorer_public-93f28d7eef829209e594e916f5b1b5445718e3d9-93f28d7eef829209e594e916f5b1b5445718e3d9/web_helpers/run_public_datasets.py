#!/usr/bin/python

# scripts to run preprocessing of public datasets

import pickle
import requests
import time

data = pickle.load(open("/app/data/databases/data0711.pkl")) # dictionary, {organism:[{'ds_name': 'E-GEOD-25267', 'platform': 'A-AFFY-35', 'descr': 'Expression data from third instar larval eye discs', 'samples': 12}]}


i = 0 # counter for nr of datasets annotated
for org in data.keys():
    org_ds = data[org] # list of dictionaries
    for d in org_ds:
        ds_name = d["ds_name"]
        if ds_name in ["Lukk2010", "E-GEOD-25267", "E-GEOD-14779", "E-GEOD-57320", "E-GEOD-39842", "E-GEOD-12012", "E-GEOD-8010", "E-GEOD-48116", "E-GEOD-50182", "E-GEOD-9217", "E-GEOD-31369", "E-GEOD-14748", "E-MEXP-526"]:
            continue
        platform = d["platform"]
        ds_id = "/AE/%s/%s.nc" %(platform, ds_name)
        dataToSend = {"ds_id": ds_id, "name": "", "email": "", "ds_name": ds_name,
                      "user": False, "organism": org, "transform": "mean_stdize", "log": "", "bg": "", "cl_cols": True}
        res = requests.post('https://biit.cs.ut.ee/preprocess/', json=dataToSend)
        response = res.text
        print response
        time.sleep(100)
        i = i + 1
        if i % 3 == 0: # after every 3 datasets make pause
            time.sleep(3000)


