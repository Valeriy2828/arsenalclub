# vishic.py

from ete3 import Tree
from analysis import vishic_analysis
import pandas as pd
import os, sys
import itertools
import numpy as np
from datetime import datetime
import logging

def setup_logger(logger_name, log_file, level=logging.INFO):
    l = logging.getLogger(logger_name)
    formatter = logging.Formatter('%(asctime)s.%(msecs)d %(levelname)s %(module)s - %(funcName)s: %(message)s')
    fileHandler = logging.FileHandler(log_file, mode='a+')
    fileHandler.setFormatter(formatter)
    streamHandler = logging.StreamHandler()
    streamHandler.setFormatter(formatter)

    l.setLevel(level)
    l.addHandler(fileHandler)
    l.addHandler(streamHandler)
    return l

logger = setup_logger('first_logger', 'data/logs/vishic_calc.log')

def vishic2(ds_id, hash_name, conn, params, data_dir, user, self):
    """
    Main function for the analysis:
    ds_id is the unique id of dataset;
    hash_name is the id for selected calculations;
    conn is the Connection object for vishic database;
    params contain calculation parameters like strategy, min, max, etc.
    data_dir is the directory where the data is held
    """
    startTime = datetime.now()
    # Modify file names
    mat_file = ds_id + ".MAT"  # ds_id is the filename
    nwk_file = ds_id + "_%s.nwk" % params["dist"]

    if user:
        nwk_file = os.path.join(data_dir, "nwk_files/user", nwk_file)  # add path to the file
    else:
        nwk_file = os.path.join(data_dir, "nwk_files/vishic", nwk_file)  # add path to the file

    # Check if everything that is needed is there

    # Read in the Newick file to ete3 Tree format
    try:
        tree = Tree(nwk_file, format=1)
    except:
        e = sys.exc_info()[0]
        logger.info('%s: Error is %s' % (ds_id, e))
        raise ValueError("Can't locate requested file: %s" % ds_id)
        sys.exit(1)
    # Not sure, maybe we could compute those in JS (but I hope that here it is faster)
    if user:
        mat_file = os.path.join(data_dir, "mat_files/user",
                                mat_file)  # expression matrix
    else:
        mat_file = os.path.join(data_dir, "mat_files/vishic",
                                mat_file)  # expression matrix

    try:
        mat_df = pd.read_csv(mat_file, sep='\t', index_col="genes")
        expressions = mat_df.T.to_dict("list")
        min_expr = min(mat_df.min(axis=1))  # minimum expression to use in heatmap scale (send to JS)
        max_expr = max(mat_df.max(axis=1))  # maximum expression to use in heatmap scale (send to JS)
        flatten = mat_df.values.flatten()  # flatten value to list
        lower = np.percentile(flatten, 2.5)
        higher = np.percentile(flatten, 97.5)
        count, bin = np.histogram(flatten, bins=20)
        keys = ["count", "bin"]
        hist = [dict(zip(keys, row)) for row in zip(count, bin[:-1])]
        minmax = {"min_expr": min_expr, "max_expr": max_expr, "lower": lower, "higher": higher, "histogram": hist}
    except IOError:
        print "File not found: {}".format(mat_file)
        sys.exit(1)

        # Check if table exists in the database

    cur = conn.cursor()
    cur.execute("""SELECT count(*) FROM dataset WHERE ds_id='{t}';""".format(t=ds_id))
    exists = cur.fetchone()[0]

    # exit if dataset doesn't exist in the database
    if exists == 0:
        print "Dataset not found from database: {}".format(ds_id)
        sys.exit(1)

    # First create dataframe with annotation info
    # Filter out the terms that are under pval threshold or are not in the user selected term list

    # Unpack parameters
    threshold = params["thr"]
    if not threshold:
        threshold = 0.05
    terms = params["terms"]  # ", " separated string
    if terms:
        terms = [x.encode('UTF8') for x in terms.split(", ")]
    min_term_size = params["min_term_size"]
    if not min_term_size:
        min_term_size = 0
    max_term_size = params["max_term_size"]
    if not max_term_size:
        max_term_size = float('inf')
    strategy = params["cut"]
    minsize = params["min"]
    maxsize = params["max"]

    if terms:
        terms_str = repr(terms).replace('[', '(').replace(']', ')')
        sql = """SELECT annotation.node_id, annotation.t_id, annotation.t_size, annotation.q_size, annotation.intersection, annotation.domain_size, annotation.rec, annotation.prec, annotation.pval, annotation.t_list, term.t_type, term.descr, term.domain FROM annotation, term WHERE annotation.hash_name='{t}' AND annotation.t_id=term.t_id AND term.t_type IN {types} AND annotation.pval<={thr} AND annotation.t_size>={min_term_size} AND annotation.t_size<={max_term_size};""".format(
            t=hash_name, types=terms_str, thr=str(threshold), min_term_size=str(min_term_size),
            max_term_size=str(max_term_size))

    else:
        sql = """SELECT annotation.node_id, annotation.t_id, annotation.t_size, annotation.q_size, annotation.intersection, annotation.domain_size, annotation.rec, annotation.prec, annotation.pval, annotation.t_list, term.t_type, term.descr, term.domain FROM annotation, term WHERE annotation.hash_name='{t}' AND annotation.t_id=term.t_id AND annotation.pval<={thr} AND annotation.t_size>={min_term_size} AND annotation.t_size<={max_term_size};""".format(
            t=hash_name, thr=str(threshold), min_term_size=str(min_term_size), max_term_size=str(max_term_size))
    timeElapsed = datetime.now() - startTime
    logger.info('%s: Time taken for parameter settings (hh:mm:ss.ms) {}'.format(timeElapsed), ds_id)
    message = "Collecting the annotations..."
    if self:
        self.update_state(state='PROGRESS',
                          meta={'status': message})
    print sql
    startTime = datetime.now()
    annotations = pd.read_sql_query(sql, conn)
    timeElapsed = datetime.now() - startTime
    logger.info('%s: Time taken for db query (hh:mm:ss.ms) {}'.format(timeElapsed), ds_id)
    startTime = datetime.now()
    logger.info('%s: Shape of annotations is {}'.format(annotations.shape), ds_id)
    if annotations.shape[0]==0:
        message = "No data available"
        self.update_state(state="FAILURE",
                          meta={'status': message})
        return

    # Calculate scores and add them to the tree
    message = "Calculating the annotation scores..."
    if self:
        self.update_state(state='PROGRESS',
                          meta={'status': message})

    if strategy == "best":
        annotations["log10"] = annotations["pval"].apply(lambda x: -np.log10(x))
        scores = annotations.groupby(["node_id"], sort="False")["log10"].max().reset_index().set_index(["node_id"])
        for n in tree.traverse():
            if n.name in scores.index:
                score = scores.get_value(index=n.name, col="log10")
                n.add_features(score=score)

    elif strategy == "max_fc":
        annotations["foldchange"] = annotations["intersection"] * annotations["domain_size"] / (
            annotations["t_size"] * annotations["q_size"])
        scores = annotations.groupby(["node_id"], sort="False")["foldchange"].max().reset_index().set_index(["node_id"])
        for n in tree.traverse():
            if n.name in scores.index:
                score = scores.get_value(index=n.name, col="foldchange")
                n.add_features(score=score)

    elif strategy == "first":
        print "Calculating scores: first"
        node_list = annotations.node_id.unique()

        def first_annotated(node):
            """
            Is_leaf_fn for finding first annotated cluster in each branch
            """
            if node.name in node_list:
                return True
            else:
                return False

        for node in tree.iter_leaves(is_leaf_fn=first_annotated):
            node.add_features(score=1)

    elif strategy == "f1":
        annotations["F1"] = 2 * (annotations["prec"] * annotations["rec"]) / (annotations["prec"] + annotations["rec"])
        print "Calculating scores: f1"
        scores = annotations.groupby(["node_id"], sort="False")["F1"].max().reset_index().set_index(["node_id"])
        for n in tree.traverse():
            if n.name in scores.index:
                score = scores.get_value(index=n.name, col="F1")
                n.add_features(score=score)

    message = "funcExplorer analysis..."
    if self:
        self.update_state(state='PROGRESS',
                          meta={'status': message})
    timeElapsed = datetime.now() - startTime
    logger.info('%s: Time taken for adding the scores (hh:mm:ss.ms) {}'.format(timeElapsed), ds_id)
    startTime = datetime.now()
    # Analysis -> returns dense and sparse clusters and position of sparse parent
    tree = vishic_analysis(tree, minsize, maxsize)
    timeElapsed = datetime.now() - startTime
    logger.info('%s: Time taken for vishic analysis (hh:mm:ss.ms) {}'.format(timeElapsed), ds_id)
    startTime = datetime.now()

    # Add node status to annotations table
    message = "Finding annotated genes and unique annotations..."
    if self:
        self.update_state(state='PROGRESS',
                          meta={'status': message})

    # Find nr of annotated genes in given cluster and add that to the tree
    merged = annotations.t_list.apply(lambda x: list(set(x)))
    annotated_genes = list(set(itertools.chain.from_iterable(merged)))

    # Add annotated genes
    node_list2 = annotations.node_id.unique()
    node2status = []
    for n in tree.traverse():
        if n.name in node_list2:
            if hasattr(n, "status") and hasattr(n, "score"):
                node2status.append([n.name, n.status, n.score, len(n)])
                if n.status == "D":
                    leaves = [g.upper() for g in n.get_leaf_names()]  # all genes in the cluster
                    annotated = set(leaves).intersection(annotated_genes)
                    n.add_features(annotated=len(annotated))
            else:
                node2status.append([n.name, 'None', 0, len(n)])
    timeElapsed = datetime.now() - startTime
    logger.info('%s: Time taken for annotated genes (hh:mm:ss.ms) {}'.format(timeElapsed), ds_id)
    startTime = datetime.now()
    statuses = pd.DataFrame(node2status, columns=["node_id", "status", "score", "size"])
    #annotations.to_csv(os.path.join(data_dir, "logs", "annotations.dat"), sep="\t")
    annotations = pd.merge(annotations, statuses, on=["node_id"])
    timeElapsed = datetime.now() - startTime
    logger.info('%s: Time taken for merging (hh:mm:ss.ms) {}'.format(timeElapsed), ds_id)
    startTime = datetime.now()

    # Find unique annotations (only in one dense cluster)
    # Unique annotations across dense nodes
    annotations["unique"] = (annotations[annotations.status == "D"].groupby("t_id").t_id.transform(len) == 1)
    annotations.unique.fillna(value=False, inplace=True)
    annotations["nr_unique"] = annotations.groupby("node_id")["unique"].transform('sum').astype(int)
    annotations["hasuniq"] = annotations.groupby(["node_id", "t_type"])["unique"].transform('sum').astype(int) > 0
    annotations["value"] = annotations.groupby(["node_id", "t_type"])["t_type"].transform('size')

    timeElapsed = datetime.now() - startTime
    logger.info('%s: Time taken for unique (hh:mm:ss.ms) {}'.format(timeElapsed), ds_id)
    annotations = annotations.drop(["t_list", "q_size", "domain_size"], 1)
    # Sort the annotations by pval
    annotations.sort_values(by="pval", ascending=True, kind="mergesort", inplace=True)
    # return tree, annotations, minmax, expressions
    cur.close()
    return tree, annotations, minmax, expressions
