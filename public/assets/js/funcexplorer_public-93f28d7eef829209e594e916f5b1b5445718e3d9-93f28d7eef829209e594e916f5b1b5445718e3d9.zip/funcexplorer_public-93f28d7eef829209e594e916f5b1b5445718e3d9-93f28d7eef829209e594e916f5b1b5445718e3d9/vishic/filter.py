# filter.py

# Functions to filter the ete3 Tree object for pvalue threshold and selected term types
# before doing the analysis

# This function assumes that threshold or term list is given
# Otherwise the original Tree is sent to analysis
# Run: filter_tree(tree, threshold, terms)

def filter_tree(tree, threshold, terms):
    for node in tree.iter_descendants():
        if hasattr(node, 'pval') and node.pval:
            pvals = map(float, node.pval.split('|'))
            n_terms = node.t_type.split('|') # list with term names that cluster has
            if terms:
                pvals = [pvals[i] for i, t in enumerate(n_terms) if t in terms]
                n_terms = [t for t in n_terms if t in terms]
            if threshold:
                idx = [i for i, p in enumerate(pvals) if p<threshold]
                pvals = [pvals[i] for i in idx]
                n_terms = [n_terms[i] for i in idx]
            node.pval = pvals
            node.t_type = n_terms
            
