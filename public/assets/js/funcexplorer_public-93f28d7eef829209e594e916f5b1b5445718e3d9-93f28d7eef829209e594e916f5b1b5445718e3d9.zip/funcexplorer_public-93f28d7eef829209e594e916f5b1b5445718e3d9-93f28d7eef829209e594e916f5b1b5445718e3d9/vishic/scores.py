# scores.py
# Functions to calculate and add the scores to the (prefiltered) tree
# Main function: add_scores(tree, strategy)

import numpy as np

def score_func(pvalues, n, strategy):
    """
    Calculating the vishic scores from pvalues for strategies 'annot' and 'best'
    n is the size of the cluster,
    """
    if strategy == "annot":
        score = sum([-np.log10(x) for x in pvalues])/n
    elif strategy == "best":
        score = max([-np.log10(x) for x in pvalues])
    else:
        raise ValueError("Strategy name '%s' is not accepted" % (strategy))
    return score


def first_annotated(node):
    """
    Is_leaf_fn for finding first annotated cluster in each branch
    """
    if hasattr(node, 'pval') and node.pval:
        return True
    else:
        return False


def add_scores(tree, strategy):
    """
    Adding the scores as features to clusters that have enrichment
    if threshold is given, then this is taken into account
    takes strategies: 'annot', 'best' and 'first'
    """
    if strategy == "first":
        for node in tree.iter_leaves(is_leaf_fn=first_annotated):
             node.add_features(score = 1)
    else:
        for node in tree.iter_descendants(): # iterate without including root node (is faster?)
            if hasattr(node, 'pval') and node.pval:
                if type(node.pval) is list:
                    pvals = node.pval
                else:
                    pvals = map(float, node.pval.split('|')) # since Tree keeps pvalues as string we create float valued list from that
                sc = score_func(pvalues = pvals, n = len(node), strategy = strategy)
                node.add_features(score = sc)


