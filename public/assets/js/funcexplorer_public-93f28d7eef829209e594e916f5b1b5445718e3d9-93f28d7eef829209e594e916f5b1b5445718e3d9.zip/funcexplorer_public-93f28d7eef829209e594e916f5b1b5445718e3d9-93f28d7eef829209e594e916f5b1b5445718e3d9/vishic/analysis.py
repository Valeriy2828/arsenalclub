# analysis.py

from cutting import find_dense, find_sparse


def vishic_analysis(tree, minsize, maxsize):
    """
    Doing the vishic analysis on Newick tree file
    tree object that is read in using ete3,
    minsize and maxsize of clusters to analyse,
    returns the Newick tree with whole information
    """
    find_dense(tree=tree, minsize=minsize, maxsize=maxsize) # add flag 'D' to nodes that are dense
    find_sparse(tree=tree) # add flag 'S' to nodes that are sparse
    return tree


