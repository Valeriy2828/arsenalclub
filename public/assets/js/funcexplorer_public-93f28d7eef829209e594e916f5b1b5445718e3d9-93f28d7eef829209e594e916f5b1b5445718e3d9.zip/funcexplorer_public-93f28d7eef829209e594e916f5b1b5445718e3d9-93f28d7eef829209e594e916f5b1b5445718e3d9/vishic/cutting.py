# cutting.py
# Functions to find the dense and sparse clusters based on strategy 

# First look for dense clusters (clusters with high annotation score)
# from groups of genes that have functional enrichment (i.e nodes that have feature node.score and it's not empty)
# 1. Find clusters that have functional enrichment
# 2. Find node with maximum score and give it the status = 'D'
# 3. If any of its child or parent clusters are in dictionary, remove them (since they can't be dense anymore)


def find_dense(tree, minsize, maxsize):
    """
    Finding dense clusters
    as a result node.status is set to 'D'
    """

    enriched = {x: float(x.score) for x in tree.iter_descendants() if ((len(x) >= minsize) and (len(x) <= maxsize) and hasattr(x, 'score'))}
    while 0 < len(enriched):
        d = max(enriched, key = enriched.get) # name of the cluster with highest score, this is dense
        d.status = 'D' # set the status to dense
        rem = d.get_ancestors() + d.get_descendants()
        for node in frozenset(enriched) & frozenset(rem): # remove all children and ancestors of dense cluster from list of enriched clusters (since they are not considered anymore)
            del enriched[node]
        del enriched[d] # remove the dense cluster from the dictionary in order to find next dense cluster

def is_sparse(node):
    """
    Finding out if given node is sparse, recursively
    returns True or False
    """
    if not node.is_leaf():
        lc = node.children[0]
        rc = node.children[1]
        if node.status=='D':
            return True
        if lc.is_leaf() and rc.is_leaf():
            if not node.status=='D':
                sparse = True
            else:
                sparse = False
            return sparse
        l_sparse = True
        r_sparse = True
        if not lc.is_leaf(): # if there exists left node
            if not node.status=='D' and not lc.status=='D':
                l_sparse = is_sparse(lc)
            else:
                l_sparse = False
        if not rc.is_leaf(): # if there exists right node
            if not node.status=='D' and not rc.status=='D':
                r_sparse = is_sparse(rc)
            else:
                r_sparse = False
        sparse = l_sparse and r_sparse
        return sparse
    else:
        return False

def find_sparse(tree):
    """
    Setting the status of sparse nodes to 'S'
    """
    for s in tree.iter_leaves(is_leaf_fn = is_sparse):
        if s.status!='D' and not s.is_root():
            s.status = 'S'
            # set the position of parent node
            par = s.up
            if s == par.children[0]:
                pos = "left"
            else:
                pos = "right"
            par.add_features(position=pos)

    # set single leftover leaves as sparse
    node2labels = tree.get_cached_content(container_type=type([]))
    not_free_leaves = list(set(sum([node2labels[n] for n in tree.traverse() if hasattr(n, 'status') and n.status!='None'], [])))
    for l in tree.iter_leaves():
        if not l in not_free_leaves:
            l.status = 'S'
