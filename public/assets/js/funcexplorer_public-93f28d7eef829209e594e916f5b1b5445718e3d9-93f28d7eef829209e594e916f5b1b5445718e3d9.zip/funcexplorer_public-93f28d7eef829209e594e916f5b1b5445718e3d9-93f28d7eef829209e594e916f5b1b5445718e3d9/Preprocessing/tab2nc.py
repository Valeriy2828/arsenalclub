import netCDF4
import numpy as np
import pandas as pd
import GEOparse


def tab2nc(ds_id, organism, ds_name, descr, ds_type):
    # ds_id is with path
    nc_filename = ds_id +'.nc'
    df = pd.read_table(ds_id, sep="\t", comment="#")
    #df.convert_objects(convert_numeric=True)
    array = list(df.columns.values)[1:]
    genes = df.ix[:,0].tolist()
    df = df.convert_objects(convert_numeric=True)
    mat = df.drop(df.columns[[0]], axis=1).as_matrix()
    nc_file = netCDF4.Dataset(nc_filename, 'w', format='NETCDF4_CLASSIC')
    nrows, ncols = np.shape(mat)
    org_dim = len(organism)
    ds_dim = len(ds_name)
    ds_type_dim = len(ds_type)
    if len(descr) > 0:
        descr = descr.encode('ascii', 'ignore')
        descr_dim = len(descr)
        nc_file.createDimension('__dim_%s' %descr_dim, descr_dim)
        description = nc_file.createVariable("ExperimentDescription", "S1", ('__dim_%s'%descr_dim,))
        description[:] = netCDF4.stringtochar(np.array(descr))

    N1 = len(max(genes, key=len)) # longest gene name in list
    N2 = len(max(array, key=len)) # longest sample name in list
    dims = list(set([org_dim, N1, N2, ds_dim, ds_type_dim]))
    for d in dims:
        nc_file.createDimension('__dim_%s' %d, d)
    nc_file.createDimension('m', nrows)
    nc_file.createDimension('n', ncols)

    dim_g = '__dim_%s' %N1
    dim_a = '__dim_%s' %N2
    g = nc_file.createVariable('gene', 'S1', ('m', dim_g))
    a = nc_file.createVariable('array', 'S1', ('n', dim_a))
    data = nc_file.createVariable('data', 'f4', ('m', 'n'))
    org = nc_file.createVariable('__Organism', 'S1', ('__dim_%s'%org_dim,))
    d_type = nc_file.createVariable('__DatasetType', 'S1', ('__dim_%s'%ds_type_dim,))
    ds_id = nc_file.createVariable('DatasetID', 'S1', ('__dim_%s'%ds_dim,))
    tracks = nc_file.createVariable('Experiment', 'S1', ('n', dim_a))
    g[:] = netCDF4.stringtochar(np.array(genes))
    a[:] = netCDF4.stringtochar(np.array(array))
    data[:,:] = mat
    org[:] = netCDF4.stringtochar(np.array(organism))
    d_type[:] = netCDF4.stringtochar(np.array(ds_type))
    ds_id[:] = netCDF4.stringtochar(np.array(ds_name))
    tracks[:] = netCDF4.stringtochar(np.array(array))
    nc_file.close()
    return nc_filename

def soft2nc(filename, res_filename, ds_name, soft_id, organism, descr, ds_type):
    nc_filename = res_filename+'.nc'
    # filename is SOFT file
    gds = GEOparse.get_GEO(filepath=filename) # This will read the file into GDS object
    if not descr:
        descr = str(gds.metadata.get("description", [""])[0])
    df = gds.table # pandas dataframe with expression values
    values = ["ID_REF", "IDENTIFIER"]
    remove = [x for x in values if x!=soft_id][0]
    del df[remove]
    nc_file = netCDF4.Dataset(nc_filename, 'w', format='NETCDF4_CLASSIC')
    array = list(df.columns.values)[1:]
    genes = list(df[soft_id].tolist())
    mat = df.drop(df.columns[[0]], axis=1).as_matrix()
    nrows, ncols = np.shape(mat)
    org_dim = len(organism)
    ds_type_dim = len(ds_type)

    if len(descr)>0:
        descr = descr.encode('utf-8')
        descr_dim = len(descr)
        nc_file.createDimension('__dim_%s' %descr_dim, descr_dim)
        description = nc_file.createVariable("ExperimentDescription", "S1", ('__dim_%s'%descr_dim,))
        description[:] = netCDF4.stringtochar(np.array(descr))
    ds_dim = len(ds_name)
    N1 = len(max(genes, key=len)) # longest gene name in list
    N2 = len(max(array, key=len)) # longest sample name in list
    dims = list(set([org_dim, N1, N2, ds_dim, ds_type_dim]))
    for d in dims:
        nc_file.createDimension('__dim_%s' %d, d)
    nc_file.createDimension('m', nrows)
    nc_file.createDimension('n', ncols)

    dim_g = '__dim_%s' %N1
    dim_a = '__dim_%s' %N2
    g = nc_file.createVariable('gene', 'S1', ('m', dim_g))
    a = nc_file.createVariable('array', 'S1', ('n', dim_a))
    data = nc_file.createVariable('data', 'f4', ('m', 'n'))
    org = nc_file.createVariable('__Organism', 'S1', ('__dim_%s'%org_dim,))
    d_type = nc_file.createVariable('__DatasetType', 'S1', ('__dim_%s' % ds_type_dim,))
    ds_id = nc_file.createVariable('DatasetID', 'S1', ('__dim_%s'%ds_dim,))
    tracks = nc_file.createVariable('Experiment', 'S1', ('n', dim_a))
    g[:] = netCDF4.stringtochar(np.array(genes))
    a[:] = netCDF4.stringtochar(np.array(array))
    data[:,:] = mat
    org[:] = netCDF4.stringtochar(np.array(organism))
    d_type[:] = netCDF4.stringtochar(np.array(ds_type))
    ds_id[:] = netCDF4.stringtochar(np.array(ds_name))
    tracks[:] = netCDF4.stringtochar(np.array(array))
    nc_file.close()
    return nc_filename


