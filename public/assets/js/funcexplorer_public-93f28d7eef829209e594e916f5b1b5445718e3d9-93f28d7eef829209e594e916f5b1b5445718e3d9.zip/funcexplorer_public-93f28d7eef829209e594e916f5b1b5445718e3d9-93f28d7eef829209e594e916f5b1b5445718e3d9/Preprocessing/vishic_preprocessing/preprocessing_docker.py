#!/usr/bin/python
# Preprocessing data for vishic app

import netCDF4
import numpy as np
import os
import argparse  # for command line arguments
import tempfile
import subprocess
from ete3 import Tree
import csv
import collections
import json
import logging
import hashlib
import sys
import time
import multiprocessing
import psycopg2
from RNAseq import transformRNAseq
from datetime import datetime
from collections import Counter

from gprofiler.gprofiler import GProfiler
import config_preprocessing as conf
import random

# -----------------------------------------------------------
# Global variables
gp = GProfiler("vishic_preprocessing/2.0")

TRANSFORMS = conf.TRANSFORMS
MINSIZE = conf.MINSIZE
MAXSIZE = conf.MAXSIZE
NON_TRACK = conf.NON_TRACK
LOGDIR = conf.LOGDIR
GP_VERSION = conf.GP_VERSION

reload(sys)
sys.setdefaultencoding('utf-8')
sys.setrecursionlimit(2000)  # so that for big queries multiprocessing isn't killed

def setup_logger(logger_name, log_file, level=logging.INFO):
    l = logging.getLogger(logger_name)
    formatter = logging.Formatter('%(asctime)s.%(msecs)d %(levelname)s %(module)s - %(funcName)s: %(message)s')
    fileHandler = logging.FileHandler(log_file, mode='a+')
    fileHandler.setFormatter(formatter)
    streamHandler = logging.StreamHandler()
    streamHandler.setFormatter(formatter)
    l.setLevel(level)
    l.addHandler(fileHandler)
    l.addHandler(streamHandler)
    return l

# Functions

# 1. Read in .nc file and create gene expression matrix
def read_data(nc_dat):
    """Function to read the expression matrix from .nc file.
    Function returns dictionary with the matrix, list of gene names, list of array names and other info"""
    ds_nc = netCDF4.Dataset(nc_dat, 'r')  # read in the .nc file
    #genes = ["".join(x) for x in ds_nc.variables['gene'][:]]  # list of the gene names
    genes = list(netCDF4.chartostring(ds_nc.variables['gene'][:]))
    mat = ds_nc.variables['data'][:]  # gene expression matrix
    array = list(netCDF4.chartostring(ds_nc.variables['array'][:])) # list of array names
    n = len(array)
    ds_id = ds_nc.variables.get('DatasetID', "")[:]
    if len(ds_id)>0:
        ds_id = str(netCDF4.chartostring(ds_id))
    else:
        ds_id = os.path.basename(nc_dat).split(".")[0]
    organism = ds_nc.variables.get('__Organism','')[:]
    if len(organism) > 0:
        organism = str(netCDF4.chartostring(organism))
    else:
        organism = str(netCDF4.chartostrncing(ds_nc.variables.get('Organism','')[:][1]))
    # Non obligatory variables
    ds_link = ds_nc.variables.get('DatasetLink',"")
    ds_link = "".join(ds_link[:])

    ds_type = ds_nc.variables.get('__DatasetType',"")
    ds_type = "".join(ds_type[:])

    experiment_descr = "".join(ds_nc.variables.get("ExperimentDescription","")[:])
    # track data as list of dictionaries {"ds_id": ,"track_name", "track_value"}
    track = []
    for k, v in ds_nc.variables.items():
        if k not in NON_TRACK and k[0].isupper() and len(v[:]) == n:
            #values = list(netCDF4.chartostring(v[:]))
            if isinstance(v[:], np.ma.MaskedArray):
                values = list(netCDF4.chartostring(v[:]))
            else:
                values = ["".join(x) for x in v[:]]  # UTF-8 encoding
            for (x, y) in zip(array, values):
                temp = {"sample_id": x, "track_name": k, "track_value": y}
                track.append(temp)
    ds_nc.close()
    res = {'matrix': mat, 'genes': genes, 'array': array, 'ds_id': ds_id, 'ds_link': ds_link, 'ds_type': ds_type,
           'organism': organism, 'description': experiment_descr, 'tracks': track}
    return res


# 2. Create expression matrix file for clustering
#    The first line has names of the columns, every other line starts with
#    the name of the gene, followed by real numbers

def write_data(mat, genes, array, filename, matdir, cl_cols):
    # create expression matrix files
    # For clustering genes
    mat_file = os.path.join(matdir, filename + '.MAT')
    with open(mat_file, 'w+b') as f:  # creates expression matrix file
        f.write("\t".join(['genes'] + array) + "\n")
        dat = np.c_[np.array(genes).reshape(len(genes), 1), mat]
        for line in dat:
            f.write("\t".join(line) + "\n")
    if cl_cols:
        # For clustering samples
        filename_c = os.path.join(matdir, filename + '_col.MAT')
        mat_c = mat.transpose()
        with open(filename_c, 'w+b') as f:  # creates expression matrix file
            f.write("\t".join(['genes'] + genes) + "\n")
            dat = np.c_[np.array(array).reshape(len(array), 1), mat_c]
            for line in dat:
                f.write("\t".join(line) + "\n")


# Transformation functions

def center(mat):
    # Center matrix
    mat_c = mat - mat.mean(axis=1, keepdims=True)
    return mat_c

def center_mean(mat):
    # Center matrix
    mat_c = mat - mat.mean(axis=1, keepdims=True)
    return mat_c

def center_median(mat):
    # Center matrix by median
    mat_c = mat - np.median(mat, axis=1, keepdims=True)
    return mat_c

def log10(mat):
    # Take log10 of all values in the matrix
    # If cell_value < 1, result is clamped to 0
    mat_log = np.where(mat < 1, 0, np.log10(mat))
    return mat_log

def mean_stdize(mat):
    mat = center_mean(mat)
    st = np.array(mat).std(1, keepdims=True)  # standard deviation of rows
    mat = mat/st
    return mat

def mad(data, axis=None):
    return np.median(np.absolute(data - np.median(data, axis, keepdims=True)), axis, keepdims=True)

def median_stdize(mat):
    mat = center_median(mat)
    md = mad(mat, axis=1)  # median absolute deviation of rows
    mat = mat/md
    return mat


# Creating the matrix
def create_expressionmat(mat, genes, array, filename, transformation, log, norm_method, c, matdir, cl_cols):
    # norm_method and c are for RNA seq normalisation, c is pseudocount
    if norm_method:
        logger.info("Normalising RNA seq data with method: %s" % (norm_method,))
        logger.info("Normalising RNA seq data with pseudocount: %s" % (c,))
        if norm_method != "no_norm":
            mat = transformRNAseq(mat, c = c, method = norm_method) # returns numpy matrix
        else:
            mat = mat
    if log:
        mat = log10(mat)
    if transformation:
        mat = globals()[transformation](mat)
    mat = mat.round(6) # so java could read the numbers
    # remove na rows (they had 0 std before standardization
    nans = ~np.isnan(mat).any(axis=1)
    mat = mat[nans]
    genes = list(np.array(genes)[nans])
    # remove rows with inf value
    finite = np.isfinite(mat).any(axis=1)
    mat = mat[finite]
    genes = list(np.array(genes)[finite])
    # Make sure the data does not have all 0 rows and 0 std rows
    st = np.array(mat).std(1) # standard deviation
    which_rows1 = ~(mat==0).all(1)
    which_rows2 = ~(st==0)
    which_rows = which_rows1 & which_rows2
    mat = mat[which_rows]
    genes = list(np.array(genes)[which_rows])
    write_data(mat, genes, array, filename, matdir, cl_cols)  # create expressionmatrix files
    return mat, genes


# 3. Clustering with Hybridclustering
def HybridClustering(filename, dist, hybrid, treedir, matdir):
    # Hierarchical clustering with Hybridclustering using Pearson correlation as default,
    # Average linkage, automatically calculated k for k-means
    # k = sqrt(n/4)

    if hybrid:
        command = ["java", "-jar", "/preprocess_app/scripts/clustering-4.jar", "-i", os.path.join(matdir, filename) + '.MAT',
                   "-sr", str(1), "-sc",
                   str(1), "-sep", '"\\t"', "-%s" % dist, "-o", os.path.join(treedir, filename + "_%s" %dist), "-hybrid", "-precision", str(10)]

    else:
        command = ["java", "-jar", "/preprocess_app/scripts/clustering-4.jar", "-i", os.path.join(matdir, filename) + '.MAT',
                   "-sr", str(1), "-sc",
                   str(1), "-sep", '"\\t"', "-%s" % dist, "-o", os.path.join(treedir, filename + "_%s" %dist), "-precision", str(10)]

    # Run clustering
    p = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    out, err = p.communicate()
    if err:
        logger.info(err)
    # If clustered columns, then file2 exists
    filename2 = filename + "_col"
    if filename2 + ".MAT" in os.listdir(matdir):
        command2 = ["java", "-jar", "/preprocess_app/scripts/clustering-4.jar", "-i", os.path.join(matdir, filename2) + '.MAT',
                    "-sr", str(1), "-sc",
                    str(1), "-sep", '"\\t"', "-%s" % dist, "-o", os.path.join(treedir, filename2 + "_%s" %dist), "-hybrid", "-precision", str(10)]
        p = subprocess.Popen(command2, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        out, err = p.communicate()
    return os.path.join(treedir, filename + "_%s" %dist), os.path.join(treedir, filename2 + "_%s" %dist)


# Function to convert data.gtr and data.cdt files into NEWICK format
# Taken from: https://github.com/tanghaibao/treecut/blob/master/scripts/eisen_to_newick.py

def cdt_to_nwk(gtr_file, cdt_file):
    f_name, extension = os.path.splitext(gtr_file)
    nwk_file = f_name + '.nwk'  # change the .gtr extension to .nwk
    GTRLine = collections.namedtuple("GTRLine", "parent left_child right_child dist")
    reader = csv.reader(file(cdt_file), delimiter="\t")
    reader.next()  # header
    gid_to_name = {}
    for row in reader:
        gid, name = row[:2]
        gid_to_name[gid] = name
    reader = csv.reader(file(gtr_file), delimiter="\t")
    nodes = {}
    for gtr in map(GTRLine._make, reader):
        node = Tree()
        parent_name, parent_dist = gtr.parent, float(gtr.dist)
        for child in (gtr.left_child, gtr.right_child):
            # if is leaf/gene
            if child in gid_to_name:
                node.add_child(name=gid_to_name[child], dist=1 - parent_dist)
            else:
                assert child in nodes, child
                child_node, child_dist = nodes[child]
                # dist: the distance from the node to the child.
                node.add_child(child_node, dist=child_dist - parent_dist)
        nodes[parent_name] = (node, parent_dist)
    t = node
    t.dist = 0.0  # doesn't change the tree structure
    t.write(features=[], format=1, outfile=nwk_file, format_root_node=True)
    return t, nwk_file  # in case we want to continue with our analysis


# Functions for querying with gCocoa

def toFasta(clusters_dict, fasta_filename):
    """This function writes given dictionary of clusters into .FASTA file for querying with gCocoa"""
    the_file = open(fasta_filename, 'w')
    for name, query in clusters_dict.iteritems():
        fasta_string = '>' + name + "\n" + query + "\n"
        the_file.write(fasta_string)


def split_dict(clusters_dict, qsize):
    """This function splits given dictionary into parts with given size
    (in order to not query all clusters at once)"""
    for i in range(len(clusters_dict) / qsize):
        yield dict(clusters_dict.items()[i * qsize:(i * qsize) + qsize])
    if len(clusters_dict) % qsize != 0:  # leftover clusters (if division isn't exact)
        yield dict(clusters_dict.items()[-(len(clusters_dict) % qsize):])


def gCocoa(query_file, genome, correction, bg, numeric_ns):
    """This function takes given .FASTA file and sends this to gCocoa for querying (from server)

    Needed arguments:
    query_file (resultfile from toFasta()),
    genome ('hsapiens'),
    correction ('a', 'b' or 'f' <-- analytical threshold, Bonferroni correction, FDR Benjamini-Hochberg correction),
    terms is a list of term names
    bg is background for querying
    numeric_ns is the namespace for fully numeric id-s, if empty, then they are not numeri ids
    """
    terms = ["GO", "KEGG", "REAC", "TF", "MI", "HP", "CORUM", "HPA"]  # needed to leave BIOGRID out
    bg_dir = '/gprofiler/ensembl_data/' + genome + '/backgrounds'
    # If background exists in /backgrounds folder, then use it, else query without background
    if os.path.isdir(bg_dir) and bg in os.listdir(bg_dir):
        command = ["/gprofiler/gost.pl", "-g", genome, "--query_file_multiple", query_file,
                   "-x", "-t", correction, "--no_iea", "--webservice_output", "--sort_by_pvalue",
                   "-l", "--background_spexs", bg, "-s", ",".join(terms)]
    elif bg in os.listdir(os.path.join(conf.DATADIR, "backgrounds")):
        # if use dataset as background
        command = ["/gprofiler/gost.pl", "-g", genome, "--query_file_multiple", query_file,
                       "-x", "-t", correction, "--no_iea", "--webservice_output", "--sort_by_pvalue",
                       "-l", "-s", ",".join(terms), "-B", os.path.join(conf.DATADIR, "backgrounds", bg)]

    else:
        command = ["/gprofiler/gost.pl", "-g", genome, "--query_file_multiple", query_file,
                   "-x", "-t", correction, "--no_iea", "--webservice_output", "--sort_by_pvalue",
                   "-l", "-s", ",".join(terms)]

    gcocoa = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)

    # read results line by line and filter them to resultlist
    if numeric_ns:
        if gcocoa.stdout:
            resultlist = []
            domain_sizes = {}
            for line in gcocoa.stdout:
                if line.startswith("NODE"):  # if line starts with the node name like 'NODE_x'
                    line = line.split('\t')
                    resultlist.append(
                        {'node_id': line[0], 'pval': float(line[2]), 't_size': int(line[3]), 'q_size': int(line[4]),
                         'intersection': int(line[5]),
                         'prec': float(line[6]),
                         'rec': float(line[7]), 't_id': line[8], 'domain': line[8].split(":")[0], 't_type': line[9],
                         'descr': line[11],
                         't_list': line[13].rstrip().split(",").split(":")[1]}) # keep numeric id-s
                else:
                    if "Effective domain" in line:
                        info = line.split('\t')[1].split(" ")
                        domain = info[4].strip(":").split("_")[0]  # remove NOIEA from domain name
                        size = int(info[5].strip(","))
                        domain_sizes[domain] = size

            for x in resultlist:
                x["domain_size"] = domain_sizes.get(x["domain"])
            return resultlist
    else:
        if gcocoa.stdout:
            resultlist = []
            domain_sizes = {}
            for line in gcocoa.stdout:
                if line.startswith("NODE"):  # if line starts with the node name like 'NODE_x'
                    line = line.split('\t')
                    resultlist.append(
                        {'node_id': line[0], 'pval': float(line[2]), 't_size': int(line[3]), 'q_size': int(line[4]), 'intersection': int(line[5]),
                         'prec': float(line[6]),
                         'rec': float(line[7]), 't_id': line[8], 'domain': line[8].split(":")[0], 't_type': line[9],
                         'descr': line[11],
                         't_list': line[13].rstrip().split(",")})
                else:
                    if "Effective domain" in line:
                        info = line.split('\t')[1].split(" ")
                        domain = info[4].strip(":").split("_")[0]  # remove NOIEA from domain name
                        size = int(info[5].strip(","))
                        domain_sizes[domain] = size

            for x in resultlist:
                x["domain_size"] = domain_sizes.get(x["domain"])
            return resultlist


def find_clusters(tree, minsize, maxsize, expressions, numeric_ns):
    """This function takes Newick tree and returns dictionary with clusters sized between minsize and maxsize.
    It also names the tree nodes by 'NODE_x'.

    Result: {'NODE_0': 'gen1 gen2 gen3', ... }
    """
    clusters = dict()  # dictionary to store the clusters (only the ones that need to be queried!)
    node2labels = tree.get_cached_content(store_attr="name", container_type=type(
        []))  # dictionary with leaf names for each node (speeds up?)
    edge = 1
    for node in tree.traverse():
        if node.is_root():
            node.add_features(rootDist=0.0, status=None)
            node.name = "NODE_0"
        elif node.is_leaf():  # if node is leaf add profile for heatmap plotting
            #node.add_features(rootDist=node.up.rootDist + node.dist)
            node.add_features(rootDist=1.0)
            #if expressions:
            #    node.add_features(profile=expressions[node.name])  # add expression vector to each leaf
        else:  # in order to not rename the leaves (genes)
            node.name = "NODE_%d" % edge  # name each node as NODE_1 etc
            node.add_features(rootDist=node.up.rootDist + node.dist)
            node.add_features(
                status=None)  # add feature to nodes where we can add if cluster is dense ('D'), sparse ('S') or neither (None)
            # is there something better to use instead of D, S and ' ' ?
            edge += 1
            if minsize <= len(node) <= maxsize:  # if cluster size is between given min and max size then query
                # If numeric genes, then add numeric_ns to the names
                if numeric_ns:
                    renamed_genes = map(lambda orig_gene: numeric_ns + ":" + orig_gene, node2labels[node])
                    clusters[node.name] = " ".join(renamed_genes)
                else:
                    clusters[node.name] = " ".join(node2labels[node])  # get one string from the list of genes in one cluster
    return clusters


def query_process(x, genome, correction, bg, numeric_ns):
    # x is a dictionary with size 10 that is yield by split_dict
    tf = tempfile.NamedTemporaryFile()
    toFasta(x, tf.name)  # create FASTA file
    # Query with gCost
    # Returns a list with result dictionaries
    gres = gCocoa(query_file=tf.name, genome=genome, correction=correction, bg=bg, numeric_ns=numeric_ns)
    tf.close()  # deletes the temporary FASTA file
    if gres:
        return gres  # list of dictionaries


def annotate_clusters(tree, genome, correction, minsize, maxsize, bg, numeric_ns, expressions):
    """This function takes the Newick tree and queries with gCocoa(). This is the main function for that!
    """
    clusters = find_clusters(tree, minsize, maxsize, expressions, numeric_ns)  # also adds names to the nodes
    # Start querying with gProfiler
    qsize = 10  # how many clusters to query at once?
    TASKS = list(split_dict(clusters_dict=clusters, qsize=qsize))  # all clusters split into list by 'qsize' clusters at one

    pool = multiprocessing.Pool(processes=10)
    jobs = []

    for i in range(len(TASKS)):
        jobs.append(pool.apply_async(query_process, args=(TASKS[i], genome, correction, bg, numeric_ns)))
    output = []
    for j in jobs:
        res = j.get()
        if type(res) is list:
            output = output + res
    pool.close()
    pool.join()
    return output


# gConvert genes
def gConvert(genes, organism, numeric_ns):
    res = gp.gconvert(genes, organism=organism, numeric_ns=numeric_ns)  # list of lists with the results
    res_genes = [{"gene_id": r[1], "gene_name": r[4], "descr": r[5], "namespaces": r[6]} for r in res if r[2].endswith(".1")]
    return res_genes


# Create database table named by analysed filename
def create_connection(user, dbname, host):
    """ create a database connection to the SQLite database
        specified by db_file
    :param db_file: database file
    :return: Connection object
    """
    conn_string = "host='%s' dbname='%s' user='%s'" % (host, dbname, user)
    try:
        conn = psycopg2.connect(conn_string)
        return conn
    except:
        logger.info("Couldn't connect to database")
        sys.exit(1)


def insert_ds_data(conn, ds_id, track_data, ds_data, gene_data):
    c = conn.cursor()
    sql1 = """INSERT INTO tracks(ds_id, sample_id, track_name, track_value) VALUES ('{t}', %(sample_id)s, %(track_name)s, %(track_value)s);""".format(
        t=ds_id)
    sql2 = """INSERT INTO dataset(ds_id, ds_name, organism, ds_descr, ds_link, experiment_descr, platform, sample_count, gene_count, data_type, ds_list, namespace, fix_value, impute_method, background, cl_cols, transformation, norm_method, pseudocount) VALUES ('{t}', %(ds_name)s, %(organism)s, %(ds_descr)s, %(ds_link)s, %(experiment_descr)s, %(platform)s, %(sample_count)s, %(gene_count)s, %(data_type)s, %(ds_list)s, %(namespace)s, %(fix_value)s, %(impute_method)s, %(background)s, %(cl_cols)s, %(transformation)s, %(norm_method)s, %(pseudocount)s);""".format(t=ds_id)
    sql3 = """INSERT INTO genes(ds_id, gene_id, gene_name, descr) VALUES ('{t}', %(gene_id)s, %(gene_name)s, %(descr)s);""".format(t=ds_id)
    if len(track_data) > 0:
        c.executemany(sql1, track_data)
        conn.commit()
    c.execute(sql2, ds_data)
    conn.commit()
    c.executemany(sql3, gene_data)
    conn.commit()


def insert_annot_data(conn, hash_name, annot_data, input_data, user):
    """ insert data into db about annotations
    :param conn: Connection object
    :param hash_name: hash filename
    :param data: Pandas dataframe, column names are the same as in the table
    :return:
    """
    c = conn.cursor()
    sql1 = """INSERT INTO annotation(hash_name, node_id, t_id, q_size, t_size, domain_size, intersection, rec, prec, pval, t_list) VALUES ('{t}', %(node_id)s, %(t_id)s, %(q_size)s, %(t_size)s, %(domain_size)s, %(intersection)s, %(rec)s, %(prec)s, %(pval)s, %(t_list)s);""".format(t=hash_name)
    sql2 = """INSERT INTO term(t_id, descr, domain, t_type) VALUES (%(t_id)s, %(descr)s, %(domain)s, %(t_type)s) ON CONFLICT DO NOTHING;"""
    if user:
        sql3 = """INSERT INTO input(hash_name, ds_id, gp_version, correction, distance, email_hash) VALUES ('{t}', %(ds_id)s, %(gp_version)s, %(correction)s, %(distance)s, %(email_hash)s);""".format(t=hash_name)
    else:
        sql3 = """INSERT INTO input(hash_name, ds_id, gp_version, correction, distance) VALUES ('{t}', %(ds_id)s , %(gp_version)s, %(correction)s, %(distance)s);""".format(t=hash_name)
    c.executemany(sql1, annot_data)
    conn.commit()
    try:
        c.executemany(sql2, annot_data)
        conn.commit()
    except psycopg2.extensions.TransactionRollbackError:
        logger.info("%s: Run insert terms again" % (hash_name,))
        # try again
        time.sleep(random.randint(2,11))
        c.executemany(sql2, annot_data)
        conn.commit()
    except ValueError as e:
        conn.rollback()
        e = sys.exc_info()[0]
        logger.info("%s: Insert error: %s" % (hash_name,e))
        conn.commit()
        conn.close()
        sys.exit(1)
    c.execute(sql3, input_data)
    conn.commit()





# 5. The main function that is invoked from command line
def main(inputfile, user, email, email_hash, name, transf, log, norm_method, pseudocount, cl_cols, bg, gp_version, numeric_ns, fix_value, impute_method):
    # Parameters
    dists = ['p']
    hybrid = True
    correction = ['a', 'b', 'f']

    # Read in the data
    data_dict = read_data(nc_dat=inputfile)  # dictionary with data from .nc file
    mat = data_dict['matrix']
    initial_genes = data_dict["genes"]
    array = data_dict["array"]
    ds_name = data_dict["ds_id"]
    organism = data_dict["organism"]
    experiment_descr = data_dict["description"]
    track_data = data_dict.get("tracks",[])  # list of dictionaries for sample tracks
    ds_link = data_dict.get("ds_link", "")
    data_type = data_dict.get("ds_type", "")

    # unique filename
    ds_id = os.path.splitext(os.path.basename(inputfile))[0]

    if not user:
        email_hash = ""
        TREEDIR = conf.TREEDIR["non_user"]
        MATDIR = conf.MATDIR["non_user"]
        db_user = conf.DATABASES['default']['USER']
        dbname = conf.DATABASES['default']['DBNAME']
        host = conf.DATABASES['default']['HOST']

        if any(item.startswith(ds_id) for item in os.listdir(TREEDIR)):
            logger.info("FAIL, FILE ALREADY EXISTS!: %s" % (inputfile,))
            return 1

        # Prepare the data
        # what transformation to use before clustering
        if data_type and not transf:
            transf = TRANSFORMS.get(data_type, None)  # log10 or center

        # Get background for our public datasets
        platform = os.path.basename(os.path.dirname(inputfile)) # e.g A-AFFY-33
        platformfolder = os.path.dirname(os.path.dirname(inputfile))

        if os.path.isfile(os.path.join(platformfolder,'platforminfo')):
            with open(os.path.join(platformfolder,'platforminfo'), 'rb') as f:
                PLATFORMINFO = json.load(f)
            background = PLATFORMINFO.get(platform, '')
        else:
            background = ''
        if background:
            background = background.get('gc_namespace', '')
            if background:
                background = background.encode('ascii', 'ignore').upper()

        # Get the info of dataset
        infofile = os.path.join(os.path.dirname(inputfile), 'DESC/exps.collection')
        if os.path.isfile(infofile):
            with open(infofile, 'rb') as f:
                for line in f:
                    if line.startswith(ds_name):
                        index_info = line.rstrip()  # DATASET:;TITLE:;CHIPS:;DESC:;TAGS:;PLATFORM
                        description = index_info.split(":;")[1]
                        break
        else:
            description = ""


    else:
        TREEDIR = conf.TREEDIR["user"]
        MATDIR = conf.MATDIR["user"]
        db_user = conf.DATABASES['user']['USER']
        dbname = conf.DATABASES['user']['DBNAME']
        host = conf.DATABASES['user']['HOST']
        user_data = {"email_hash": email_hash, "email": email, "name": name}
        if any(item.startswith(ds_id) for item in os.listdir(TREEDIR)):
            logger.info("FAIL, FILE ALREADY EXISTS!: %s" % (inputfile,))
            sys.exit(1)

        if bg=="ds":
            background = ds_id + "_bg"
            # save background file for gprofiler analysis
            bg_file = open(os.path.join(conf.DATADIR, "backgrounds", background), "w")
            bg_file.write(" ".join(initial_genes))
            bg_file.close()
        elif not bg:
            background = bg
        else:
            background = ''

        description = ""
        platform = ""

    params = [ds_id, gp_version, email_hash]

    # Create expression matrix with filename=ds_id
    mat_t, genes = create_expressionmat(mat=mat, genes=initial_genes, array=array, filename=ds_id,
                                        transformation=transf, log=log, norm_method=norm_method, c=pseudocount, matdir=MATDIR,
                                        cl_cols=cl_cols)  # creates expression matrix after transformation, also writes it to mat_file

    mat_shape = np.shape(mat_t)
    if any(x < 5 for x in mat_shape):
        logger.info("File dimensions too small for clustering!: %s" % (inputfile,))
        sys.exit(1)
    # Create connection to the database
    conn = create_connection(user=db_user, dbname=dbname, host=host)
    # Clustering
    # Hash the filename by distance (and correction parameters, FILE FOLDER PATH ADDED TO THE FILENAME!!!)
    for dist in dists:
        logger.info('%s: Started clustering with distance %s', ds_id, dist)
        logger.info('%s: The dimensions of data are: %s x %s', ds_id, mat_shape[0], mat_shape[1])
        logger.info('%s: The transformation of data is: %s ', ds_id, transf)
        outname, outname2 = HybridClustering(filename=ds_id, dist=dist, hybrid=hybrid, treedir=TREEDIR, matdir=MATDIR)
        # Check if succeeded
        if not os.path.isfile(outname + ".gtr"):
            logger.info("Clustering failed: %s" % (inputfile,))
            # Add to blacklist
            if user:
                c = conn.cursor()
                c.execute("""INSERT INTO blacklist(email_hash) VALUES (%(email_hash)s)""", {"email_hash": email_hash})
                conn.commit()
                conn.close()
            sys.exit(1)
        logger.info('%s: Clustering ended', ds_id)
        # Create Newick tree file
        tree, nwk_file = cdt_to_nwk(gtr_file=outname + ".gtr", cdt_file=outname + ".cdt")
        if cl_cols and os.path.isfile(outname2 + ".gtr"):
            tree_col, nwk_file_col = cdt_to_nwk(gtr_file=outname2 + ".gtr", cdt_file=outname2 + ".cdt")
            # Re-arrange mat_file according to column clustering
            n_array = tree_col.get_leaf_names()  # new order of samples, old order is 'array'
            i = [array.index(x) for x in n_array]  # new indexes
            n_mat = mat_t[:, i]
            # Rewrite the mat file
            with open(os.path.join(MATDIR, ds_id) + '.MAT', 'w+b') as f:  # creates new expression matrix file
                f.write("\t".join(['genes'] + n_array) + "\n")
                dat = np.c_[np.array(genes).reshape(len(genes), 1), n_mat]
                for line in dat:
                    f.write("\t".join(line) + "\n")
        else:
            n_array = array
            dat = np.c_[np.array(genes).reshape(len(genes), 1), mat_t]
        # not needed here?
        #expressions = dict(zip([x[0] for x in dat], [[float(v) for v in x[1:]] for x in
        #                                             dat]))  # dictionary with genes as keys and expression vector as values
        expressions = ""
        # Remove .gtr and .cdt files from folder, also mat_col
        remove_files = [outname + ".gtr", outname + ".cdt", outname2 + ".cdt", outname2 + ".gtr",
                        os.path.join(MATDIR, ds_id) + '_col.MAT']
        for x in remove_files:
            if os.path.isfile(x):
                os.remove(x)

        # Annotations
        for corr in correction:
            key = params + [dist, corr]
            hash_name = hashlib.md5(str(key)).hexdigest()
            # Query with gP and write results to pandas dataframe
            output = annotate_clusters(tree=tree, genome=organism, correction=corr,
                                       minsize=MINSIZE, maxsize=MAXSIZE, bg=background, numeric_ns = numeric_ns, expressions=expressions)
            logger.info("%s: The size of the output is: " + str(len(output)), ds_id)
            # Check if annotations succeeded
            if len(output) == 0:
                logger.info("%s: The output is empty", ds_id)
                if user:
                    c = conn.cursor()
                    c.execute("""INSERT INTO blacklist(email_hash) VALUES (%(email_hash)s)""",
                              {"email_hash": email_hash})
                    conn.commit()
                    conn.close()
                sys.exit(1)

            try:
                input_data = {"ds_id": ds_id, "gp_version": gp_version, "correction": corr, "distance": dist}
                if user:
                    input_data["email_hash"] = email_hash
                insert_annot_data(conn, hash_name, annot_data=output, input_data=input_data, user=user)

            except:
                conn.rollback()
                e = sys.exc_info()[0]
                logger.info("Error in writing the output: %s" % e)
                # Add to blacklist
                if user:
                    c = conn.cursor()
                    c.execute("""INSERT INTO blacklist(email_hash) VALUES (%(email_hash)s)""", {"email_hash": email_hash})
                conn.commit()
                conn.close()
                sys.exit(1)


        # Save the tree with the results
        tree.write(features=[], outfile=nwk_file, format=1, format_root_node=True)

    # Add data of dataset to the database
    try:
        # Get the namespace of dataset
        gene_data = gConvert(genes, organism, numeric_ns) # contains values for common namespaces
        if not numeric_ns:
            namespace = [g["namespaces"] for g in gene_data]
            namespace = filter(None, namespace)
            namespace = [x for ns in namespace for x in ns.split(", ")]
            namespace = Counter(namespace)
            if namespace:
                namespace = namespace.most_common(1)[0][0]
            else:
                namespace = numeric_ns # None
        else:
            namespace = numeric_ns
        ds_data = {"ds_name": ds_name, "organism": organism, "ds_descr": unicode(description), "ds_link": ds_link, "experiment_descr": experiment_descr.decode('unicode-escape'), "platform": platform, "sample_count": mat_shape[1], "gene_count": mat_shape[0], "data_type": data_type, "ds_list": n_array, "namespace": namespace, "fix_value": fix_value, "impute_method": impute_method, "background": background, "cl_cols": cl_cols, "transformation": transf, "pseudocount": pseudocount, "norm_method":norm_method}
        insert_ds_data(conn, ds_id, track_data, ds_data, gene_data)
        # Add user info
        if user:
            logger.info(user_data)
            c = conn.cursor()
            sql = """INSERT INTO users(email_hash, email, name) VALUES (%(email_hash)s, %(email)s, %(name)s) ON CONFLICT DO NOTHING;"""
            c.execute(sql, user_data)

    except:
        e = sys.exc_info()[0]
        logger.info("Error in writing the ds data: %s" % e)
        conn.rollback()
        # Add to blacklist
        if user:
            c = conn.cursor()
            c.execute("""INSERT INTO blacklist(email_hash) VALUES (%(email_hash)s) ON CONFLICT DO NOTHING""", {"email_hash": email_hash})
        conn.commit()
        conn.close()
        sys.exit(1)

    conn.commit()
    conn.close()
    return 0


# 4. Take arguments from command line and create the resultfile
parser = argparse.ArgumentParser(description='Preprocessing .nc file, i.e clustering')
parser.add_argument('-i', required=True, help="Name of the input .nc file")
parser.add_argument('-U', action="store_true", help="If given then the data is user uploaded")
parser.add_argument('-email', default="", help="Email of user")
parser.add_argument('-hash', default="", help="Hash connected to email")
parser.add_argument('-name', default="", help="Name connected to email")
parser.add_argument('-transf', default='', help="Transformations to apply to the matrix")
parser.add_argument('-cols', action="store_true", help="If given, then cluster also the columns")
parser.add_argument('-bg', default="", help="If given, then use custom background")
parser.add_argument('-norm_method', default='', help="If given, then normalise RNA seq")
parser.add_argument('-pseudocount', default=0, type=float, help="Pseudocount for RNA seq normalisation")
parser.add_argument('-log', action="store_true", help="If given, then take log values")
parser.add_argument('-numeric_ns', default="", help="Namespace to use for fully numeric IDs")
parser.add_argument('-fix_value', default=0, help="Value used to replace in impute method")
parser.add_argument('-impute_method', default="", help="Imputing method used")



if __name__ == "__main__":
    args = parser.parse_args()
    inputfile = args.i  # .nc file with path
    user = args.U  # if user uploaded file
    email = args.email
    email_hash = args.hash
    name = args.name
    transf = args.transf
    cl_cols = args.cols # cluster columns?
    bg = args.bg # use custom background?
    norm_method = args.norm_method # for RNAseq
    pseudocount = args.pseudocount # pseudocount for RNAseq
    gp_version = GP_VERSION
    log = args.log
    numeric_ns = args.numeric_ns
    fix_value = args.fix_value
    impute_method = args.impute_method
    # Logging
    if user:
        logger = setup_logger('preprocessing_user', os.path.join(LOGDIR, 'preprocessing_user.log'))
        #logging.basicConfig(level=logging.INFO,
        #                    format='%(asctime)s.%(msecs)d %(levelname)s %(module)s - %(funcName)s: %(message)s',
        #                    datefmt="%Y-%m-%d %H:%M:%S", filename=os.path.join(LOGDIR, 'vishic_user.log'),
        #                    filemode='a+')
    else:
        logger = setup_logger('preprocessing_public',
                              os.path.join(LOGDIR, 'preprocessing_public.log'))  # logs of preprocessing, vishic public
        #logging.basicConfig(level=logging.INFO,
        #                    format='%(asctime)s.%(msecs)d %(levelname)s %(module)s - %(funcName)s: %(message)s',
         #                   datefmt="%Y-%m-%d %H:%M:%S", filename=os.path.join(LOGDIR, 'vishic.log'), filemode='a+')
    logger.info('NEW PROCESSING')
    logger.info('%s: Preprocessing starts', inputfile)
    startTime = datetime.now()
    res = main(inputfile, user, email, email_hash, name, transf, log, norm_method, pseudocount, cl_cols, bg, gp_version, numeric_ns, fix_value, impute_method)
    timeElapsed = datetime.now() - startTime
    logger.info('%s: Everything is done', inputfile)
    logger.info('%s: Time taken (hh:mm:ss.ms) {}'.format(timeElapsed), inputfile)
    sys.exit(res)

