# Functions for RNA seq upload etc

import numpy as np
import pandas as pd

from rpy2 import robjects as _ro
from rpy2.robjects import numpy2ri as _numpy2ri
_numpy2ri.activate()

vst = _ro.r('DESeq2::vst')


# Normalize as in DESeq
# https://www.biostars.org/p/9442/
# http://genomicsclass.github.io/book/pages/rnaseq_gene_level.html
# Normalization for sequencing depth

def transformRNAseq(counts, c = 1, method = "no_norm"):
    counts = pd.DataFrame(counts)
    if method == "log2":
        logcounts = np.log(counts)
        loggeomeans = logcounts.mean(axis=1)
        sf = logcounts.sub(loggeomeans, axis=0)[(np.isfinite(loggeomeans)) & loggeomeans.notnull()]  # same as estimateSizeFactors in R
        sf = np.exp(sf.median(axis=0))  # sizefactors (same as estimateSizeFactors in DESeq2)
        counts.normed = counts / sf.values
        counts.normed = np.log2(counts.normed + c)  # log normalized counts (plus a pseudocount c)
        counts.normed = np.matrix(counts.normed)
    elif method == "vst":
        mat = counts.as_matrix()
        counts.normed = vst(mat)
        counts.normed = np.matrix(counts.normed)
        # counts.normed = pd.DataFrame(counts.normed, columns=counts.columns.values, index=counts.index.values)
    else:
        counts.normed = np.matrix(counts)
    return counts.normed