import os
import pickle

DATADIR = '/data'  # Directory for keeping .nc, _mat, .cdt and .gtr data
TREEDIR = {"user": os.path.join(DATADIR, 'nwk_files/user'),
           "non_user": os.path.join(DATADIR, 'nwk_files/vishic')} # Directory for keeping all .nwk tree files

MATDIR = {"user": os.path.join(DATADIR, 'mat_files/user'),
          "non_user": os.path.join(DATADIR, 'mat_files/vishic')} # Directory for .mat files

LOGDIR = os.path.join(DATADIR, 'logs')

DATABASES = {'default':
                 {
                     'USER': 'vishic_nonuser',
                     'DBNAME': 'vishic_nonuser',
                     'HOST': 'vishic_db'
                 },
             'user':
                 {
                     'USER': 'vishic_user',
                     'DBNAME': 'vishic_user',
                     'HOST': 'vishic_db'
             }
}

# Sizes for clusters to analyse
MINSIZE = 5
MAXSIZE = 1000
TRANSFORMS = pickle.load(
    open(os.path.join(DATADIR, 'databases/data_transforms.dict'), 'rb'))  # dictionary in form {datatype: transformation}

# Netcdf parameters
NON_TRACK = ["__FileFormat", "__DatasetType", "Organism", "InvestigationTitle", "ExperimentDescription", "DatasetID",
             "DatasetLink", "__VariableLabel", "__Organism", "data", "gene", "array", "MetadataOrder"]

#GP_VERSION = "r1732_e89_eg36"
GP_VERSION = "r1741_e90_eg37"