#!/anaconda_ete/bin/python

# Preprocessing data for vishic app

import netCDF4
import numpy as np
import os
import argparse  # for command line arguments
import tempfile
import subprocess
from ete3 import Tree
import csv
import collections
import json
import logging
import hashlib
import sys
import multiprocessing
import psycopg2
from RNAseq import transformRNAseq

from gprofiler.gprofiler import GProfiler
import config_preprocessing as conf

# -----------------------------------------------------------
# Global variables
gp = GProfiler("vishic_preprocessing/2.0")

TRANSFORMS = conf.TRANSFORMS
MINSIZE = conf.MINSIZE
MAXSIZE = conf.MAXSIZE
NON_TRACK = conf.NON_TRACK
LOGDIR = conf.LOGDIR

reload(sys)
sys.setdefaultencoding('utf-8')
sys.setrecursionlimit(2000)  # so that for big queries multiprocessing isn't killed

# Functions

# 1. Read in .nc file and create gene expression matrix
def read_data(nc_dat):
    """Function to read the expression matrix from .nc file.
    Function returns dictionary with the matrix, list of gene names, list of array names and other info"""
    ds_nc = netCDF4.Dataset(nc_dat, 'r')  # read in the .nc file
    #genes = ["".join(x) for x in ds_nc.variables['gene'][:]]  # list of the gene names
    genes = list(netCDF4.chartostring(ds_nc.variables['gene'][:]))
    mat = ds_nc.variables['data'][:]  # gene expression matrix
    array = list(netCDF4.chartostring(ds_nc.variables['array'][:])) # list of array names
    n = len(array)
    ds_id = ds_nc.variables.get('DatasetID', "")[:]
    if len(ds_id)>0:
        ds_id = str(netCDF4.chartostring(ds_id))
    else:
        ds_id = os.path.basename(nc_dat).split(".")[0]
    organism = ds_nc.variables.get('__Organism','')[:]
    if len(organism) > 0:
        organism = str(netCDF4.chartostring(organism))
    else:
        organism = str(netCDF4.chartostrncing(ds_nc.variables.get('Organism','')[:][1]))
    # Non obligatory variables
    ds_link = ds_nc.variables.get('DatasetLink',"")
    ds_link = "".join(ds_link[:])

    ds_type = ds_nc.variables.get('__DatasetType',"")
    ds_type = "".join(ds_type[:])

    experiment_descr = "".join(ds_nc.variables.get("ExperimentDescription","")[:])
    # track data as list of dictionaries {"ds_id": ,"track_name", "track_value"}
    track = []
    for k, v in ds_nc.variables.items():
        if k not in NON_TRACK and k[0].isupper() and len(v[:]) == n:
            #values = list(netCDF4.chartostring(v[:]))
            if isinstance(v[:], np.ma.MaskedArray):
                values = list(netCDF4.chartostring(v[:]))
            else:
                values = ["".join(x) for x in v[:]]  # UTF-8 encoding
            for (x, y) in zip(array, values):
                temp = {"ds_id": x, "track_name": k, "track_value": y}
                track.append(temp)
    ds_nc.close()
    res = {'matrix': mat, 'genes': genes, 'array': array, 'ds_id': ds_id, 'ds_link': ds_link, 'ds_type': ds_type,
           'organism': organism, 'description': experiment_descr, 'tracks': track}
    return res


# 2. Create expression matrix file for clustering
#    The first line has names of the columns, every other line starts with
#    the name of the gene, followed by real numbers

def write_data(mat, genes, array, filename, matdir, cl_cols):
    # create expression matrix files
    # For clustering genes
    mat_file = os.path.join(matdir, filename + '.MAT')
    with open(mat_file, 'w+b') as f:  # creates expression matrix file
        f.write("\t".join(['gene'] + array) + "\n")
        dat = np.c_[np.array(genes).reshape(len(genes), 1), mat]
        for line in dat:
            f.write("\t".join(line) + "\n")
    if cl_cols:
        # For clustering samples
        filename_c = os.path.join(matdir, filename + '_col.MAT')
        mat_c = mat.transpose()
        with open(filename_c, 'w+b') as f:  # creates expression matrix file
            f.write("\t".join(['gene'] + genes) + "\n")
            dat = np.c_[np.array(array).reshape(len(array), 1), mat_c]
            for line in dat:
                f.write("\t".join(line) + "\n")


# Transformation functions
def center_mean(mat):
    # Center matrix
    mat_c = mat - mat.mean(axis=1, keepdims=True)
    return mat_c

def center_median(mat):
    # Center matrix by median
    mat_c = mat - np.median(mat, axis=1, keepdims=True)
    return mat_c

def log10(mat):
    # Take log10 of all values in the matrix
    # If cell_value < 1, result is clamped to 0
    mat_log = np.where(mat < 1, 0, np.log10(mat))
    return mat_log

def mean_stdize(mat):
    mat = center_mean(mat)
    st = np.array(mat).std(1, keepdims=True)  # standard deviation of rows
    mat = mat/st
    return mat

def mad(data, axis=None):
    return np.median(np.absolute(data - np.median(data, axis, keepdims=True)), axis, keepdims=True)

def median_stdize(mat):
    mat = center_median(mat)
    md = mad(mat, axis=1)  # median absolute deviation of rows
    mat = mat/md
    return mat


# Creating the matrix
def create_expressionmat(mat, genes, array, filename, transformation, norm_method, c, matdir, cl_cols):
    # norm_method and c are for RNA seq normalisation, c is pseudocount
    if norm_method:
        logging.info("Normalising RNA seq data with method: %s" % (norm_method,))
        logging.info("Normalising RNA seq data with pseudocount: %s" % (c,))
        mat = transformRNAseq(mat, c = c, method = norm_method) # returns numpy matrix
    if transformation:
        mat = globals()[transformation](mat)
    mat = mat.round(6) # so java could read the numbers
    # Make sure the data does not have all 0 rows and 0 std rows
    st = np.array(mat).std(1) # standard deviation
    which_rows1 = ~(mat==0).all(1)
    which_rows2 = ~(st==0)
    which_rows = which_rows1 & which_rows2
    mat = mat[which_rows]
    genes = list(np.array(genes)[which_rows])
    write_data(mat, genes, array, filename, matdir, cl_cols)  # create expressionmatrix files
    return mat, genes


# 3. Clustering with Hybridclustering
def HybridClustering(filename, dist, hybrid, treedir, matdir):
    # Hierarchical clustering with Hybridclustering using Pearson correlation as default,
    # Average linkage, automatically calculated k for k-means
    # k = sqrt(n/4)

    if hybrid:
        command = ["java", "-jar", "/preprocess_app/scripts/clustering-4.jar", "-i", os.path.join(matdir, filename) + '.MAT',
                   "-sr", str(1), "-sc",
                   str(1), "-sep", '"\\t"', "-%s" % dist, "-o", os.path.join(treedir, filename), "-hybrid", "-precision", str(10)]

    else:
        command = ["java", "-jar", "/preprocess_app/scripts/clustering-4.jar", "-i", os.path.join(matdir, filename) + '.MAT',
                   "-sr", str(1), "-sc",
                   str(1), "-sep", '"\\t"', "-%s" % dist, "-o", os.path.join(treedir, filename), "-precision", str(10)]

    # Run clustering
    p = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    out, err = p.communicate()
    if err:
        logging.info(err)
    # If clustered columns, then file2 exists
    filename2 = filename + "_col"
    if filename2 + ".MAT" in os.listdir(matdir):
        command2 = ["java", "-jar", "/preprocess_app/scripts/clustering-4.jar", "-i", os.path.join(matdir, filename2) + '.MAT',
                    "-sr", str(1), "-sc",
                    str(1), "-sep", '"\\t"', "-%s" % dist, "-o", os.path.join(treedir, filename2), "-hybrid", "-precision", str(10)]
        p = subprocess.Popen(command2, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        out, err = p.communicate()
    return os.path.join(treedir, filename), os.path.join(treedir, filename2)


# Function to convert data.gtr and data.cdt files into NEWICK format
# Taken from: https://github.com/tanghaibao/treecut/blob/master/scripts/eisen_to_newick.py

def cdt_to_nwk(gtr_file, cdt_file):
    f_name, extension = os.path.splitext(gtr_file)
    nwk_file = f_name + '.nwk'  # change the .gtr extension to .nwk
    GTRLine = collections.namedtuple("GTRLine", "parent left_child right_child dist")
    reader = csv.reader(file(cdt_file), delimiter="\t")
    reader.next()  # header
    gid_to_name = {}
    for row in reader:
        gid, name = row[:2]
        gid_to_name[gid] = name
    reader = csv.reader(file(gtr_file), delimiter="\t")
    nodes = {}
    for gtr in map(GTRLine._make, reader):
        node = Tree()
        parent_name, parent_dist = gtr.parent, float(gtr.dist)
        for child in (gtr.left_child, gtr.right_child):
            # if is leaf/gene
            if child in gid_to_name:
                node.add_child(name=gid_to_name[child], dist=1 - parent_dist)
            else:
                assert child in nodes, child
                child_node, child_dist = nodes[child]
                # dist: the distance from the node to the child.
                node.add_child(child_node, dist=child_dist - parent_dist)
        nodes[parent_name] = (node, parent_dist)
    t = node
    t.dist = 0.0  # doesn't change the tree structure
    t.write(features=[], format=1, outfile=nwk_file, format_root_node=True)
    return t, nwk_file  # in case we want to continue with our analysis


# Functions for querying with gCocoa

def toFasta(clusters_dict, fasta_filename):
    """This function writes given dictionary of clusters into .FASTA file for querying with gCocoa"""
    the_file = open(fasta_filename, 'w')
    for name, query in clusters_dict.iteritems():
        fasta_string = '>' + name + "\n" + query + "\n"
        the_file.write(fasta_string)


def split_dict(clusters_dict, qsize):
    """This function splits given dictionary into parts with given size
    (in order to not query all clusters at once)"""
    for i in range(len(clusters_dict) / qsize):
        yield dict(clusters_dict.items()[i * qsize:(i * qsize) + qsize])
    if len(clusters_dict) % qsize != 0:  # leftover clusters (if division isn't exact)
        yield dict(clusters_dict.items()[-(len(clusters_dict) % qsize):])


def gCocoa(query_file, genome, correction, bg):
    """This function takes given .FASTA file and sends this to gCocoa for querying (from server)

    Needed arguments:
    query_file (resultfile from toFasta()),
    genome ('hsapiens'),
    correction ('a', 'b' or 'f' <-- analytical threshold, Bonferroni correction, FDR Benjamini-Hochberg correction),
    terms is a list of term names
    bg is background for querying (platform or none)
    """
    terms = ["GO", "KEGG", "REAC", "TF", "MI", "HP", "CORUM", "HPA"]  # needed to leave BIOGRID out
    bg_dir = '/gprofiler/ensembl_data/' + genome + '/backgrounds'
    # bg_dir = '/gp_data/' + genome + '/backgrounds'
    # If background exists in /backgrounds folder, then use it, else query without background
    if os.path.isdir(bg_dir) and bg in os.listdir(bg_dir):
        command = ["/gprofiler/gost.pl", "-g", genome, "--query_file_multiple", query_file,
                   "-x", "-t", correction, "--no_iea", "--webservice_output", "--sort_by_pvalue",
                   "-l", "--background_spexs", bg, "-s", ",".join(terms)]
    elif bg in os.listdir(os.path.join(conf.DATADIR, "backgrounds")):
        # if use dataset as background
        command = ["/gprofiler/gost.pl", "-g", genome, "--query_file_multiple", query_file,
                       "-x", "-t", correction, "--no_iea", "--webservice_output", "--sort_by_pvalue",
                       "-l", "-s", ",".join(terms), "-B", os.path.join(conf.DATADIR, "backgrounds", bg)]

    else:
        command = ["/gprofiler/gost.pl", "-g", genome, "--query_file_multiple", query_file,
                   "-x", "-t", correction, "--no_iea", "--webservice_output", "--sort_by_pvalue",
                   "-l", "-s", ",".join(terms)]

    gcocoa = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)

    # read results line by line and filter them to resultlist
    if gcocoa.stdout:
        resultlist = []
        domain_sizes = {}
        for line in gcocoa.stdout:
            if line.startswith("NODE"):  # if line starts with the node name like 'NODE_x'
                line = line.split('\t')
                resultlist.append(
                    {'node_id': line[0], 'pval': line[2], 't_size': line[3], 'q_size': line[4], 'intersection': line[5],
                     'prec': line[6],
                     'rec': line[7], 't_id': line[8], 'domain': line[8].split(":")[0], 't_type': line[9],
                     'descr': line[11],
                     't_list': line[13].rstrip().split(",")})
            else:
                if "Effective domain" in line:
                    info = line.split('\t')[1].split(" ")
                    domain = info[4].strip(":").split("_")[0]  # remove NOIEA from domain name
                    size = int(info[5].strip(","))
                    domain_sizes[domain] = size

        for x in resultlist:
            x["domain_size"] = domain_sizes.get(x["domain"])
        return resultlist


def find_clusters(tree, minsize, maxsize, expressions):
    """This function takes Newick tree and returns dictionary with clusters sized between minsize and maxsize.
    It also names the tree nodes by 'NODE_x'.

    Result: {'NODE_0': 'gen1 gen2 gen3', ... }
    """
    clusters = dict()  # dictionary to store the clusters (only the ones that need to be queried!)
    node2labels = tree.get_cached_content(store_attr="name", container_type=type(
        []))  # dictionary with leaf names for each node (speeds up?)
    edge = 1
    for node in tree.traverse():
        if node.is_root():
            node.add_features(rootDist=0.0, status=None)
            node.name = "NODE_0"
        elif node.is_leaf():  # if node is leaf add profile for heatmap plotting
            #node.add_features(rootDist=node.up.rootDist + node.dist)
            node.add_features(rootDist=1.0)
            if expressions:
                node.add_features(profile=expressions[node.name])  # add expression vector to each leaf
        else:  # in order to not rename the leaves (genes)
            node.name = "NODE_%d" % edge  # name each node as NODE_1 etc
            node.add_features(rootDist=node.up.rootDist + node.dist)
            node.add_features(
                status=None)  # add feature to nodes where we can add if cluster is dense ('D'), sparse ('S') or neither (None)
            # is there something better to use instead of D, S and ' ' ?
            edge += 1
            if minsize <= len(node) <= maxsize:  # if cluster size is between given min and max size then query
                clusters[node.name] = " ".join(
                    node2labels[node])  # get one string from the list of genes in one cluster
    return clusters


def query_process(x, genome, correction, bg):
    # x is a dictionary with size 10 that is yield by split_dict
    tf = tempfile.NamedTemporaryFile()
    toFasta(x, tf.name)  # create FASTA file
    # Query with gCost
    # Returns a list with result dictionaries
    gres = gCocoa(query_file=tf.name, genome=genome, correction=correction, bg=bg)
    tf.close()  # deletes the temporary FASTA file
    if gres:
        return gres  # list of dictionaries


def annotate_clusters(tree, genome, correction, minsize, maxsize, bg, expressions):
    """This function takes the Newick tree and queries with gCocoa(). This is the main function for that!
    """
    clusters = find_clusters(tree, minsize, maxsize, expressions)  # also adds names to the nodes
    # Start querying with gProfiler
    qsize = 10  # how many clusters to query at once?
    TASKS = list(split_dict(clusters_dict=clusters, qsize=qsize))  # all clusters split into list by 'qsize' clusters at one

    pool = multiprocessing.Pool(processes=8)
    jobs = []

    for i in range(len(TASKS)):
        jobs.append(pool.apply_async(query_process, args=(TASKS[i], genome, correction, bg)))
    output = []
    for j in jobs:
        res = j.get()
        if type(res) is list:
            output = output + res
    pool.close()
    pool.join()
    return output


# gConvert genes
def gConvert(genes, bg, organism):
    bg_dir = '/gprofiler/ensembl_data/' + organism + '/backgrounds'
    # bg_dir = '/gp_data/' + organism + '/backgrounds'
    if os.path.isdir(bg_dir) and bg in os.listdir(bg_dir):
        res = gp.gconvert(genes, organism=organism, target=bg)  # list of lists with the results
    else:
        res = gp.gconvert(genes, organism=organism)
    res_genes = [{"gene_id": r[1], "gene_name": r[4], "descr": r[5]} for r in res if r[2].endswith(".1")]
    return res_genes


# Create database table named by analysed filename
def create_connection(user, dbname, host):
    """ create a database connection to the SQLite database
        specified by db_file
    :param db_file: database file
    :return: Connection object
    """
    conn_string = "host='%s' dbname='%s' user='%s'" % (host, dbname, user)
    try:
        conn = psycopg2.connect(conn_string)
        return conn
    except:
        logging.info("Couldn't connect to database")
        sys.exit(1)



def create_tables(conn, filename):
    """ create a tables tree and hash_filename
    :param conn: Connection object
    :param filename: a CREATE TABLE table name
    :return:
    """
    create_table_sql2 = """CREATE TABLE IF NOT EXISTS "{t}"(node_id text, t_id text, t_size integer, q_size integer, domain_size integer, intersection integer, rec real, prec real, pval numeric, t_list text[]);""".format(t=filename)
    #create_table_sql3 = """CREATE TABLE IF NOT EXISTS terms (t_id text PRIMARY KEY, descr blob, domain text, t_type text);"""
    #if not user:
    #    create_table_sql1 = """CREATE TABLE IF NOT EXISTS trees (hash_name text PRIMARY KEY, ds_name text, ds_description text, ds_link blob, distance text, correction text, background text, platform text, organism text, ds_list blob, experiment_descr blob, transformation text);"""
    #else:
    #    create_table_sql1 = """CREATE TABLE IF NOT EXISTS trees (hash_name text PRIMARY KEY, ds_name text, ds_description text, ds_link blob, distance text, correction text, background text, platform text, organism text, ds_list blob, experiment_descr blob, transformation text, email blob, email_hash text);"""

    c = conn.cursor()
    #c.execute(create_table_sql1)
    c.execute(create_table_sql2, (filename,))
    #c.execute(create_table_sql3)


def insert_ds_data(conn, ds_id, track_data, ds_data):
    c = conn.cursor()
    sql1 = """INSERT INTO tracks(ds_id, sample_id, track_name, track_value) VALUES ({t}, %(sample_id)s, %(track_name)s, %(track_value)s);""".format(
        t=ds_id)
    sql2 = """INSERT INTO dataset(ds_id, ds_name, organism, ds_descr, ds_link, experiment_descr, platform, sample_count, gene_count, data_type, ds_list) VALUES ({t}, %(ds_name)s, %(organism)s, %(ds_descr)s, %(ds_link)s, %(experiment_descr)s, %(platform)s, %(sample_count)s, %(gene_count)s, %(data_type)s, %(ds_list)s);""".format(t=ds_id)
    c.executemany(sql1, track_data)
    c.execute(sql2, ds_data)


def insert_annot_data(conn, hash_name, annot_data, input_data, user):
    """ insert data into db about annotations
    :param conn: Connection object
    :param hash_name: hash filename
    :param data: Pandas dataframe, column names are the same as in the table
    :return:
    """
    c = conn.cursor()
    sql1 = """INSERT INTO annotation(hash_name, node_id, t_id, q_size, t_size, domain_size, intersection, rec, prec, pval, t_list) VALUES ({t}, %(node_id)s, %(t_id)s, %(q_size)s, %(t_size)s, %(domain_size)s, %(intersection)s, %(rec)s, %(prec)s, %(pval)s, %(t_list)s);""".format(t=hash_name)
    sql2 = """INSERT INTO term(t_id, descr, domain, t_type) VALUES (%(t_id)s, %(descr)s, %(domain)s, %(t_type)s) ON CONFLICT DO NOTHING;"""
    if user:
        sql3 = """INSERT INTO input(hash_name, ds_id, gp_version, background, cl_cols, transformation, correction, pseudocount, distance, norm_method, email_hash) VALUES ({t}, %(ds_id)s , %(gp_version)s, %(background)s, %(cl_cols)s, %(transformation)s, %(correction)s, %(pseudocount)s, %(distance)s, %(norm_method), %(email_hash)s);""".format(t=hash_name)
    else:
        sql3 = """INSERT INTO input(hash_name, ds_id, gp_version, background, cl_cols, transformation, correction, pseudocount, distance, norm_method) VALUES ({t}, %(ds_id)s , %(gp_version)s, %(background)s, %(cl_cols)s, %(transformation)s, %(correction)s, %(pseudocount)s, %(distance)s, %(norm_method));""".format(t=hash_name)
    #sql1 = """INSERT INTO "{t}" (node_id, t_id, t_size, q_size, domain_size, intersection, rec, prec, pval, t_list) VALUES (%(node_id)s, %(t_id)s, %(t_size)s, %(q_size)s, %(domain_size)s, %(intersection)s, %(rec)s, %(prec)s, %(pval)s, %(t_list)s);""".format(t=filename)
    #sql2 = """INSERT INTO terms(t_id, descr, domain, t_type) VALUES (%(t_id)s, %(descr)s, %(domain)s, %(t_type)s) ON CONFLICT DO NOTHING;"""
    c.executemany(sql1, annot_data)
    c.executemany(sql2, annot_data)
    c.execute(sql3, input_data)



# 5. The main function that is invoked from command line
def main(inputfile, user, email, email_hash, transf, norm_method, pseudocount, cl_cols, bg):
    # Parameters
    dists = ['p']
    hybrid = True
    correction = ['a', 'b', 'f']

    # Read in the data
    data_dict = read_data(nc_dat=inputfile)  # dictionary with data from .nc file
    mat = data_dict['matrix']
    initial_genes = data_dict["genes"]
    array = data_dict["array"]
    #ds_id = data_dict["ds_id"] # ds_name
    ds_name = data_dict["ds_id"]
    organism = data_dict["organism"]
    experiment_descr = data_dict["description"]
    track_data = data_dict.get("tracks",[])  # list of dictionaries for sample tracks

    # unique filename
    ds_filename = os.path.splitext(os.path.basename(inputfile))[0]

    if not user:
        TREEDIR = conf.TREEDIR["non_user"]
        MATDIR = conf.MATDIR["non_user"]
        db_user = conf.DATABASES['default']['USER']
        dbname = conf.DATABASES['default']['DBNAME']
        host = conf.DATABASES['default']['HOST']
        ds_link = data_dict.get("ds_link", "")
        data_type = data_dict.get("ds_type", "")
        # what transormation to use before clustering
        if data_type and not transf:
            transf = TRANSFORMS.get(data_type, None)  # log10 or center
        # Get background for our public datasets (if user uploads own data, then don't use bg)
        platform = os.path.basename(os.path.dirname(inputfile))
        platformfolder = os.path.dirname(os.path.dirname(inputfile))

        if os.path.isfile(os.path.join(platformfolder,'platforminfo')):
            with open(os.path.join(platformfolder,'platforminfo'), 'rb') as f:
                PLATFORMINFO = json.load(f)
            background = PLATFORMINFO.get(platform, None)
        else:
            background = None
        if background:
            background = background.get('gc_namespace', None)
            if background:
                background = background.encode('ascii', 'ignore').upper()
        # Get the info of dataset
        infofile = os.path.join(os.path.dirname(inputfile), 'DESC/exps.collection')
        if os.path.isfile(infofile):
            with open(infofile, 'rb') as f:
                for line in f:
                    if line.startswith(ds_id):
                        index_info = line.rstrip()  # DATASET:;TITLE:;CHIPS:;DESC:;TAGS:;PLATFORM
                        description = index_info.split(":;")[1]
                        break
        else:
            description = ""

        if any(item.startswith(ds_id + '_') for item in os.listdir(TREEDIR)):
            logging.info("FAIL, FILE ALREADY EXISTS!: %s" % (inputfile,))
            sys.exit(0)

    else:
        TREEDIR = conf.TREEDIR["user"]
        MATDIR = conf.MATDIR["user"]
        db_user = conf.DATABASES['user']['USER']
        dbname = conf.DATABASES['user']['DBNAME']
        host = conf.DATABASES['user']['HOST']
        #DB_FILE = conf.DB_FILE["user"]
        description = ""
        ds_link = ""
        platform = ""
        if bg:
            background = ds_id + "_bg"
            # save background file for gprofiler analysis
            bg_file = open(os.path.join(conf.DATADIR, "backgrounds", background), "w")
            bg_file.write(" ".join(initial_genes))
            bg_file.close()

        else:
            background = None



    # Database connection and create tables if needed
    conn = create_connection(user=db_user, dbname=dbname, host=host)
    c = conn.cursor()
    if len(track_data) > 0:
        # Add table with sample tracks
        c.execute("""SELECT count(*) FROM information_schema.tables WHERE table_name=%s;""", (ds_filename,))
        is_table = c.fetchone()[0]
        if is_table==0:
            #create_table_sql4 = """CREATE TABLE IF NOT EXISTS "{t}"(ds_id text, track_name text, track_value text);""".format(t=ds_id)
            create_table_sql4 = """CREATE TABLE IF NOT EXISTS "{t}" (ds_id text, track_name text, track_value text);""".format(t=ds_filename)
            c.execute(create_table_sql4)
            #sql = """INSERT INTO "{t}" (ds_id, track_name, track_value) VALUES (%(ds_id)s, %(track_name)s, %(track_value)s);""".format(t=ds_id)
            sql = """INSERT INTO "{t}" (ds_id, track_name, track_value) VALUES (%(ds_id)s, %(track_name)s, %(track_value)s);""".format(t=ds_filename)
            c.executemany(sql, track_data)
    # Clustering

    # Hash the filename by distance (and correction parameters, FILE FOLDER PATH ADDED TO THE FILENAME!!!)
    hashes = {}  # dictionary with distance and filename
    for dist in dists:
        hash = hashlib.md5(str(dist)).hexdigest()
        if not user:
            hashes[dist] = "_".join([ds_id, hash])
        else:
            hashes[dist] = "_".join([ds_id, email_hash, hash])

    # Create expression matrices
    for dist, filename in hashes.iteritems():
        mat_t, genes = create_expressionmat(mat=mat, genes=initial_genes, array=array, filename=filename, transformation=transf, norm_method=norm_method, c=pseudocount, matdir=MATDIR, cl_cols=cl_cols)  # creates expression matrix after transformation, also writes it to mat_file
        # gconvert gene names
        gene_table = ds_filename + "_genes"  # table name
        # gene_table = ds_id + "_genes"  # table name
        c.execute("""SELECT count(*) FROM information_schema.tables WHERE table_name=%s;""", (gene_table,))
        is_table = c.fetchone()[0]
        if is_table==0:
            gene_names = gConvert(genes, bg=background, organism=organism)
            create_table = """CREATE TABLE IF NOT EXISTS "{t}" (gene_id text PRIMARY KEY, gene_name text, descr text);""".format(t=gene_table)
            c.execute(create_table)
            sql = """INSERT INTO "{t}"(gene_id, gene_name, descr) VALUES (%(gene_id)s, %(gene_name)s, %(descr)s) ON CONFLICT DO NOTHING;""".format(t=gene_table)
            c.executemany(sql, gene_names)

        mat_shape = np.shape(mat_t)
        if dist=="p" and any(x<5 for x in mat_shape):
            continue

        logging.info('%s: Started clustering with distance %s', ds_id , dist)
        logging.info('%s: The dimensions of data are: %s x %s', ds_id, mat_shape[0], mat_shape[1])
        logging.info('%s: The transformation of data is: %s ', ds_id, transf)

        outname, outname2 = HybridClustering(filename=filename, dist=dist, hybrid=hybrid, treedir=TREEDIR,
                                             matdir=MATDIR)

        if not os.path.isfile(outname+".gtr"):
            conn.rollback()
            # Add to blacklist
            if user:
                c.execute("""INSERT INTO blacklist(hash_id) VALUES (%(hash_id)s)""", [{"hash_id": email_hash}])
                conn.commit()
            conn.close()
            break
            raise ValueError("Clustering failed: %s" % ds_id)




        logging.info('%s: Clustering ended', ds_id)
        # Create Newick tree file
        tree, nwk_file = cdt_to_nwk(gtr_file=outname + ".gtr", cdt_file=outname + ".cdt")
        if cl_cols:
            tree_col, nwk_file_col = cdt_to_nwk(gtr_file=outname2 + ".gtr", cdt_file=outname2 + ".cdt")
            # Re-arrange mat_file according to column clustering
            n_array = tree_col.get_leaf_names()  # new order of samples, old order is 'array'
            i = [array.index(x) for x in n_array]  # new indexes
            n_mat = mat_t[:, i]
            # Rewrite the mat file
            with open(os.path.join(MATDIR, filename) + '.MAT', 'w+b') as f:  # creates new expression matrix file
                f.write("\t".join(['gene'] + n_array) + "\n")
                dat = np.c_[np.array(genes).reshape(len(genes), 1), n_mat]
                for line in dat:
                    f.write("\t".join(line) + "\n")
        else:
            n_array = array
            dat = np.c_[np.array(genes).reshape(len(genes), 1), mat_t]
        expressions = dict(zip([x[0] for x in dat], [[float(v) for v in x[1:]] for x in
                                                     dat]))  # dictionary with genes as keys and expression vector as values

        # Remove .gtr and .cdt files from folder, also mat_col
        remove_files = [outname + ".gtr", outname + ".cdt", outname2 + ".cdt", outname2 + ".gtr",
                        os.path.join(MATDIR, filename) + '_col.MAT']
        for x in remove_files:
            if os.path.isfile(x):
                os.remove(x)
        for corr in correction:
            #hash2 = hashlib.md5(str([dist, corr])).hexdigest()
            hash2 = "".join([dist, corr]) if user else hashlib.md5(str([dist, corr])).hexdigest()
            create_tables(conn=conn, filename="_".join([ds_filename, hash2]))  # creating tables for our database

            #create_tables(conn=conn, filename="_".join([ds_id, hash2]))  # creating tables for our database
            # logging.info('Annotating starts')
            # Query with gP and write results to pandas dataframe
            output = annotate_clusters(tree=tree, genome=organism, correction=corr,
                                       minsize=MINSIZE, maxsize=MAXSIZE, bg=background, expressions=expressions)
            # annotate_clusters(tree=tree, genome=organism, correction=corr,
            #                            minsize=MINSIZE, maxsize=MAXSIZE, bg=background, expressions=expressions,
            #                            spark=spark)
            logging.info("%s: The size of the output is: " + str(len(output)), ds_id)
            # logging.info('Annotations are done')

            if len(output)>0:
                try:
                    insert_filetable(conn=conn, filename="_".join([ds_filename, hash2]), data=output)
                    #insert_filetable(conn=conn, filename="_".join([ds_id, hash2]), data=output)

                    # Add file info to table 'trees'
                    if user:
                        sql = """INSERT INTO trees(hash_name, ds_name, distance, correction, organism, ds_list, transformation, norm_method, pseudocount, background, cl_cols, email, email_hash, experiment_descr) VALUES (%(hash_name)s, %(ds_name)s, %(distance)s, %(correction)s, %(organism)s, %(ds_list)s, %(transformation)s, %(norm_method)s, %(pseudocount)s, %(background)s, %(cl_cols)s, %(email)s, %(email_hash)s, %(experiment_descr)s) ON CONFLICT DO NOTHING;"""
                        if not email:
                            email = "global"
                        trees_data = [{"hash_name": "_".join([ds_filename, hash2]), "ds_name": ds_id,
                                       "distance": dist, "correction": corr, "organism": organism, "ds_list": n_array, "transformation": transf,
                                       "background": str(background), "cl_cols": cl_cols,
                                      "email": email, "email_hash": email_hash, "experiment_descr": experiment_descr.decode('unicode-escape'), "norm_method": norm_method, "pseudocount": pseudocount}]
                    else:
                        sql = """INSERT INTO trees(hash_name, ds_name, ds_description, ds_link, distance, correction, background, platform, organism, ds_list, experiment_descr, transformation, norm_method, pseudocount) VALUES (%(hash_name)s, %(ds_name)s, %(ds_description)s, %(ds_link)s, %(distance)s, %(correction)s, %(background)s, %(platform)s, %(organism)s, %(ds_list)s, %(experiment_descr)s, %(transformation)s, %(norm_method)s, %(pseudocount)s) ON CONFLICT DO NOTHING;"""
                        trees_data = [{"hash_name": "_".join([ds_id, hash2]), "ds_name": ds_id,
                                      "ds_description": unicode(description),
                                      "ds_link": ds_link, "distance": dist, "correction": corr, "background": background,
                                      "platform": platform, "organism": organism, "ds_list": n_array,
                                      "experiment_descr": experiment_descr.decode('unicode-escape'), "transformation": transf,
                                      "email": email, "email_hash": email_hash, "norm_method": norm_method, "pseudocount": pseudocount}]

                    c.executemany(sql, trees_data)

                    # Save the tree with the results
                    tree.write(features=[], outfile=nwk_file, format=1, format_root_node=True)
                except:
                    e = sys.exc_info()[0]
                    logging.info("Error in output: %s" % e)
                    logging.info("Description is : %s" % description)
                    conn.rollback()
                    # Add to blacklist
                    if user:
                        c.execute("""INSERT INTO blacklist(hash_id) VALUES (%(hash_id)s)""", [{"hash_id": email_hash}])
                        conn.commit()
                    conn.close()
                    break
                    sys.exit(1)


            else:
                conn.rollback()
                # Add to blacklist
                if user:
                    c.execute("""INSERT INTO blacklist(hash_id) VALUES (%(hash_id)s)""", [{"hash_id": email_hash}])
                    conn.commit()
                conn.close()
                break
                raise ValueError("Output is empty: %s" % ds_id)


    conn.commit()
    conn.close()
    return "success"


# 4. Take arguments from command line and create the resultfile
parser = argparse.ArgumentParser(description='Preprocessing .nc file, i.e clustering')
parser.add_argument('-i', required=True, help="Name of the input .nc file")
parser.add_argument('-U', action="store_true", help="If given then the data is user uploaded")
parser.add_argument('-email', default="", help="Email of user")
parser.add_argument('-hash', default="", help="Hash connected to email")
parser.add_argument('-transf', default=None, help="Transformations to apply to the matrix")
parser.add_argument('-cols', action="store_true", help="If given, then cluster also the columns")
parser.add_argument('-bg', action="store_true", help="If given, then use custom background")
parser.add_argument('-norm_method', default=None, help="If given, then normalise RNA seq")
parser.add_argument('-pseudocount', default=1.0, type=float, help="Pseudocount for RNA seq normalisation")


if __name__ == "__main__":
    args = parser.parse_args()
    inputfile = args.i  # .nc file with path
    user = args.U  # if user uploaded file
    email = args.email
    email_hash = args.hash
    transf = args.transf
    cl_cols = args.cols # cluster columns?
    bg = args.bg # use custom background?
    norm_method = args.norm_method # for RNAseq
    pseudocount = args.pseudocount # pseudocount for RNAseq

    # Logging
    if user:
        logging.basicConfig(level=logging.INFO,
                            format='%(asctime)s.%(msecs)d %(levelname)s %(module)s - %(funcName)s: %(message)s',
                            datefmt="%Y-%m-%d %H:%M:%S", filename=os.path.join(LOGDIR, 'vishic_user.log'),
                            filemode='a+')
    else:
        logging.basicConfig(level=logging.INFO,
                            format='%(asctime)s.%(msecs)d %(levelname)s %(module)s - %(funcName)s: %(message)s',
                            datefmt="%Y-%m-%d %H:%M:%S", filename=os.path.join(LOGDIR, 'vishic.log'), filemode='a+')
    logging.info('\n')
    logging.info('NEW PROCESSING')
    logging.info('%s: Preprocessing starts', inputfile)
    res = main(inputfile, user, email, email_hash, transf, norm_method, pseudocount, cl_cols, bg)
    logging.info('%s: Everything is done', inputfile)

