#!/bin/sh

cd preprocess_app

scripts/run_gp.sh

# Wait for Redis server to start
sleep 10

celery -A preprocessing_app.celery worker --loglevel=debug -f /log
