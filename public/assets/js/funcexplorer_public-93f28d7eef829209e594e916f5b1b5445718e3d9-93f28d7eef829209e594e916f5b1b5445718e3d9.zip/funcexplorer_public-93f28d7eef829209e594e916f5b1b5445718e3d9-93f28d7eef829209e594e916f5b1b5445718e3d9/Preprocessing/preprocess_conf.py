import os
REDIS_PORT = 6379
REDIS_DB = 0
REDIS_HOST = os.environ.get('REDIS_PORT_6379_TCP_ADDR', 'preprocess_redis')
CELERY_RESULT_BACKEND = 'redis://%s:%d/%d' % (REDIS_HOST, REDIS_PORT, REDIS_DB)
CELERY_BROKER_URL = 'redis://%s:%d/%d' % (REDIS_HOST, REDIS_PORT, REDIS_DB)

# all paths for user and public
DATADIR = "/data"
UPLOAD_FOLDER = os.path.join(DATADIR, 'upload')
LOGDIR = os.path.join(DATADIR, 'logs')
