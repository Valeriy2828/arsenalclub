#!/bin/sh
/preprocess_app/scripts/run_gp.sh \
&& /usr/sbin/apache2ctl -D FOREGROUND
