# Creating sqlite3 database that consists gene ref lists for each public affy
# Database is used for autocomplete search
# Iterates over /scratch/data/AE/ folders and looks for affy_ref files
# It is located in /data/databases
import os
import sqlite3
import pandas as pd

rootdir = '/AE'

dir_list = os.walk(rootdir).next()[1]

if __name__ == "__main__":
    conn = sqlite3.connect('/affy_lists.db')
    cur = conn.cursor()

    for dir in dir_list:
        f = os.path.join(os.path.join(rootdir, dir), "affy_ref")
        if os.path.exists(f):
            create_table_sql = """CREATE TABLE IF NOT EXISTS "%s" (gene_id text, name blob, descr text);""" % dir
            cur.execute(create_table_sql)
            gene_data = pd.read_csv(f, sep='\t', names=['gene_id', 'name', 'descr'], na_values="NaN")
            data = gene_data.to_dict('records')
            sql = """INSERT INTO "%s" (gene_id, name, descr) VALUES (:gene_id, :name, :descr)""" % dir
            cur.executemany(sql, data)
    conn.commit()
    conn.close()
