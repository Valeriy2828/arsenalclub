#!/bin/bash
cd /gprofiler && ./compile_gost.sh && ./link_edata.sh /gp_data

cd /preprocess_app && R -f scripts/install.R