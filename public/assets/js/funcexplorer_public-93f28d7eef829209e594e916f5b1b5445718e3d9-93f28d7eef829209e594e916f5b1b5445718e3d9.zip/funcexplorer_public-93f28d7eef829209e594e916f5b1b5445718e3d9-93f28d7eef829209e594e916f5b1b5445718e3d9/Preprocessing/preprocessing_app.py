from flask import Flask, request
import os
import sys
from preprocess_celery import make_celery
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.header import Header
import smtplib
from tab2nc import tab2nc
from keys_preprocess import KEY

import logging

def setup_logger(logger_name, log_file, level=logging.INFO):
    l = logging.getLogger(logger_name)
    formatter = logging.Formatter('%(asctime)s.%(msecs)d %(levelname)s %(module)s - %(funcName)s: %(message)s')
    fileHandler = logging.FileHandler(log_file, mode='a+')
    fileHandler.setFormatter(formatter)
    streamHandler = logging.StreamHandler()
    streamHandler.setFormatter(formatter)
    l.setLevel(level)
    l.addHandler(fileHandler)
    l.addHandler(streamHandler)
    return l

def send_mail(name, email, email_hash, ds_name, error, fail):
    if not fail:
        message = "The preprocessing of %s was successful!\n" % ds_name
        message = message + "You can access your data from link: https://biit.cs.ut.ee/funcexplorer/user/" + email_hash
        message = message + "\n\n\nThank you for using funcExplorer"
    else:
        message = "Something went wrong while preprocessing data\n"
        message = message + str(error) + "\n"

    from_address = ["Liis Kolberg", "liis.kolberg@ut.ee"]
    recipient = [name, email]
    subject = 'funcExplorer results'
    subject = subject.decode('unicode-escape')

    msg = MIMEMultipart('related')
    msg['Subject'] = "%s" % Header(subject, 'utf-8')
    msg['From'] = "\"%s\" <%s>" % (Header(from_address[0], 'utf-8'), from_address[1])
    msg['To'] = "\"%s\" <%s>" % (Header(recipient[0], 'utf-8'), recipient[1])
    msg.preamble = 'This is a multi-part message in MIME format.'

    msgAlt = MIMEMultipart('alternative')

    textpart = MIMEText(message, 'plain', 'UTF-8')
    msgAlt.attach(textpart)
    msg.attach(msgAlt)
    s = smtplib.SMTP('mailhost.ut.ee')
    s.sendmail(from_address[1], recipient[1], msg.as_string())
    s.quit()


app = Flask(__name__)
app.config.from_object('preprocess_conf')
celery = make_celery(app)

#logging.basicConfig(level=logging.INFO,
#                            format='%(asctime)s.%(msecs)d %(levelname)s %(module)s - %(funcName)s: %(message)s',
#                            datefmt="%Y-%m-%d %H:%M:%S", filename=os.path.join(app.config['UPLOAD_FOLDER'],'vishic_preprocess.log'),
#                            filemode='a+')

class CallbackTask(celery.Task):
    def on_success(self, retval, task_id, args, kwargs):
        send_mail(retval["name"], retval["email"], retval["email_hash"], retval["ds_name"], error="", fail=False)

    def on_failure(self, exc, task_id, args, kwargs, einfo):
        send_mail("Liis", "liis.kolberg@gmail.com", "abc", "dontknow", error=einfo, fail=True)
        pass


@celery.task(name='vishic_preprocessing.preprocessing', base=CallbackTask)
def preprocessing(input, name, email, email_hash, ds_name, user, transform, norm_method, pseudocount, bg, cl_cols, log, numeric_ns, fix_value, impute_method):
    if user and email:
        command = "/preprocess_app/vishic_preprocessing/preprocessing_docker.py -i %s -email %s -hash %s -U -name '%s'" % (input, email, email_hash, name)
    elif user and not email:
        command = "/preprocess_app/vishic_preprocessing/preprocessing_docker.py -i %s -hash %s -U" % (input, email_hash)
    else:
        command = "/preprocess_app/vishic_preprocessing/preprocessing_docker.py -i %s -email %s -hash %s" % (input, email, email_hash)
    if cl_cols:
        command = command + " -cols"
    if transform:
        command = command + " -transf %s" %(transform)
    if log:
        command = command + " -log"
    if bg:
        command = command + " -bg %s" %(bg)
    if norm_method:
        command = command + " -norm_method %s" % (norm_method)
        if pseudocount:
            command = command + " -pseudocount %s" %(pseudocount)
    if numeric_ns:
        command = command + " -numeric_ns %s" %(numeric_ns)
    if fix_value:
        command = command + " -fix_value %s" %(fix_value)
    if impute_method:
        command = command + " -impute_method %s" %(impute_method)
    if user:
        logger = setup_logger('preprocessing_user', os.path.join(app.config['LOGDIR'], 'preprocessing_user.log'))
    else:
        logger = setup_logger('preprocessing_public', os.path.join(app.config['LOGDIR'], 'preprocessing_public.log'))
    logger.info("%s: Celery starts" % ds_name)
    try:
        res = os.system(command)
        if res == 0:
            if not email:
                email = "liis.kolberg@gmail.com"
            return {"name": name, "email": email, "email_hash": email_hash, "ds_name": ds_name}
        else:
            raise ValueError("Error in preprocessing of %s: %s" % (ds_name, res.text))
    except:
        e = sys.exc_info()[0]
        logger.info(e)
        raise ValueError("Error in running command: %s" % command)


@app.route("/", methods=['POST'])
def preprocess():
    if request.method == 'POST':
        data = request.get_json(force=True)
        # force=True, above, is necessary if another developer
        # forgot to set the MIME type to 'application/json'
        ds_id = data["ds_id"]  # unique filename
        user_name = data.get("name", "")
        user_email = data.get("email", "")
        ds_name = data.get("ds_name", "")
        email_hash = data.get("email_hash", '')
        user = data["user"]
        organism = data.get("organism", None)
        log = data.get("log", None)
        transf = data.get("transform", '')
        bg = data.get("bg", None)
        cl_cols = data.get("cl_cols", False)
        descr = data.get("descr", "")
        norm_method = data.get("norm_method", '')
        pseudocount = data.get("pseudocount", 1)
        numeric_ns = data.get("numeric_ns", '')
        fix_value = data.get("fix_value", 0)
        impute_method = data.get("impute_method", '')
        ds_type = data.get("datatype", "")

        if organism:
            organism = organism.encode('utf-8')
        if transf:
            transf = transf.encode('utf-8')
        if ds_name:
            ds_name = ds_name.encode('utf-8')
        if norm_method:
            norm_method = norm_method.encode('utf-8')
        if impute_method:
            impute_method = impute_method.encode('utf-8')
        if bg:
            bg = bg.encode('utf-8')
        if numeric_ns:
            numeric_ns = numeric_ns.encode('utf-8')
        if descr:
            descr = descr.encode('utf-8')
        if ds_type:
            ds_type = ds_type.encode('utf-8')

        if user:
            # logging file
            logger = setup_logger('preprocessing_user', os.path.join(app.config['LOGDIR'], 'preprocessing_user.log'))
            logger.info('User request starts')
            logger.info(data)
            # tab separated file to .nc
            path_filename = os.path.join(app.config['UPLOAD_FOLDER'], ds_id)
            try:
                nc_filename = tab2nc(path_filename, organism, ds_name, descr, ds_type)
            except:
                os.remove(path_filename +'.nc')
                e = sys.exc_info()[0]
                logger.info("Error in writing the nc file: %s" % e)
                return "Failed"

        if not user:
            logger = setup_logger('preprocessing_public', os.path.join(app.config['LOGDIR'], 'preprocessing_public.log'))
            nc_filename = ds_id
            logger.info('Request starts')
            logger.info(data)
            user_name = "Liis Kolberg"
            user_email = "liis.kolberg@gmail.com"
            email_hash = "test"

        if os.path.isfile(nc_filename):
            logger.info(".nc file exists")
            # start preprocessing
            try:
                task = preprocessing.apply_async(args=[nc_filename, user_name, user_email, email_hash, ds_name, user, transf, norm_method, pseudocount, bg, cl_cols, log, numeric_ns, fix_value, impute_method])
                return "Job submitted: " + ds_id
            except:
                os.remove(path_filename + '.nc')
                e = sys.exc_info()[0]
                logger.info("Problem running celery: %s" % e)
                return "Failed"
        else:
            logger.info(".nc file does not exist")
            return "Failed"


if __name__ == '__main__':
    app.secret_key = KEY["preprocess"]
    app.run(debug=False, threaded=True)
