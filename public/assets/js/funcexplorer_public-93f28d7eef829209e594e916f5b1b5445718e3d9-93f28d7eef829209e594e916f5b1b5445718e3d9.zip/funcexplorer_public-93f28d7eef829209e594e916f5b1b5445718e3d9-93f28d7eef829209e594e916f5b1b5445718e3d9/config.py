# Static configurations
import os
import pickle

sparse_col = ["#ECE7AF"]

cols = ["#3366cc", "#dc3912", "#ff9900", "#556B2F", "#990099", "#00CED1", "#dd4477", "#ADFF2F", "#FFD700",
        "#00FA9A"] + sparse_col

domains = ["BP", "CC", "MF", "keg", "rea", "tf", "mi", "cor", "hp", "hpa", "No data"]

COLORS = dict(zip(domains, cols))

REDIS_PORT = 6379
REDIS_DB = 0
REDIS_HOST = os.environ.get('REDIS_PORT_6379_TCP_ADDR', 'redis')
CELERY_RESULT_BACKEND = 'redis://%s:%d/%d' % (REDIS_HOST, REDIS_PORT, REDIS_DB)
CELERY_BROKER_URL = 'redis://%s:%d/%d' % (REDIS_HOST, REDIS_PORT, REDIS_DB)

DATABASES = {'cache':
    {
        'USER': 'vishic',
        'DBNAME': 'vishic_cache',
        'HOST': 'db'
    },
    'default':
        {
            'USER': 'vishic_nonuser',
            'DBNAME': 'vishic_nonuser',
            'HOST': 'vishic_db'
        },
    'user':
        {
            'USER': 'vishic_user',
            'DBNAME': 'vishic_user',
            'HOST': 'vishic_db'
        }
}

# all paths for user and public
DATADIR = "data"
UPLOAD_FOLDER = os.path.join(DATADIR, 'upload')

#GP_VERSION = "r1732_e89_eg36"
GP_VERSION = "r1741_e90_eg37"
ORGANISMS = pickle.load(open("data/databases/gp_organisms_" + GP_VERSION + ".pkl", "rb"))
ORGANISMS = [(k,v["name"]) for k,v in ORGANISMS.items()]
ORGANISMS.sort(key=lambda tup: tup[1])
NUMERIC_NS = pickle.load(open("data/databases/numeric_ids.pkl", "rb")) # organism:numeric ids, available id-s for upload selection
BACKGROUNDS = pickle.load(open("data/databases/gp_bg_" + GP_VERSION + ".pkl", "rb"))
HASHTABLE_NAME = os.path.join(DATADIR, "databases","shortlink_hashtable.pkl")
